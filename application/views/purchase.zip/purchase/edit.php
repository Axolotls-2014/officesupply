<?php 
  $this->load->view('layout/header');
  $currency = $this->company_settings_model->get_company_records()->currency_symbol;

  $expiry_date = $this->utility_model->get_records_by_field_value('custom_field_setting','field_name', 'field_status', 'expiry_date', 'active',$row = true,$check_delete_status = false);

  $mfg_date = $this->utility_model->get_records_by_field_value('custom_field_setting','field_name', 'field_status', 'mfg_date', 'active',$row = true,$check_delete_status = false);

  $promotion = $this->utility_model->get_records_by_field_value('custom_field_setting','field_name', 'field_status', 'promotion', 'active',$row = true,$check_delete_status = false);

  $batch_no = $this->utility_model->get_records_by_field_value('custom_field_setting','field_name', 'field_status', 'batch_no_purchase', 'active',$row = true,$check_delete_status = false);
                          
?>

<style type="text/css">
  .search { position: relative; }
  .search input { text-indent: 20px;}
  .search .fa-search { 
    position: absolute;
    top: 9px;
    left: 20px;
    font-size: 18px;
    padding-left: 8px;
  }
  .search_product{
    background-color: #F8F8F8;
    height: 35px;
    padding-left: 25px;
    font-size: 18px;
  }

  .search_product::-webkit-input-placeholder { /* Chrome/Opera/Safari */
    padding-left: 5px;
    font-size: 18px;
  }
  .search_product::-moz-placeholder { /* Firefox 19+ */
    font-size: 18px;
  }
  .search_product:-ms-input-placeholder { /* IE 10+ */
    font-size: 18px;
  }
  .search_product:-moz-placeholder { /* Firefox 18- */
    font-size: 18px;
  }
  .product_row{
    background: #fffee9 !important;
  }
  .highlight_row{
    /*animation: fadeOut 5s forwards;*/
    background: #fed9c6 !important;
    -webkit-transition: all 0.5s ease;
    -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
  }
  .quantity_update_message{
    width: 100% !important;
    padding-left: 40% !important;
  }

  .discount_type{
    padding-left: 20px;
  }
  .discount_amount{
    padding-right: 10px !important;
  }
  .delete_item{
    cursor:pointer;
  }
  .total_data{
    font-size: 18px;
    font-weight: bolder;
  }



</style>
  <div class="wrapper">
    <div class="content-wrapper">
      <section class="content-header">
          <div class="row mb-2">
            <div class="col-sm-12">
              <ol class="breadcrumb breadcrumb-custom float-sm-left">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item "><a href="#"><?=$this->lang->line('header_inventory')?></a></li>
                <li class="breadcrumb-item "><a href="<?=base_url('purchase')?>"><?=$this->lang->line('purchase_header')?></a></li>
                <li class="breadcrumb-item active"><?=$this->lang->line('purchase_edit')?></li>
              </ol>
            </div>
          </div>
      </section>

      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <form class="form-horizontal" name="editPurchaseForm" id="editPurchaseForm" method="POST" action="<?=base_url('purchase/edit')?>">
              <div class="card">
                <div class="card-header"><?=$this->lang->line('purchase_edit')?></h6>
                  <div class="card-tools">
                    <ul class="nav nav-pills ml-auto">


                      
                      <li class="nav-item  ml-2">
                        <a class="nav-link reset btn-sm btn-warning" href="#" data-tt="tooltip" title="Click here to Reset Purchase Items">
                          <i class="fas fa-redo-alt"></i> Reset
                        </a>
                      </li>
                      


                      <li class="nav-item ml-2">
                        <a class="nav-link active" href="<?=base_url('purchase')?>" data-tt="tooltip" title="Click here to show purchase list"><i class="fas fa-arrow-left mr-2"></i>Back</a>
                      </li>

                    </ul>
                  </div>
                </div>
                <div class="card-body">
                  <div class="col-sm-12">
                    <div class="row">
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_reference_no')?></label>
                          <input type="text" class="form-control" id="reference_no" name="reference_no" value="<?=$purchase->reference_no?>" readonly>
                        </div>
                      </div>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_invoice_no')?></label>
                          <input type="text" class="form-control" id="invoice_no" name="invoice_no" value="<?=$purchase->invoice_no?>" placeholder="<?=$this->lang->line('purchase_invoice_no')?>">
                          <!-- <span id="err_invoice_no" class="error invalid-feedback"><?=form_error('invoice_no');?></span> -->
                        </div>
                      </div>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_date')?></label>
                          <input type="text" class="form-control datepicker" id="purchase_date" name="purchase_date" value="<?=date('d-m-Y', strtotime($purchase->purchase_date))?>" placeholder="Invoice Date">
                          <span id="err_purchase_date" class="error invalid-feedback"><?=form_error('purchase_date');?></span>
                        </div>
                      </div>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label><?=$this->lang->line('sale_due_date')?></label>
                          <input type="text" class="form-control datepicker" readonly="readonly" id="due_date" name="due_date" value="<?=set_value('due_date',(($purchase->due_date != '' && $purchase->due_date != '0000-00-00') ? date('d-m-Y',strtotime($purchase->due_date)) : '' ))?>" readonly>
                        </div>
                      </div>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label for="warehouse">
                            <?=$this->lang->line('purchase_warehouse')?>
                            <span class="text-danger">*</span>
                          </label>
                          <div class="input-group input-group-sm">
                            <select class="form-control form-control-sm select2bs4 field_validation" name="warehouse_id" id="warehouse_id" width="100%" class="add-row" placeholder="<?=$this->lang->line('purchase_warehouse')?>">
                            <option value=""><?=$this->lang->line('select')?></option>
                            <?php
                              foreach ($warehouses as $value) {
                            ?>
                              <option value="<?=$value->id;?>"
                                <?php 
                                  if($value->id == $purchase->warehouse_id)
                                    echo ' selected';
                                ?>
                              >
                                <?= $value->name;?>
                              </option>
                              
                            <?php 
                              }
                            ?>
                             
                          
                            </select>
                          </div>
                          <!-- <input type="hidden" name="warehouse_id" id="warehouse_id" value="<?=$purchase->warehouse_id?>"> -->
                          <span id="err_warehouse_id" class="error invalid-feedback"><?=form_error('warehouse_id');?></span>
                        </div>
                      </div>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label for="supplier"><?=$this->lang->line('purchase_supplier')?><span class="validation-color">*</span>
                          </label>
                          <div class="input-group input-group-sm">
                            <select class="form-control form-control-sm select2bs4 field_validation" name="supplier_id" id="supplier_id" width="100%" class="add-row" placeholder="<?=$this->lang->line('purchase_supplier')?>">
                              <option value=""><?=$this->lang->line('select')?></option>
                              <?php
                                foreach ($supplier as $value) {
                              ?>
                                <option value="<?=$value->id;?>"
                                  <?php 
                                    if($value->id == $purchase->supplier_id)
                                      echo ' selected';
                                  ?>
                                >
                                  <?= $value->company_name;?>
                                </option>
                                
                              <?php 
                                }
                              ?>
                             
                          
                            </select>
                            <!-- <span class="input-group-append">
                              <button type="button" class="btn btn-info btn-flat" data-toggle="modal" data-target="#add_supplier_modal" data-tt="tooltip" accesskey="c"><i class="fas fa-plus"></i></button>
                            </span>
                          -->
                          </div>
                         
                          <input type="hidden" name="supplier_state_id" id="supplier_state_id" value="<?=$supplier_detail->state_id?>">
                          <input type="hidden" name="supplier_country_id" id="supplier_country_id" value="<?=$supplier_detail->country_id?>">
                          <span id="err_supplie_id" class="error invalid-feedback"><?=form_error('supplie_id');?></span>
                        </div>
                      </div>
                      
                    </div>

                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group">
                            <label><?=$this->lang->line('cdn_document')?></label>
                            <div class="input-group input-group-sm">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="upload_document" name="upload_document[]" accept=".pdf" multiple>
                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                </div>
                                <input type="hidden" value="<?= $purchase->document ?>" name="document[]" id="document">
                            </div>
                            <span id="fileTypeError" class="error-message"></span>
                            <?php
                              $document_filenames = explode(',', $purchase->document);
                              foreach ($document_filenames as $filename){
                                if($filename != ''){
                            ?>
                            <div class="btn-group attached-file" style="margin-top:5px; margin-left:5px;margin-right:5px;">
                                <a href="#" class="btn btn-default"><?=$filename?></a>
                                <button type="button" class="btn btn-danger deleteAttachedFile" data-filename="<?=$filename?>">X</button>
                            </div>
                            <?php
                                }
                              }
                            ?>

                        </div>
                      </div>
                    </div>
                    
                    <div class="row">
                      <div class="col-sm-12 ">
                        <div class="well">
                          <div class="row">
                            <div class="col-sm-12">
                              <a href="" data-toggle="modal" data-tt="tooltip" data-target="#add_product_modal" class="float-right add_product_modal"><?=$this->lang->line('purchase_add_new_product')?></a>
                            </div>
                            <div class="col-sm-12 search">
                              <span class="fa fa-search"></span>
                              <input id="search_product" class="form-control search_product"  type="text" name="search_product"  placeholder="<?=$this->lang->line('purchase_item_search')?>">
                            </div>
                            <div class="col-sm-8">
                              <span class="validation-color" id="err_product"></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" style="height: 20px;"></div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_items')?></label>
                          <table class="table items table-striped table-bordered table-condensed table-hover product_table" name="product_data" id="product_data">
                          
                          <thead>
                              <tr>
                                <th width="2%">
                                  <img src="<?php  echo base_url(); ?>assets/images/bin1.png" />
                                </th>
                                <th class="span2" width="13%"><?=$this->lang->line('product_description')?></th>
                                <th class="span2" width="7%"><?=$this->lang->line('purchase_qty')?></th>
                                <th class="span2 <?= (empty($promotion) || $promotion->field_status !== 'active') ? 'd-none' : '' ?>" width="10%"><?=$this->lang->line('proforma_invoice_free_qty')?></th>
                                <th class="span2 <?= (empty($batch_no) || $batch_no->field_status !== 'active') ? 'd-none' : '' ?>" width="12%"><?=$this->lang->line('purchase_batch_no')?></th>
                                <th class="span2" width="10%"><?=$this->lang->line('purchase_cost')?></th>
                                <th class="span2" width="10%"><?=$this->lang->line('product_selling_price')?></th>
                                <th class="span2" width="10%"><?=$this->lang->line('purchase_price')?></th>

                                <th class="span2 <?= (empty($mfg_date) || $mfg_date->field_status !== 'active') ? 'd-none' : '' ?>" width="10%">
                                  <?= $this->lang->line('product_mfg_date') ?>
                                </th>
                                <th class="span2 <?= (empty($expiry_date) || $expiry_date->field_status !== 'active') ? 'd-none' : '' ?>" width="10%">
                                  <?= $this->lang->line('product_expiry_date') ?>
                                </th>



                                <th class="span2" width="14%"><?=$this->lang->line('purchase_discount')?></th>
                                <th class="span2" width="6%"><?=$this->lang->line('purchase_uom')?></th>
                                <th class="span2" width="8%"><?=$this->lang->line('purchase_taxable_value')?></th>
                                <th class="span2" width="10%"><?=$this->lang->line('purchase_tax')?></th>
                                <th class="span2" width="5%"><?=$this->lang->line('purchase_inclusive')?></th>
                                <th class="span2" width="7%"><?=$this->lang->line('purchase_total')?></th>
                              </tr>
                            </thead>
                            <tbody id="product_table_body">
                              <?php 
                                foreach ($purchase_items as $row) {
                              ?>
                                <tr class="product_row">
                                  <td>
                                    <span class="delete_item"><i class="fas fa-minus-circle text-danger"></i>
                                    </span>
                                    <input type="hidden" name="product_id" value="<?=$row->product_id?>">
                                    <input type="hidden" name="igst_rate" value="<?=$row->igst?>">
                                    <input type="hidden" name="sgst_rate" value="<?=$row->sgst?>">
                                    <input type="hidden" name="cgst_rate" value="<?=$row->cgst?>">
                                  </td>

                                  <td>
                                    <span name="product_name"><?=$row->product_name?></span><br/>
                                    <span name="description"><?=$row->description?></span>
                                  </td>

                                
                                  
                                  <td>
                                    <input type="number" class="form-control" name="quantity" value="<?=$row->quantity?>" step="1" min="1">
                                    <span name="quantity_update_message" class="quantity_update_message"></span>
                                  </td>

                                  <td <?= (empty($promotion)) ? 'class="d-none"' : '' ?>>
                                      <input type="number" class="form-control" name="free_quantity" value="<?= (empty($promotion)) ? '0.00' : ($row->free_quantity) ?>" step="0.01" min="0.00">
                                    </td>

                                  <td <?= (empty($batch_no)) ? 'class="d-none"' : '' ?>>
                                      <input type="text" list="batch_no_<?=$row->product_id?>" class="form-control batch_no_list" name="batch_no" value="<?=$row->batch_no?>" autocomplete="off" required>
                                      <datalist class="batch_datalist" id="batch_no_<?=$row->product_id?>">
                                        <?php 
                                          $batch_nos = $this->warehouse_products_model->get_batch_nos_by_product_id($row->product_id);
                                          foreach ($batch_nos as $value) {
                                        ?>    
                                            <option value="<?=$value->batch_no?>" data-cost="<?=$value->cost?>" data-price="<?=$value->price?>" data-selling_price="<?=$value->selling_price?>">
                                        <?php 
                                          }
                                        ?>
                                      </datalist>
                                    </td>
                                  
                                  <td>
                                    <span id="cost_span">
                                      <input type="number" class="form-control text-right" name="cost" step="0.01" value="<?=$row->cost?>" min="1">
                                    </span>
                                  </td>

                                  <td>
                                      <span id="selling_price_span">
                                        <input type="number" class="form-control text-right" name="selling_price" step="0.01" value="<?=$row->selling_price?>" min="1">
                                      </span>
                                    </td>

                                  <td>
                                    <span id="cost_span">
                                      <input type="number" class="form-control text-right" name="price" step="0.01" value="<?=$row->price?>" min="1">
                                    </span>
                                  </td>

                                  <td <?= (empty($mfg_date)) ? 'class="d-none"' : '' ?>>
                                      <input type="text" class="form-control datepicker" name="mfg_date" value="<?= (empty($mfg_date)) ? '' : (($row->mfg_date != '' && $row->mfg_date != '0000-00-00') ? date('d-m-Y', strtotime($row->mfg_date)) : '') ?>" autocomplete="off">
                                  </td>

                                  <td <?= (empty($expiry_date)) ? 'class="d-none"' : '' ?>>
                                      <input type="text" class="form-control datepicker" name="expiry_date" value="<?= (empty($expiry_date)) ? '' : (($row->expiry_date != '' && $row->expiry_date != '0000-00-00') ? date('d-m-Y', strtotime($row->expiry_date)) : '') ?>" autocomplete="off">
                                  </td>

                                  
                                  <td>
                                    <select class="form-control select2bs4" name="item_discount" style="width: 100%;">
                                      <option value="">Select</option>
                                      <?php 
                                        foreach ($discounts as $value) {
                                      ?>
                                        <option value="<?=$value->id?>"
                                          <?php 
                                            if($value->id == $row->discount_id)
                                              echo ' selected';
                                          ?>
                                        >
                                          <?=$value->name.' ('.$value->value.$this->session->userdata('currency_symbol').')' ?>
                                        </option>
                                      <?php
                                        }
                                      ?>
                                      </option>
                                    </select>
                                    <span name="span_discount_type" class="discount_type">Discount Value :  <?=$this->session->userdata('currency_symbol')?> </span>
                                    <input type="hidden" name="discount_type" value="<?=$row->discount_type?>">
                                    <span name="discount_amount" class="discount_amount"><?=$row->discount_amount?></span>
                                    <input type="hidden" name="discount_value" value="<?=$row->discount_value?>">
                                  </td>
                                  <td>
                                    <input type="hidden" name="uom_id" value="<?=$row->uom_id?>" data-uom_name="<?=$row->uom_name?>" data-uom_uom="<?=$row->uom_uom?>">  
                                    <?=$row->uom_uom?>
                                  </td>
                                  
                                  
                                  <td><span name="taxable_value"><?=$row->taxable_value?></span></td>
                                  
                                  <td class="tax_td">
                                    <?php 
                                      if($company_setting->country_id == $supplier_detail->country_id)
                                      {
                                        if($company_setting->state_id == $supplier_detail->state_id)
                                        {
                                    ?>
                                          <input type="hidden" name="tax_id" value="<?=$row->tax_id?>">CGST : <span name="c_tax"><?=$row->cgst_tax?></span>
                                          (<span name="cgst"><?=$row->cgst?></span>)
                                          <br>SGST : <span name="s_tax"><?=$row->sgst_tax?></span>
                                          (<span name="sgst"><?=$row->sgst?></span>)
                                          <span name="i_tax" style="display:none"><?=$row->igst_tax?></span>
                                          <span name="igst" style="display:none"><?=$row->igst?></span>
                                    <?php
                                        }
                                        else
                                        {
                                    ?>
                                          <input type="hidden" name="tax_id" value="<?=$row->tax_id?>">IGST : <span name="i_tax"><?=$row->igst_tax?></span>
                                          (<span name="igst"><?=$row->igst?></span>)
                                          <span name="c_tax" style="display:none"><?=$row->cgst_tax?></span>
                                          <span name="cgst" style="display:none"><?=$row->cgst?></span>
                                          <span name="s_tax" style="display:none"><?=$row->sgst_tax?></span>
                                          <span name="sgst" style="display:none"><?=$row->sgst?></span>
                                    <?php 
                                        }
                                      }
                                      else
                                      {
                                    ?>
                                        N/A
                                        <input type="hidden" name="tax_id" value="1">
                                        <span name="c_tax" style="display:none"><?=$row->cgst_tax?></span>
                                        <span name="cgst" style="display:none"><?=$row->cgst?></span>
                                        <span name="s_tax" style="display:none"><?=$row->sgst_tax?></span>
                                        <span name="sgst" style="display:none"><?=$row->sgst?></span>
                                        <span name="i_tax" style="display:none"><?=$row->igst_tax?></span>
                                        <span name="igst" style="display:none"><?=$row->igst?></span>
                                    <?php
                                      }
                                    ?>
                                    
                                  </td>
                                  
                                  <td>
                                    <input type="hidden" name="tax_type" value="<?=$row->tax_type?>">
                                    <?=($row->tax_type == 0) ? 'No' : 'Yes';?>
                                  </td>
                                  
                                  <td><span name="subtotal"><?=$row->subtotal?></span></td>
                                </tr>
                              <?php 
                                }
                              ?>
                            </tbody>
                          </table>
                          <table class="table table-striped table-bordered table-condensed table-hover total_data" style="font-size: 18px;">
                            <tr>
                              <td align="right" colspan="7"> <?=$this->lang->line('purchase_total_discount')?>(<?=$currency?>)</td>
                              <td align='right' class="text-danger">
                                -<span id="total_discount"><?=$purchase->total_discount?></span>
                                <input type="hidden" name="total_discount" id="t_discount" value="<?=$purchase->total_discount?>">
                              </td>
                            </tr>
                            <tr>
                              <td align="right" colspan="7"><?=$this->lang->line('purchase_total_taxable_value')?>(<?=$currency?>)</td>
                              <td align='right' class="text-success">
                                +<span id="total_taxable_value"><?=$purchase->total_taxable_value?></span>
                                <input type="hidden" name="total_taxable_value" id="t_taxable_value" value="<?=$purchase->total_taxable_value?>">
                              </td>
                            </tr>
                            
                            <tr>
                              <td align="right" colspan="7"><?=$this->lang->line('purchase_total_tax')?>(<?=$currency?>)</td>
                              <td align='right' class="text-success">
                                +<span id="total_tax"><?=$purchase->total_tax?></span>
                                <input type="hidden" name="total_tax" id="t_tax" value="<?=$purchase->total_tax?>">
                              </td>
                            </tr>
                            <tr>
                              <td align="right" colspan="7"><?=$this->lang->line('purchase_total')?>(<?=$currency?>)</td>
                              <td align='right'>
                                <span id="total"><?=$purchase->total?></span>
                                <input type="hidden" name="total" id="t" value="<?=$purchase->total?>">
                              </td>
                            </tr>
                          </table>

                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="control-group">                     
                          <div class="controls">
                            <div class="tabbable">
                              <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                                <li class="nav-item">
                                  <a class="nav-link active" href="#external_note" data-toggle="pill"><?php echo $this->lang->line('purchase_external_note'); ?></a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#internal_note" data-toggle="pill"><?php echo $this->lang->line('purchase_internal_note'); ?></a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#bank_detail" data-toggle="pill"><?php echo $this->lang->line('purchase_bank_detail'); ?></a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#terms_and_condition" data-toggle="pill"><?php echo $this->lang->line('purchase_terms_and_condition'); ?></a>
                                </li>
                              </ul>                           
                              <br>
                              <div class="tab-content">
                                <div class="tab-pane active" id="external_note">
                                  <textarea class="col-sm-12 form-control" name="external_note" rows="4" placeholder="<?php echo $this->lang->line('purchase_external_note'); ?>"><?=str_replace("<br />","",$purchase->external_note)?></textarea>
                                </div>
                                <div class="tab-pane" id="internal_note">
                                  <textarea class="col-sm-12 form-control" name="internal_note" rows="4" placeholder="<?php echo $this->lang->line('purchase_internal_note'); ?>"><?=str_replace("<br />","",$purchase->internal_note)?></textarea>
                                </div>
                                <div class="tab-pane" id="bank_detail">
                                  <textarea class="col-sm-12 form-control" name="bank_detail" rows="4" placeholder="<?php echo $this->lang->line('purchase_bank_detail'); ?>"><?=str_replace("<br />","",$purchase->bank_detail)?></textarea>
                                </div>
                                <div class="tab-pane" id="terms_and_condition">
                                  <textarea class="col-sm-12 form-control" name="terms_and_condition" rows="4" placeholder="<?php echo $this->lang->line('purchase_terms_and_condition'); ?>"><?=str_replace("<br />","",$purchase->terms_and_condition)?></textarea>
                                </div>
                              </div>
                            </div>   
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-footer">
                  <input type="hidden" name="id" value="<?=$purchase->id?>">
                  <input type="hidden" name="purchase_items" id="purchase_items" value="">
                  <input type="hidden" name="company_state_id" id="company_state_id" value="<?=$company_setting->state_id?>">
                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                  <input type="hidden" name="company_country_id" id="company_country_id" value="<?=$company_setting->country_id?>">
                  <button type="submit" name="submit" id="purchaseSubmit" class="btn btn-info"><?=$this->lang->line('purchase_add')?></button>
                  <!-- <button type="submit" name="submit" id="purchaseSubmitPayNow" value="pay" name="pay" class="btn btn-info">Add purchase & Pay Now</button>                      -->
                  <span class="btn btn-default float-right" id="cancel" onclick="cancel('purchase')"><?=$this->lang->line('purchase_cancel')?></span>
                </div>
            </form>
          </div>
        </div>
      </section>
  
    </div>
    <aside class="control-sidebar control-sidebar-dark"></aside>
  </div>

<?php 
  $this->load->view('layout/footer');
  /*$this->load->view('supplier/add_supplier_modal');
  $this->load->view('warehouse/add_warehouse_modal');*/
?>

<div class="modal fade" id="emptyPurchaseItemWarningModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header warning-header">
        <h5 class="modal-title" id="exampleModalLabel">Message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        There are no item(s) in Invoice. Please atleast 1 item in invoice.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="example-modal">
  <div class="modal fade" id="add_product_modal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div>

<div class="example-modal">
  <div class="modal fade" id="add_product_category_modal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
      </div>
      <!-- /.modal-content -->
    </div>
      <!-- /.modal-dialog -->
  </div>
</div>

<div class="example-modal">
  <div class="modal fade" id="add_tax_modal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
      </div>
      <!-- /.modal-content -->
    </div>
      <!-- /.modal-dialog -->
  </div>

<div class="example-modal">
  <div class="modal fade" id="reset_model" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header secondary-header">
          <h4 class="modal-title">
            Reset Purchase
          </h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>
            <?php echo "Are you sure want to reset this purchase ?";?>
          </p>
        </div>
        <div class="modal-footer">
            
          <button type="button" class="btn btn-default" data-dismiss="modal">
            <?php echo $this->lang->line('btn_modal_close');?>
          </button>
        
          <button type="submit" name="resetSubmit" id="resetSubmit" class="btn btn-secondary" value="">Reset</button>
         
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/disableautofill/src/jquery.disableAutoFill.min.js"></script>

<script type="text/javascript">

  $(document).ready(function(e){

     const product_categoryToast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 10000
    });

    const productToast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 10000
    });

    const taxToast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 10000
    });

    $(document).on('click', "#resetSubmit" ,function(e){
      e.preventDefault();

      $('span.delete_item').trigger('click');
       
      $('#supplier_id').val('');

      $('#supplier_id').trigger('change');
      $('#reset_model').modal('hide');
   
    });


    $(document).on('click', ".reset" ,function(){
      $('#reset_model').modal('show');
    });


    $(document).on('click', ".add_product_modal" ,function(){
   
      $.ajax({
      url: "<?php echo base_url('product_core/add')?>",
        type: "GET",
        dataType: "JSON",
        success: function(data){
          $('#add_product_modal').find('.modal-content').html(data.add_product_modal_body);
          $('#add_product_modal').modal('show');

          $('.select2bs4').select2({
            theme: 'bootstrap4'
          });
        },
        error: function (xhr, ajaxOptions, thrownError) {
          alert(xhr.status);
          alert(thrownError);
          alert(ajaxOptions);
        }
      });
    });


    $(document).on('submit','#addProductForm',function(e){
      
      e.preventDefault();

      $('#addProductSubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');
      var formData = $('#addProductForm').serialize();

      var isError = false;

      $('form#addProductForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#addProductForm  #err_"+id).text(field+ " field is required.");
            $('form#addProductForm  #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#addProductForm #err_"+id).text("");
            $('form#addProductForm #'+id).removeClass('is-invalid');
            $('form#addProductForm #'+id).addClass('is-valid');
          }

      });

      if(isError == true)
      {
        $('#addProductSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
        return false;
      }
      else
      {
        $.ajax({
        url: "<?php echo base_url('product/add')?>",
          type: "POST",
          data: formData,
          dataType: "JSON",
          success: function(response){
            if(response.code==1)
            { 
            $('#add_product_modal').modal('hide');
              $('form#addProductForm #addProductSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
              //////initialize_datatable();

              productToast.fire({
                type: 'success',
                title: response.message
              });
            }
            else
            {
              productToast.fire({
                type: 'error',
                title: response.message
              });
              $('#addProductSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
            }
          }
        });
      }
      
    });

    $(document).on("blur change keyup", "form#addProductForm  .field_validation", function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#addProductForm #err_"+id).text(field+ " field is required.");
          $('form#addProductForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#addProductForm #err_"+id).text("");
          $('form#addProductForm #'+id).removeClass('is-invalid');
          $('form#addProductForm #'+id).addClass('is-valid');
        }
    });

    $(document).on('click', ".add_product_category_modal" ,function(){

     $.ajax({
        url: "<?php echo base_url('product_category/add')?>",
        type: "GET",
        dataType: "JSON",
        success: function(data){
          $('#add_product_category_modal').find('.modal-content').html(data.add_product_category_modal_body);
          $('#add_product_category_modal').modal('show');

          $('.select2bs4').select2({
            theme: 'bootstrap4'
          });
        },
        error: function (xhr, ajaxOptions, thrownError) {
          alert(xhr.status);
          alert(thrownError);
          alert(ajaxOptions);
        }
      });
    });

    $(document).on('submit','#addProduct_categoryForm',function(e){
      
      e.preventDefault();

      $('#addProduct_categorySubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');
      var formData = $('#addProduct_categoryForm').serialize();

      var isError = false;

      $('form#addProduct_categoryForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#addProduct_categoryForm  #err_"+id).text(field+ " field is required.");
            $('form#addProduct_categoryForm  #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#addProduct_categoryForm #err_"+id).text("");
            $('form#addProduct_categoryForm #'+id).removeClass('is-invalid');
            $('form#addProduct_categoryForm #'+id).addClass('is-valid');
          }

      });

      if(isError == true)
      {
        $('#addProduct_categorySubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
        return false;
      }
      else
      {
        $.ajax({
        url: "<?php echo base_url('product_category/add')?>",
          type: "POST",
          data: formData,
          dataType: "JSON",
          success: function(response){
            if(response.code==1)
            { 
            $('#add_product_category_modal').modal('hide');
              $('form#addProduct_categoryForm #addProduct_categorySubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
             /* initialize_datatable();*/
              if($('form#addProductForm #product_category_id').length)
              {
                $('form#addProductForm #product_category_id').html('');
                $('form#addProductForm #product_category_id').append('<option value="">Select</option>');
                
                for(i=0;i<response['product_categories'].length;i++)
                { 
                  $('form#addProductForm #product_category_id').append('<option value="' + response['product_categories'][i].id + '">' + response['product_categories'][i].name +'</option>');
                }

                $('form#addProductForm #product_category_id').val(response['id']).attr("selected","selected");


                product_categoryToast.fire({
                  type: 'success',
                  title: response.message
                });
              }
              else
              {
                // show_message('success-header',response.message);
                product_categoryToast.fire({
                  type: 'success',
                  title: response.message
                });  

                location.reload(true);
              }
            }
            else
            {
              product_categoryToast.fire({
                type: 'error',
                title: response.message
              });
              $('#addProduct_categorySubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
            }
          }
        });
      }
      
    });

    $(document).on('click', ".add_tax_modal" ,function(){

     $.ajax({
        url: "<?php echo base_url('tax/add')?>",
        type: "GET",
        dataType: "JSON",
        success: function(data){
          $('#add_tax_modal').find('.modal-content').html(data.add_tax_modal_body);
          $('#add_tax_modal').modal('show');

          $('.select2bs4').select2({
            theme: 'bootstrap4'
          });
        },
        error: function (xhr, ajaxOptions, thrownError) {
          alert(xhr.status);
          alert(thrownError);
          alert(ajaxOptions);
        }
      });
    });


    $(document).on('submit','#addTaxForm',function(e){
      
      e.preventDefault();

      $('#taxSubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');
      var formData = $('#addTaxForm').serialize();

      var isError = false;

      $('form#addTaxForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#addTaxForm  #err_"+id).text(field+ " field is required.");
            $('form#addTaxForm  #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#addTaxForm #err_"+id).text("");
            $('form#addTaxForm #'+id).removeClass('is-invalid');
            $('form#addTaxForm #'+id).addClass('is-valid');
          }

      });

      if(isError == true)
      {
        var formData = $('#addTaxForm').serialize();
        $('#taxSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
        return false;
      }
      else
      {
        $.ajax({
        url: "<?php echo base_url('tax/add')?>",
          type: "POST",
          data: formData,
          dataType: "JSON",
          success: function(response){
            if(response.code==1)
              {
                $('#add_tax_modal').modal('hide');
                /*$('#add_product_category_modal').modal('hide');*/
                $('#taxSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
                
                if($('form#addProduct_categoryForm #tax_id').length)
                {
                  $('form#addProduct_categoryForm #tax_id').html('');
                  $('form#addProduct_categoryForm #tax_id').append('<option value="">Select</option>');
                  
                  for(i=0;i<response['taxes'].length;i++)
                  { 
                    $('form#addProduct_categoryForm #tax_id').append('<option value="' + response['taxes'][i].id + '">' + response['taxes'][i].tax_name + ' ( I : ' + response['taxes'][i].igst + ' | C : ' +response['taxes'][i].cgst + ' | S : ' + response['taxes'][i].sgst + ' ) ' +'</option>');

                    /*<?=$value->tax_name.' ( I : '.$value->igst.' | C : '.$value->cgst.' | S : '.$value->sgst.' )'?>*/
                  }

                  $('form#addProduct_categoryForm #tax_id').val(response['id']).attr("selected","selected");  

                  // show_message('success-header',response.message);
                  TaxToast.fire({
                    type: 'success',
                    title: response.message
                  });  

                }
                else
                {
                  // show_message('success-header',response.message);
                  TaxToast.fire({
                    type: 'success',
                    title: response.message
                  });  

                  location.reload(true);
                }
              }
            else
            {
              TaxToast.fire({
                type: 'error',
                title: response.message
              });
              $('#taxSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
            }
          }
        });
      }
      
    });

    $(document).on("blur change keyup", "form#addTaxForm  .field_validation", function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#addTaxForm #err_"+id).text(field+ " field is required.");
          $('form#addTaxForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#addTaxForm #err_"+id).text("");
          $('form#addTaxForm #'+id).removeClass('is-invalid');
          $('form#addTaxForm #'+id).addClass('is-valid');
        }
    });



      $('#warehouse_id').change(function(e){

        var warehouse_id = $(this).val();
        if(warehouse_id != '')
        {
          if($('#supplier_id').val() != '')
          {
            $("#warehouse_id").closest('.row').siblings().fadeIn(10);
          }

          $.ajax({
              url: "<?php echo base_url('warehouse/get_record_details') ?>",
              type: "POST",
              dataType: "json",
              data: {
                  'warehouse_id' : warehouse_id,
                  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
              },
              success: function(data){
                var warehouse = data.warehouse;
                // $("#product_table_body tr").remove();
                // calculateGrandTotal();
                refresh_tax_td();

              }
          });
        }
        else
        {
          $("#warehouse_id").closest('.row').siblings().css('display','none');
        }
      });

      $('#supplier_id').change(function(e){

        var supplier_id = $(this).val();
        if(supplier_id != '')
        {
          if($('#warehouse_id').val() != '')
          {
            $("#supplier_id").closest('.row').siblings().fadeIn(10);  
          }

          $.ajax({
              url: "<?php echo base_url('supplier/get_record_detail') ?>",
              type: "POST",
              dataType: "json",
              data: {
                  'supplier_id' : supplier_id,
                  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
              },
              success: function(data){
                var supplier = data.supplier;

                var futureDate = data.futureDate;

                $('#due_date').val(futureDate);
                $('#supplier_state_id').val(supplier.state_id);
                $('#supplier_country_id').val(supplier.country_id);
                $('#supplier_gstin').val(supplier.gstin);
                // $('#supplier_id').val(supplier.id);

                refresh_tax_td();
              
                // $("#product_table_body tr").remove();
                // calculateGrandTotal();
              }
          });
        }
        else
        {
          $("#supplier_id").closest('.row').siblings().css('display','none');
        }
      }); 

      function refresh_tax_td()
      {
        var company_country_id  = $('#company_country_id').val();
        var company_state_id    = $('#company_state_id').val();
        var supplier_state_id   = $('#supplier_state_id').val();
        var supplier_country_id = $('#supplier_country_id').val();
        
        $("#product_table_body").find('tr').each(function () {
          var tr              = $(this).closest("tr");
          var tax_td          = tr.find('.tax_td');
          // var igst            = parseFloat(tax_td.find('span[name="igst"]').text());
          // var cgst            = parseFloat(tax_td.find('span[name="cgst"]').text());
          // var sgst            = parseFloat(tax_td.find('span[name="sgst"]').text());

          var igst            = 0;
          var cgst            = 0;
          var sgst            = 0;

          if(company_country_id == supplier_country_id)
          {
            if(company_state_id == supplier_state_id)
            {
              cgst        = parseFloat(tax_td.find('input[name^="cgst_rate"]').val());
              sgst        = parseFloat(tax_td.find('input[name^="sgst_rate"]').val());
            }
            else
            {
              igst        = parseFloat(tax_td.find('input[name^="igst_rate"]').val());
            }  
          }

          var tax_rate        = igst+cgst+sgst;

          var igst            = tax_rate;
          var cgst            = (parseFloat(tax_rate/2)).toFixed(2);
          var sgst            = (parseFloat(tax_rate/2)).toFixed(2);

        

          var tax_id          = tax_td.find('input[name="tax_id"]').val();
          var tax             = '<input type="hidden" name="tax_id" value="'+tax_id+'">';

          if(company_country_id == supplier_country_id)
          { 
            if(company_state_id == supplier_state_id)
            {
              tax += 'CGST : <span name="c_tax">'+0.0+'</span>(<span name="cgst">'+cgst+'</span>)<br/>';
              tax += 'SGST : <span name="s_tax">'+0.0+'</span>(<span name="sgst">'+sgst+'</span>)';
              tax += '<span name="i_tax"style="display:none">0</span><span name="igst" style="display:none">0</span>';
            }
            else
            {
              tax += 'IGST : <span name="i_tax">'+0.0+'</span>(<span name="igst">'+igst+'</span>)<br/>';
              tax += '<span name="c_tax" style="display:none">0</span><span name="cgst" style="display:none">0</span>';
              tax += '<span name="s_tax" style="display:none">0</span><span name="sgst" style="display:none">0</span>';
            }  
          }
          else
          {
            tax += 'N/A'; 
            tax += '<span name="i_tax" style="display:none">0</span><span name="igst" style="display:none">0</span>';
            tax += '<span name="c_tax" style="display:none">0</span><span name="cgst" style="display:none">0</span>';
            tax += '<span name="s_tax" style="display:none">0</span><span name="sgst" style="display:none">0</span>'; 
          }


          tax_td.html(tax);
          calculateRow(tr);
          calculateGrandTotal();
        });
      }

      // product search code begin

      var c_mapping = { };

      $(function(){
        $('#search_product').autoComplete({
          minChars: 1,
          source: function(term, suggest){
            term = term.toLowerCase();

            $.ajax({
              url: "<?php echo base_url('product/search') ?>",
              type: "POST",
              dataType: "json",
              data:{
                'term': term,
                'module': '<?=PURCHASE_MODULE?>',
                '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
              },
              success: function(data){
                var products = data;
                var suggestions = [];
                for(var i = 0; i < products.length; ++i) {
                    suggestions.push(products[i].id+' - '+products[i].name+' - '+products[i].product_category_name);
                    c_mapping[products[i].id] = products[i].name;
                }
                suggest(suggestions);
              }
            });
          },
          onSelect: function(event, ui) {
            var str = ui.split(' - ');
            
            var product_id = str[0];

            $.ajax({
              url: "<?php echo base_url('product/get_record_detail') ?>",
              type: "POST",
              dataType: "json",
              data:{
                'product_id': product_id, 
                'module': '<?=PURCHASE_MODULE?>',
                '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
              },
              success: function(data){
                var product = data.product;

                if(!is_product_exist_in_row(product.id))
                {
                  add_row(data);
                }
                else
                {
                  highlight_row(product.id);
                }

                calculateGrandTotal();
                $('#search_product').val('');
              }
            });
          } 
        });
      });

      

      function add_row(data)
      {
        var supplier_country_id = $('#supplier_country_id').val();
        var supplier_state_id   = $('#supplier_state_id').val();
        var supplier_gstin      = $('#supplier_gstin').val();

        var company_country_id  = $('#company_country_id').val();
        var company_state_id    = $('#company_state_id').val();
        var company_gstin       = '<?=$company_setting->gstin?>';
        var warehouse_id        = $('#warehouse_id').val();

        var product   = data.product;
        var discounts = data.discount;
        var uqc       = data.uqc;

        var select_discount = "";
            select_discount += '<select class="form-control select2bs4" name="item_discount" style="width: 100%;">';
            select_discount += '<option value="">Select</option>';
              for(a=0;a<discounts.length;a++)
              {
                var type_symbol;
                if(discounts[a].type == 0)
                {
                  type_symbol = "<?=$this->session->userdata('currency_symbol')?>";
                }
                else
                {
                  type_symbol = "%"; 
                }
                select_discount += '<option value="' + discounts[a].id + '">' + discounts[a].name+'('+discounts[a].value  + type_symbol +')'+ '</option>';
              }
            select_discount += '</select>'
            select_discount += '<span name="span_discount_type" class="discount_type">Discount Value :  <?=$this->session->userdata('currency_symbol');?> </span><input type="hidden" name="discount_type" value="0">';
            select_discount += '<span name="discount_amount" class="discount_amount">0.0</span><input type="hidden" name="discount_value" value="'+0+'">';

        var input_uom = '<input type="hidden" name="uom_id" value="'+product.uom_id+'" data-uom_name="'+product.uom_name+'" data-uom_uom="'+product.uom_uom+'">'+product.uom_uom;

        var input_quantity =  '<input type="number" class="form-control" name="quantity" value="1" step="1" min="1"><span name="quantity_update_message" class="quantity_update_message"></span>';
        var taxable_value  =  '<span name="taxable_value">'+product.cost+'</span>';

        /************    tax begin   *****************/
        var tax = '<input type="hidden" name="tax_id" value="'+product.tax_id+'">';

        // alert(company_state_id);
        // alert(warehouse_state_id);

        if(company_country_id == supplier_country_id)
        {
          if(company_state_id == supplier_state_id)
          {
            tax += 'CGST : <span name="c_tax">'+0.0+'</span>(<span name="cgst">'+product.cgst+'</span>)<br/>';
            tax += 'SGST : <span name="s_tax">'+0.0+'</span>(<span name="sgst">'+product.sgst+'</span>)';
            tax += '<span name="i_tax"style="display:none">0</span><span name="igst" style="display:none">0</span>';
          }
          else
          {
            tax += 'IGST : <span name="i_tax">'+0.0+'</span>(<span name="igst">'+product.igst+'</span>)<br/>';
            tax += '<span name="c_tax" style="display:none">0</span><span name="cgst" style="display:none">0</span>';
            tax += '<span name="s_tax" style="display:none">0</span><span name="sgst" style="display:none">0</span>';
          }  
        }
        else if((company_country_id != supplier_country_id))
        {
            tax += 'N/A';
            tax += '<span name="i_tax" style="display:none">0</span><span name="igst" style="display:none">0</span>';
            tax += '<span name="c_tax" style="display:none">0</span><span name="cgst" style="display:none">0</span>';
            tax += '<span name="s_tax" style="display:none">0</span><span name="sgst" style="display:none">0</span>';
        }


        /************    tax end   *****************/

        /************    tax type begin   *****************/

        var tax_type  = '<input type="hidden" name="tax_type" value="'+product.tax_type+'">';
        tax_type      += (product.tax_type == 0) ? "No" : "Yes";

        /************    tax type end   *****************/

        var free_quantity =  '<input type="number" class="form-control" name="free_quantity" min="0.00" value="0" step="0.01">';

        var batch_nos = data.batch_nos;

        var generated_batch_no = get_batch_no(product.cost,product.selling_price,product.price,product.id,warehouse_id);

        var newRow = $('<tr class="product_row">');
            var cols = "";

            cols += '<td>'
                      + '<span class="delete_item"><i class="fas fa-minus-circle text-danger"></i></span>'
                      + '<input type="hidden" name="product_id" value="'+product.id+'">' 
                      + '<input type="hidden" name="igst_rate" value="'+product.igst+'">'
                      + '<input type="hidden" name="cgst_rate" value="'+product.cgst+'">'
                      + '<input type="hidden" name="sgst_rate" value="'+product.sgst+'">'
                    +'</td>';
            cols += '<td><span name="product_name">'+product.name+'</span><br/><span name="description">'+product.description+'</span></td>';
            cols += '<td>'+input_quantity+'</td>';
            cols += '<td class="<?php echo empty($promotion) ? 'd-none' : ''; ?>">'+free_quantity+'</td>';
           // cols += '<td><input type="text" name="batch_no" value="" class="form-control"></td>';
            
            cols += '<td class="<?php echo empty($batch_no) ? 'd-none' : ''; ?>"><input type="text" list="batch_no_'+product.id+'" name="batch_no" id="batch_no" value="'+generated_batch_no+'" class="form-control batch_no_list" autocomplete="off" required>';
            cols +=   '<datalist class="batch_datalist" id="batch_no_'+product.id+'">';

                          for (var i=0; i < batch_nos.length; i++) 
                          { 
            cols +=         '<option value="'+batch_nos[i].batch_no+'" data-price="'+batch_nos[i].price+'" data-cost="'+batch_nos[i].cost+'" data-selling_price="'+batch_nos[i].selling_price+'">';
                          }
                   
            cols +=   '</datalist>';
            cols += '</td>';
            cols += '<td>' 
                      +'<span id="cost_span">'
                        +'<input type="number" class="form-control text-right" name="cost" step="0.01" value="'+product.cost+'" min="1">'
                        +'<input type="hidden" class="form-control text-right" name="hidden_cost" step="0.01" value="'+product.cost+'" min="1">'
                      +'</span>'
                    +'</td>';
            cols += '<td>' 
                      +'<span id="selling_price_span">'
                        +'<input type="number" class="form-control text-right" name="selling_price" step="0.01" value="'+product.selling_price+'" min="1">'
                        +'<input type="hidden" class="form-control text-right" name="hidden_selling_price" step="0.01" value="'+product.selling_price+'" min="1">'
                      +'</span>'
                    +'</td>';
            cols += '<td>' 
                      +'<span id="price_span">'
                        +'<input type="number" class="form-control text-right" name="price" step="0.01" value="'+product.price+'" min="1">'
                        +'<input type="hidden" class="form-control text-right" name="hidden_price" step="0.01" value="'+product.price+'" min="1">'
                      +'</span>'
                    +'</td>';

            cols += '<td class="<?php echo empty($mfg_date) ? 'd-none' : ''; ?>">'
                      +'<input type="text" name="mfg_date" value="" class="form-control datepicker" autocomplete="off">'
                    +'</td>';

            cols += '<td class="<?php echo empty($expiry_date) ? 'd-none' : ''; ?>">'
                      +'<input type="text" name="expiry_date" value="" class="form-control datepicker" autocomplete="off">'
                    +'</td>';


            cols += '<td>'+select_discount+'</td>';
            cols += '<td>'+input_uom+'</td>';
            cols += '<td>'+taxable_value+'</td>';
            cols += '<td class="tax_td">'+tax+'</td>';
           
            cols += '<td>'+tax_type+'</td>';
            cols += '<td><span name="subtotal"></span></td>';
            cols += '</tr>';

            newRow.append(cols);
            $("table.product_table").append(newRow);
            $('.select2bs4').select2({theme: 'bootstrap4'});

            calculateRow(newRow);
      }

      function get_batch_no(cost, selling_price, price, product_id, warehouse_id)
      {
        var batch_no = '';

        if(!empty(<?=$batch_no?>))
          batch_no = generate_batch_no(cost,selling_price,price,product_id,warehouse_id);

        return batch_no;
      }

      function generate_batch_no(cost, selling_price, price,product_id,warehouse_id) 
      {
        // Remove the decimal points by converting each price to a string and replacing the dot
        var strCost = cost.toString().replace('.', '');
        var strSellingPrice = selling_price.toString().replace('.', '');
        var strPrice = price.toString().replace('.', '');

        // Concatenate the strings
        var concatenatedString = strCost + strSellingPrice + strPrice + product_id+warehouse_id;

        return concatenatedString;
      }   

      $(document).on('change', '.batch_no_list', function (e) {

        var batch_no = $(this).val();
        var datalist = $(this).get(0).list;

        var isBatchFromList = false; // Flag to track if the batch number is from the list

        $(datalist).find('option').each(function () {
          // Compare the option value with the value to compare
          if ($(this).val() == batch_no) {
            var row = $(this).closest("tr");
            row.find('input[name="price"]').val($(this).data('price')).prop('readonly', true);
            row.find('input[name="selling_price"]').val($(this).data('selling_price')).prop('readonly', true);
            row.find('input[name="cost"]').val($(this).data('cost')).prop('readonly', true);
            isBatchFromList = true;
            return false;
          }
        });

        if (!isBatchFromList) {
          var row = $(this).closest("tr");
          var productCost = parseFloat(row.find('input[name="hidden_cost"]').val());
          var productPrice = parseFloat(row.find('input[name="hidden_price"]').val());
          var productSellingPrice = parseFloat(row.find('input[name="hidden_selling_price"]').val());

          row.find('input[name="cost"]').val(productCost).prop('readonly', false);
          row.find('input[name="price"]').val(productPrice).prop('readonly', false);
          row.find('input[name="selling_price"]').val(productSellingPrice).prop('readonly', false);
        }
      });

      function is_product_exist_in_row(product_id)
      {
        var isproductExist = false;
        $("#product_table_body").find('tr').each(function () {

          var tr = $(this).closest("tr");

          if(tr.find('input[name^="product_id"]').val() == product_id)
          {
            isproductExist = true;
          }
        });

        return isproductExist;
      }

      function highlight_row(product_id)
      {
        $("#product_table_body").find('tr').each(function () {
          var tr  = $(this).closest("tr");

          if(tr.find('input[name^="product_id"]').val() == product_id)
          {
            tr.addClass('highlight_row');

            var existing_quantity = +tr.find('input[name^="quantity"]').val();
            // alert(existing_quantity + 1);
            tr.find('input[name^="quantity"]').val(existing_quantity + 1).trigger('change');
            tr.find('span[name^="quantity_update_message"]').text('+1');

            setTimeout(function(){
              tr.removeClass('highlight_row');
              tr.find('span[name^="quantity_update_message"]').text('');
            },3000);
          }
        });        
      }

      $("table.product_table").on('change', 'input[name^="cost"], input[name^="quantity"], select[name^="item_discount"]', function (event) {

        if($(this).attr('name') == 'item_discount')
        {
          var discount_id = $(this).val();
          var tr          = $(this).closest('tr');

          $.ajax({
            url: "<?php echo base_url('discount/get_record_detail') ?>",
            type: "POST",
            dataType: "json",
            data:{
              'discount_id' : discount_id,
              '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            success: function(data){
              var discount = data.discount;
              var discount_type = '';

              tr.find('input[name^="discount_type"]').val(discount.type);
              tr.find('input[name^="discount_value"]').val(discount.value);
              
              calculateRow(tr);
              calculateGrandTotal();
            }
          });  
        }
        else
        {
          calculateRow($(this).closest("tr"));
          calculateGrandTotal();
        }
       });
      
      $('table.product_table').on('click',"span.delete_item", function(e){

        var tr = $(this).closest('tr');
        tr.remove();
        calculateGrandTotal();
      });

      function calculateRow(row)
      {
        var tax_type    = row.find('input[name^="tax_type"]').val();

        var supplier_country_id = $('#supplier_country_id').val();
        var supplier_state_id   = $('#supplier_state_id').val();

        var company_country_id  = $('#company_country_id').val();
        var company_state_id    = $('#company_state_id').val();

        if(tax_type == 0)
        {
          var product_id  = row.find('input[name^="product_id"]').val();
          var quantity    = parseFloat(row.find('input[name^="quantity"]').val());
          var cost       = parseFloat(row.find('input[name^="cost"]').val());
          var final_discount_value = 0;

          var taxable_value   = parseFloat(quantity * cost);

          var discount_type   = row.find('input[name^="discount_type"]').val();
          var discount_value  = parseFloat(row.find('input[name^="discount_value"]').val());  

          var final_discount_value = 0;

          if(discount_type == 0)
          {
            final_discount_value = discount_value;
          }
          else
          {
            final_discount_value = (taxable_value * discount_value)/100;
          }

          taxable_value   = taxable_value - final_discount_value;
          
          var igst        = 0;
          var cgst        = 0;
          var sgst        = 0;

          if(company_country_id == supplier_country_id)
          {
            if(company_state_id == supplier_state_id)
            {
              cgst        = parseFloat(row.find('input[name^="cgst_rate"]').val());
              sgst        = parseFloat(row.find('input[name^="sgst_rate"]').val());
            }
            else
            {
              igst        = parseFloat(row.find('input[name^="igst_rate"]').val());
            }  
          }

          if(company_country_id == supplier_country_id)
          {
          
              if(company_state_id == supplier_state_id)
              {
                var igst_tax    = 0 ;
                var cgst_tax    = parseFloat((taxable_value * cgst)/100) ;
                var sgst_tax    = parseFloat((taxable_value * sgst)/100) ;
              }
              else
              {
                var igst_tax    = parseFloat((taxable_value * igst)/100) ;
                var cgst_tax    = 0 ;
                var sgst_tax    = 0 ;
              }  
      
          }
          else
          {
            var igst_tax    = 0 ;
            var cgst_tax    = 0 ;
            var sgst_tax    = 0 ;
          }

          var subtotal       = parseFloat(taxable_value + igst_tax + cgst_tax + sgst_tax);

          row.find('span[name^="i_tax"]').text(igst_tax.toFixed(2));
          row.find('span[name^="c_tax"]').text(cgst_tax.toFixed(2));
          row.find('span[name^="s_tax"]').text(sgst_tax.toFixed(2));

          row.find('span[name^="igst"]').text(igst.toFixed(2));
          row.find('span[name^="cgst"]').text(cgst.toFixed(2));
          row.find('span[name^="sgst"]').text(sgst.toFixed(2));

          row.find('span[name^="discount_amount"]').text(final_discount_value.toFixed(2));

          row.find('span[name^="taxable_value"]').text(taxable_value.toFixed(2));
          row.find('span[name^="subtotal"]').text(subtotal.toFixed(2));  
        }
        else
        {
          var final_discount_value = 0;
          var quantity    = parseFloat(row.find('input[name^="quantity"]').val());
          var cost       = parseFloat(row.find('input[name^="cost"]').val());

          var discount_type   = row.find('input[name^="discount_type"]').val();
          var discount_value  = parseFloat(row.find('input[name^="discount_value"]').val()); 

          var subtotal       = (quantity * cost);

          if(discount_type == 0)
          {
            final_discount_value = discount_value;
          }
          else
          {
            final_discount_value = (subtotal * discount_value)/100;
          }

          subtotal = subtotal - final_discount_value;

          var igst        = 0;
          var cgst        = 0;
          var sgst        = 0;

          if(company_country_id == supplier_country_id)
          {
            if(company_state_id == supplier_state_id)
            {
              cgst        = parseFloat(row.find('input[name^="cgst_rate"]').val());
              sgst        = parseFloat(row.find('input[name^="sgst_rate"]').val());
            }
            else
            {
              igst        = parseFloat(row.find('input[name^="igst_rate"]').val());
            }  
          }


          var tax_rate    = igst+cgst+sgst;

          var tax_amount    = parseFloat((subtotal * tax_rate) / (100 + tax_rate));

          var igst_tax = 0;
          var cgst_tax = 0;
          var sgst_tax = 0;

          if(company_country_id == supplier_country_id)
          {
            if(company_state_id == supplier_state_id)
            {
              cgst_tax = tax_amount/2;
              sgst_tax = tax_amount/2;
            }
            else
            {
              igst_tax = tax_amount;
            }  
          }
          else
          {
            var igst_tax    = 0 ;
            var cgst_tax    = 0 ;
            var sgst_tax    = 0 ;
          }

          var taxable_value = subtotal - (igst_tax + cgst_tax + sgst_tax);    

          row.find('span[name^="i_tax"]').text(igst_tax.toFixed(2));
          row.find('span[name^="c_tax"]').text(cgst_tax.toFixed(2));
          row.find('span[name^="s_tax"]').text(sgst_tax.toFixed(2));

          row.find('span[name^="igst"]').text(igst.toFixed(2));
          row.find('span[name^="cgst"]').text(cgst.toFixed(2));
          row.find('span[name^="sgst"]').text(sgst.toFixed(2));

          row.find('span[name^="discount_amount"]').text(final_discount_value.toFixed(2));

          row.find('span[name^="taxable_value"]').text(taxable_value.toFixed(2));
          row.find('span[name^="subtotal"]').text(subtotal.toFixed(2));   

        }
        
      }

      function calculateGrandTotal()
      {
        var total_taxable_value = 0.0;
        var total_cgst          = 0.0;
        var total_sgst          = 0.0;
        var total_igst          = 0.0;
        var total               = 0.0;
        var total_discount      = 0.0;

        $("#product_table_body").find('tr').each(function () {
            var tr              = $(this).closest("tr");
            total_taxable_value += parseFloat(tr.find('span[name^="taxable_value"]').text());
            total_discount      += parseFloat(tr.find('span[name^="discount_amount"]').text());
            total_cgst          += parseFloat(tr.find('span[name^="c_tax"]').text());
            total_sgst          += parseFloat(tr.find('span[name^="s_tax"]').text());
            total_igst          += parseFloat(tr.find('span[name^="i_tax"]').text());
            total               += parseFloat(tr.find('span[name^="subtotal"]').text()); 
        });

        $('#total_taxable_value').text(total_taxable_value.toFixed(2));
        $('#t_taxable_value').val(total_taxable_value.toFixed(2));

        $('#total_discount').text(total_discount.toFixed(2));
        $('#t_discount').val(total_discount.toFixed(2));

        $('#total_tax').text((total_cgst+total_sgst+total_igst).toFixed(2));
        $('#t_tax').val((total_cgst+total_sgst+total_igst).toFixed(2));

        $('#total').text(total.toFixed(2));
        $('#t').val(total.toFixed(2));
      }

      $('#editPurchaseForm').submit(function(e){
        // e.preventDefault();

        var isError = false;
        $('#purchaseSubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');

        $('form#editPurchaseForm .field_validation').each(function() {
            var id    = $(this).attr('id');
            var value = $(this).val();
            var field = $(this).attr('placeholder');

            if(value==null || value==""){
              $("form#editPurchaseForm #err_"+id).text(field+ " field is required.").fadeIn('slow');
              $('form#editPurchaseForm #'+id).addClass('is-invalid');
              isError = true;
            }
            else
            {
              $("form#editPurchaseForm #err_"+id).text("").fadeOut('slow');
              $('form#editPurchaseForm #'+id).removeClass('is-invalid');
              $('form#editPurchaseForm #'+id).addClass('is-valid');
            }
        });

        var productDataArray = [];

        $("#product_table_body").find('tr').each(function () {

            var tr              = $(this).closest("tr");
            var productData     = {};

            productData['product_id']       = tr.find('input[name^="product_id"]').val();
            productData['product_name']     = tr.find('span[name^="product_name"]').text();
            productData['description']      = tr.find('span[name^="description"]').text();
            productData['quantity']         = tr.find('input[name^="quantity"]').val();
            productData['cost']             = tr.find('input[name^="cost"]').val();
            productData['price']            = tr.find('input[name="price"]').val();
            productData['selling_price']    = tr.find('input[name="selling_price"]').val();

            productData['mfg_date']      = tr.find('input[name="mfg_date"]').val();
            productData['expiry_date']      = tr.find('input[name="expiry_date"]').val();

            productData['batch_no']         = tr.find('input[name="batch_no"]').val();
         
            productData['taxable_value']    = tr.find('span[name^="taxable_value"]').text();
            productData['discount_id']      = tr.find('select[name^="item_discount"]').val();
            productData['uom_id']           = tr.find('input[name^="uom_id"]').val();
            productData['uom_name']         = tr.find('input[name^="uom_id"]').data('uom_name');
            productData['uom_uom']          = tr.find('input[name^="uom_id"]').data('uom_uom');
            productData['discount_type']    = tr.find('input[name^="discount_type"]').val();
            productData['discount_value']   = tr.find('input[name^="discount_value"]').val();
            productData['discount_amount']  = tr.find('span[name^="discount_amount"]').text();
            productData['tax_id']           = tr.find('input[name^="tax_id"]').val();
            productData['tax_type']         = tr.find('input[name^="tax_type"]').val();
            productData['igst']             = tr.find('span[name^="igst"]').text();
            productData['igst_tax']         = tr.find('span[name^="i_tax"]').text();
            productData['cgst']             = tr.find('span[name^="cgst"]').text();
            productData['cgst_tax']         = tr.find('span[name^="c_tax"]').text();
            productData['sgst']             = tr.find('span[name^="sgst"]').text();
            productData['sgst_tax']         = tr.find('span[name^="s_tax"]').text();
            productData['subtotal']        = tr.find('span[name^="subtotal"]').text();
            productData['free_quantity']          = tr.find('input[name="free_quantity"]').val();

            productDataArray.push(JSON.stringify(productData));
        });

        if(productDataArray.length > 0)
        {
          $('#purchase_items').val(productDataArray.join('|'));
        }
        else
        {
          isError = true;
          $('#emptyPurchaseItemWarningModal').modal('show');
        }

        if(isError == true)
        {
          $('#purchaseSubmit').text('<?=$this->lang->line("purchase_add")?>').removeAttr('disabled');
          return false;
        }
        else 
        {
          return true;
        }
      });

      $("form#editPurchaseForm .field_validation").on("blur keyup change",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#editPurchaseForm #err_"+id).text(field+ " field is required.").fadeIn('slow');
          $('form#editPurchaseForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#editPurchaseForm #err_"+id).text("").fadeOut('slow');
          $('form#editPurchaseForm #'+id).removeClass('is-invalid');
          $('form#editPurchaseForm #'+id).addClass('is-valid');
        }
      });

      $('.gstin_row').css('display','none');

      // regular expression for gstin format
      var gstReg = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

      const SupplierToast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 10000
      });

      $('form#addSupplierForm #supplierSubmit').click(function(e){
        e.preventDefault();

        var isError = false;

        $('form#addSupplierForm .field_validation').each(function() {
            
            var id    = $(this).attr('id');
            var value = $(this).val();
            var field = $(this).attr('placeholder');

            if(value==null || value==""){
              $("form#addSupplierForm #err_"+id).text(field+ " field is required.");
              if($('form#addSupplierForm #'+id).hasClass('is-valid')){
                $('form#addSupplierForm #'+id).removeClass('is-valid');
              }
              $('form#addSupplierForm #'+id).addClass('is-invalid');
              isError = true;
            }
            else
            {
              $("form#addSupplierForm #err_"+id).text("");
              $('form#addSupplierForm #'+id).removeClass('is-invalid');
              $('form#addSupplierForm #'+id).addClass('is-valid');
            }

            if (!gstReg.test($('form#addSupplierForm #gstin').val()) && $('form#addSupplierForm #gst_registration_type').val() == 1) 
            {
              if($('form#addSupplierForm #gstin').val() == '')
              {
                // $('form#addSupplierForm #gstin').val('');
                $("form#addSupplierForm #err_gstin").text('GSTIN field is required');
                $('form#addSupplierForm #gstin').addClass('is-invalid');
                isError = true;
              }
              else
              {
                // $('form#addSupplierForm #gstin').val('');
                $("form#addSupplierForm #err_gstin").text('Please enter valid GSTIN');
                $('form#addSupplierForm #gstin').addClass('is-invalid');
                isError = true;  
              }
            }
            else
            {
              
              $("form#addSupplierForm #err_gstin").text("");
              $('form#addSupplierForm #gstin').removeClass('is-invalid');
              $('form#addSupplierForm #gstin').addClass('is-valid');
            }
        });


        if(isError == true)
        {
          return false;
        }  
        else 
        {
          var formData = $('#addSupplierForm').serialize();
          $('form#addSupplierForm #supplierSubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');

          $.ajax({
              url: '<?php echo base_url("supplier/add") ?>',
              type: 'POST',
              dataType : 'json',
              data: formData,                       
              success: function (response) {

                var supplier = response.supplier;

                if(response.code==1)
                {
                  $('#add_supplier_modal').modal('hide');
                  $('#supplierSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
                  
                  $('#supplier_id').html('');
                  $('#supplier_id').append('<option value="">Select</option>');
                  
                  for(i=0;i<response['suppliers'].length;i++)
                  { 
                    $('#supplier_id').append('<option value="' + response['suppliers'][i].id + '">' + response['suppliers'][i].company_name+'</option>');
                  }

                  $('#supplier_id').val(response['id']).attr("selected","selected");

                  if($("#warehouse_id").length)
                  { 
                    if($("#warehouse_id").val() != '')
                    {
                      $("#supplier_id").closest('.row').siblings().fadeIn(10);  
                    }

                    if(supplier.gst_registration_type == 0)
                    {
                      $('#rcm').val('Y');
                    }

                    $('form#addSupplierForm #supplier_state_id').val(supplier.state_id);
                    $('form#addSupplierForm #supplier_country_id').val(supplier.country_id);
                    $('form#addSupplierForm #supplier_gstin').val(supplier.gstin);

                    $("#product_table_body tr").remove();
                    calculateGrandTotal();
                  }

                  // show_message('success-header',response.message);
                  SupplierToast.fire({
                    type: 'success',
                    title: response.message
                  });
                }
                else
                {
                  // show_message('failure-header',response.message);
                  SupplierToast.fire({
                    type: 'error',
                    title: response.message
                  });
                }
              },
              error: function () 
              { 
                show_message('failure-header','Please contact the administrator if you are keep facing this issue.');   
              }
          });
        }    
      });

      $("form#addSupplierForm .field_validation").on("blur change keyup",  function (event){
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');
          
          if(value==null || value==""){
            $("form#addSupplierForm #err_"+id).text(field+ " field is required.");
            if($('form#addSupplierForm #'+id).hasClass('is-valid')){
              $('form#addSupplierForm #'+id).removeClass('is-valid');
            }
            $('form#addSupplierForm #'+id).addClass('is-invalid');
            return false;
          }
          else{
            $("form#addSupplierForm #err_"+id).text("");
            $('form#addSupplierForm #'+id).removeClass('is-invalid');
            $('form#addSupplierForm #'+id).addClass('is-valid');
          }
      });

      $(document).on('hidden.bs.modal','#add_supplier_modal', function () {

        $('.gstin_row').css('display','none');

        $('form#addSupplierForm .form-control').each(function() {
          var id = $(this).attr('id');
          $("form#addSupplierForm #"+id).val("");
          $("form#addSupplierForm #err_"+id).text("");
          $('form#addSupplierForm #'+id).removeClass('is-invalid');
          $('form#addSupplierForm #'+id).removeClass('is-valid');
        });
      });
      $('#add_supplier_modal').on('shown.bs.modal', function () {

        $("form#addSupplierForm #company_name").focus();

        var company_country_id  = '<?=$this->company_settings_model->get_company_records()->country_id?>';
      
        $('#country_id').html('<option value="">Select</option>');

        $.ajax({
          url: "<?php echo base_url('utility/get_countries') ?>/",
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            for(i=0;i<data.length;i++)
            {
              $('#country_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
            $('#country_id').val(company_country_id).trigger('change');
          }
        });
      });

      $("form#addSupplierForm #gstin").on("blur keyup change",  function (event){

        if (!gstReg.test($('form#addSupplierForm #gstin').val()) && $('form#addSupplierForm #gst_registration_type').val() == 1) 
        {        
          if($('form#addSupplierForm #gstin').val() == "")
          {
            $("form#addSupplierForm #err_gstin").text("GSTIN field is required.");
            $('form#addSupplierForm #gstin').addClass('is-invalid');
            return false;
          }
          else
          {
            $("form#addSupplierForm #err_gstin").text("Please enter valid GSTIN.");
            $('form#addSupplierForm #gstin').addClass('is-invalid');
            return false;
          }
        }
        else
        {
          $("form#addSupplierForm #err_gstin").text("");
          $('form#addSupplierForm #gstin').removeClass('is-invalid');
          $('form#addSupplierForm #gstin').addClass('is-valid');
        }
      });

      $("form#addSupplierForm #gst_registration_type").on("blur keyup change",  function (event){

        if ($('form#addSupplierForm #gst_registration_type').val() == 1) 
        {   
          $('.gstin_row').fadeIn(10);

          if($('form#addSupplierForm #gstin').val() == "")
          {
            $("form#addSupplierForm #err_gstin").text("GSTIN field is required.");
            $('form#addSupplierForm #gstin').addClass('is-invalid');
            return false;
          }
          else
          {
            $("form#addSupplierForm #err_gstin").text("Please enter valid GSTIN.");
            $('form#addSupplierForm #gstin').addClass('is-invalid');
            return false;
          }
        }
        else
        {
          $('.gstin_row').fadeOut(10);

          $("form#addSupplierForm #err_gstin").text("");
          $('form#addSupplierForm #gstin').removeClass('is-invalid');
          $('form#addSupplierForm #gstin').addClass('is-valid');
        }
      });

      $('#country_id').change(function(){

        var id = $(this).val();

        var company_state_id    = '<?=$this->company_settings_model->get_company_records()->state_id?>';
        // alert(id);
        $('form#addSupplierForm #state_id').html('<option value="">Select</option>');
        $('form#addSupplierForm #city_id').html('<option value="">Select</option>');
        $.ajax({
          url: "<?php echo base_url('utility/get_states') ?>/"+id,
          type: "GET",
          dataType: "JSON",
          success: function(data){
            for(i=0;i<data.length;i++){
              $('#state_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
            $('#state_id').val(company_state_id).trigger('change');
          }
        });
      });

      $('#state_id').change(function(){

        var id = $(this).val();

        // alert(id);
        $('#city_id').html('<option value="">Select</option>');
        $.ajax({
          url: "<?php echo base_url('utility/get_cities') ?>/"+id,
          type: "GET",
          dataType: "JSON",
          success: function(data){
            for(i=0;i<data.length;i++){
              $('#city_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
          }
        });
      });

      $(document).on('change', '#upload_document', function(e) {
        var allowedExtensions = ["pdf"];
        var files = this.files;
        var formData = new FormData();
        formData.append('csrf_test_name', '<?= $this->security->get_csrf_hash(); ?>');

        // Get existing filenames
        var existingFilenames = $('#document').val().split(', ');

        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var fileExtension = file.name.split(".").pop().toLowerCase();
            var errorSpan = $('#fileTypeError');
            var fileInputLabel = $(this).next('.custom-file-label');

            var fileName = file.name;

            // Regular expression to match only alphanumeric characters and underscores
            var regex = /^[a-zA-Z0-9_]+(\.[a-zA-Z0-9]+)?$/;

            if (!regex.test(fileName)) {
                Swal.fire({
                    title: "Message",
                    text: "File name should only contain alphanumeric (a-z0-9) and underscore ( _ ).",
                    buttonsStyling: !1,
                    confirmButtonText: "Ok, got it!",
                    timer: 5000,
                    customClass: {
                        confirmButton: "btn btn-primary"
                    }
                });

                $(this).val(""); // Clear the file input

                return;
            }

            if ($.inArray(fileExtension, allowedExtensions) === -1) {
                errorSpan.text("Only PDF files are allowed.");
                $(this).val(""); // Clear the file input
                return;
            }

            // Append the file to form data
            formData.append("upload_document[]", file);
            // Append the filename to existing filenames
            existingFilenames.push(file.name);
        }

        // Join existing filenames with newly uploaded filenames
        var combinedFilenames = existingFilenames.join(', ');

        // Set the value of the hidden input field to the combined filenames
        // $('#document').val(combinedFilenames);

        // Create a new FormData object to send the files to the server
        var formData = new FormData();
        for (var j = 0; j < files.length; j++) {
            formData.append("upload_document[]", files[j]);
        }
        var csrfTokenName = "<?php echo $this->security->get_csrf_token_name(); ?>"; // Change to your desired token name
        var csrfTokenValue = "<?php echo $this->security->get_csrf_hash(); ?>"; // Change to your actual CSRF token value

        // Add the CSRF token to the form data
        formData.append(csrfTokenName, csrfTokenValue);

          // Perform the AJAX request to the server
          $.ajax({
              url: "<?php echo base_url('purchase/upload_documents')?>", // Replace with your server-side script URL
              type: "POST",
              data: formData,
              dataType: "JSON",
              contentType: false,
              processData: false,
              success: function(response) {
                if (response.length > 0) {
                  var currentDocumentValue = $('#document').val();
                  var newFilenames = response.join(', ');

                  // Append new filenames to the existing document value
                  var updatedDocumentValue = currentDocumentValue ? currentDocumentValue + ', ' + newFilenames : newFilenames;

                  // Update the document field with the combined filenames
                  $('#document').val(updatedDocumentValue);
              }
              },
              error: function(jqXHR, textStatus, errorThrown) {
                  // Handle the error (if needed)
                  alert("Error uploading document: " + errorThrown);
              }
          });
      });


      $(document).on('click', '.deleteAttachedFile', function() {
        var filename = $(this).data('filename');
        
        $(this).closest('.attached-file').remove();

        var filenames = [];

        $('.attached-file').each(function() {
            filenames.push($(this).find('a').text());
        });

        $('#document').val(filenames.join(','));

      });

      
  });
</script>