<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/css/adminlte.min.css"> -->
    <style>
     body{
        font-size: 8px;
        padding: 0px;
        margin: 0px;
      }
      tr{
        font-size: 10px;
      }
      table, th, td {
        border-collapse: collapse;
      }

      thead,.table_header{
        background-color: #f2f2f2;
      }

      th, td {
        text-align: left;
        border-bottom: 1px solid #ddd;
        padding: 2px;
      }
      .d-none{display:none!important}
    </style>
  </head>
  <body>

    <?php
      $expiry_date = $this->utility_model->get_records_by_field_value('custom_field_setting','field_name', 'field_status', 'expiry_date', 'active',$row = true,$check_delete_status = false);

      $mfg_date = $this->utility_model->get_records_by_field_value('custom_field_setting','field_name', 'field_status', 'mfg_date', 'active',$row = true,$check_delete_status = false);

      $promotion = $this->utility_model->get_records_by_field_value('custom_field_setting','field_name', 'field_status', 'promotion', 'active',$row = true,$check_delete_status = false);

    ?>
    
      <center>
        <h3>
          <?=$this->lang->line('tax_purchase_under_gst')?> <br/>
          <?=$this->lang->line('purchase_for_supplier')?>
        </h3>
      </center>

      <h3 style="float: right">
        <?=$this->lang->line('date')?>: <?=date('d-m-Y', strtotime($purchase->purchase_date))?>
      </h3>
      <br/><br/><br/>                     
      <table style="width:100%">
        <tr class="table_header">
          <th width="25%"></th>
          <th width="25%"><?=$this->lang->line('company_details')?></th>
          <th width="25%"><?=$this->lang->line('name_address_supplier')?></th>
          <th width="25%"><?=$this->lang->line('purchase_details')?></th>
        </tr>
        <tr>
          <td style="vertical-align: text-top !important;" width="25%">
          <?php 
              $image_data = '';
              $company_settings 	= $this->company_settings_model->get_company_records();
              $cid = $company_settings->cid;

              if ($company_setting->logo != '') {
                $image_path = './assets/images/'.$cid.'/' . $company_setting->logo; // Adjust the path accordingly
                if (file_exists($image_path)) {
                  $image_data = file_get_contents($image_path);
                  $base64_data = base64_encode($image_data);
            ?>

            <center>
              <img src="data:image/png;base64,<?=$base64_data?>" style="width: 80px; height: 80px !important">
            </center>

            <?php 
                }
              }
            ?>
          </td>
          <td width="25%">
            <strong><?=$company_setting->company_name?></strong><br>
            <?=$company_setting->address_line1?><br>
            <?=$company_setting->address_line2?><br>
            <?=$company_setting->city_name.', '.$company_setting->state_name.', '.$company_setting->country_name?><br>
            <?=$company_setting->pincode?><br>
            <?=$this->lang->line('phone')?>: <?=$company_setting->mobile?><br>
            <?=$this->lang->line('email')?>: <?=$company_setting->email?><br>
            <strong><?=$this->lang->line('gstin_of_supplier')?>: <?=$company_setting->gstin?></strong><br>
          </td>
          <td style="vertical-align: text-top;" width="25%">
            <strong><?=$supplier_detail->company_name?></strong><br>
            <?= ($supplier_detail->address != '') ? ($supplier_detail->address.'<br/>') : '' ?>
            <?=$supplier_detail->city_name.', '.$supplier_detail->state_name.', '.$supplier_detail->country_name?><br>
            <b><?=$this->lang->line('phone')?></b>: <?=$supplier_detail->phone?><br>
            <b><?=$this->lang->line('email')?></b>: <?=$supplier_detail->email?><br>
            <b><?=$this->lang->line('gstin')?></b>: <?=$supplier_detail->gstin?><br>
          </td>
          <td style="vertical-align: text-top;" width="25%">
            <b><?=$this->lang->line('purchase_id')?></b><?=$purchase->reference_no?><br>
          </td>
        </tr>
      </table>
      <table style="width: 100%; font-size: 10px;">
        <thead>
          <tr>
            <th><?=$this->lang->line('purchase_sr')?></th>
            <th><?=$this->lang->line('purchase_items')?></th>
            <th><?=$this->lang->line('purchase_hsn')?></th>
            <th><?=$this->lang->line('purchase_qty')?></th>
            <th class="<?= empty($promotion) ? 'd-none' : '' ?>"><?=$this->lang->line('proforma_invoice_free_qty')?></th>
            <th><?=$this->lang->line('purchase_cost')?></th>
            <th class="<?= empty($mfg_date) ? 'd-none' : '' ?>"><?=$this->lang->line('product_mfg_date')?></th>
            <th class="<?= empty($expiry_date) ? 'd-none' : '' ?>"><?=$this->lang->line('product_expiry_date')?></th>
            <th><?=$this->lang->line('purchase_discount')?></th>
            <th><?=$this->lang->line('purchase_uom')?></th>
            <th><?=$this->lang->line('purchase_total_taxable_value')?></th>
            <th><?=$this->lang->line('sale_tax_rate')?></th>

            <?php 
              if($company_setting->country_id == $supplier_detail->country_id)
              {
                if($company_setting->state_id == $supplier_detail->state_id)
                {
            ?>
                  <th><?=$this->lang->line('cgst')?></th>
                  <th><?=$this->lang->line('sgst')?></th>
            <?php 
                }
                else
                {
            ?>
                  <th><?=$this->lang->line('igst')?></th>
            <?php
                }
              }
              else
              {
            ?>
                <th><?=$this->lang->line('igst')?></th>
            <?php
              }
            ?>
            <th><?=$this->lang->line('purchase_sub_total')?></th>
          </tr>
        </thead>
         <tbody>
          <?php 
            $purchase_paid_amount = $this->transaction_model->get_total_transaction_amount($purchase->id,PURCHASE_MODULE,PAYMENT_TRANSACTION_TYPE);  
            $i = 1;
            $total_quantity = 0;
            $total_cost    = 0;
            $total_discount_amount = 0;
            $total_taxable_value = 0;
            $total_tax = 0;
            $total_subtotal = 0;

            $total_cgst_tax = 0;
            $total_sgst_tax = 0;
            $total_igst_tax = 0;

            $colspan = 15;

            if($company_setting->state_id != $supplier_detail->state_id)
            {
              $colspan  = 14;
            }

            if($mfg_date == '')
              $colspan = $colspan-1;

            if($expiry_date == '')
              $colspan = $colspan-1; 

            if($promotion == '')
              $colspan = $colspan-1; 

            foreach ($purchase_items as $row) 
            {
              $total_quantity         += $row->quantity;
              $total_cost             += $row->cost;
              $total_discount_amount  += $row->discount_amount;
              $total_taxable_value    += $row->taxable_value;
              $total_tax              += $row->cgst_tax+$row->sgst_tax+$row->igst_tax;
              $total_subtotal         += $row->subtotal;

              $total_cgst_tax         += $row->cgst_tax;
              $total_sgst_tax         += $row->sgst_tax;
              $total_igst_tax         += $row->igst_tax;
          ?>
            <tr>
              <td><?=$i++?></td>
              <td><?=$row->product_name.'<br/>'.$row->description?></td>
              <td><?=$row->hsn?></td>
              <td><?=$row->quantity?></td>
              <td class="<?= empty($promotion) ? 'd-none' : '' ?>"><?=$row->free_quantity?></td>
              <td><?=number_format($row->cost,2)?></td>
              <td class="<?= empty($mfg_date) ? 'd-none' : '' ?>"><?=($row->mfg_date != '' && $row->mfg_date != '0000-00-00') ? date('d-m-Y',strtotime($row->mfg_date)) : ''?></td>
              <td class="<?= empty($expiry_date) ? 'd-none' : '' ?>"><?=($row->expiry_date != '' && $row->expiry_date != '0000-00-00') ? date('d-m-Y',strtotime($row->expiry_date)) : ''?></td>
              <td><?=number_format($row->discount_amount,2)?></td>
              <td><?=$row->uom_uom?></td>    
              <td><?=number_format($row->taxable_value,2)?></td>
              <td>
                <?php 
                  echo ($row->cgst + $row->sgst + $row->igst);
                ?>
              </td>
              
              <?php 
                if($company_setting->country_id == $supplier_detail->country_id)
                { 
                    if($company_setting->state_id == $supplier_detail->state_id)
                    {
              ?>
                      <td><?=$row->cgst_tax?></td>
                      <td><?=$row->sgst_tax?></td>
                      <!-- <td><?=$row->igst_tax?></td> -->
              <?php
                    }
                    else
                    {
              ?>
                      <!-- <td><?=$row->cgst_tax?></td>
                      <td><?=$row->sgst_tax?></td> -->
                      <td><?=$row->igst_tax?></td>
              <?php 
                    }
                }
                else
                {
              ?>
                  <td>N/A</td>
              <?php
                }
              ?>
              <td><?=number_format($row->subtotal,2)?></td>
            </tr>
          <?php 
            }
          ?>
            <tr style="font-size: 10px;font-weight: bolder;">
              <td colspan="3">
                <?=$this->lang->line('total_amount_due')?>   
              </td>
              <td><?=$total_quantity?></td>
              <td class="<?= empty($promotion) ? 'd-none' : '' ?>"></td>
              <td><?=number_format($total_cost,2)?></td>
              <td class="<?= empty($mfg_date) ? 'd-none' : '' ?>"></td>
              <td class="<?= empty($expiry_date) ? 'd-none' : '' ?>"></td>
              <td><?=number_format($total_discount_amount,2)?></td>
              <td></td>
              <td><?=number_format($total_taxable_value,2)?></td>
              <td></td>
              <?php 
                if($company_setting->country_id == $supplier_detail->country_id)
                { 
                    if($company_setting->state_id == $supplier_detail->state_id)
                    {
              ?>
                      <td><?=number_format_i($total_cgst_tax)?></td>
                      <td><?=number_format_i($total_sgst_tax)?></td>
                      <!-- <td><?=number_format_i($total_igst_tax)?></td> -->
              <?php
                    }
                    else
                    {
              ?>
                      <!-- <td><?=number_format_i($total_cgst_tax)?></td>
                      <td><?=number_format_i($total_sgst_tax)?></td> -->
                      <td><?=number_format_i($total_igst_tax)?></td>
              <?php 
                    }
                }
                else
                {
              ?>
                  <td>N/A</td>
              <?php
                }
              ?>
              <td><?=number_format($total_subtotal,2)?></td>
            </tr>
            <tr style="font-size: 10px;font-weight: bolder;">
            <td colspan="<?=($colspan-1)?>">
                <?=$this->lang->line('rounded_off')?>
            </td>

                <?=$this->lang->line('rounded_off')?>
              </td>

              <td>
                <?php 
                  if((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)) > 0)
                  {
                    echo '+'.number_format((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)),2);
                  }
                  else
                  {
                    echo '-'.number_format((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)),2);
                  }
                ?>
              </td>
            </tr>
            <tr style="font-size: 10px;font-weight: bolder;">
              <td colspan="<?=($colspan-1)?>">
                <?=$this->lang->line('paid_amount')?>
              </td>
              <td>
                <?php echo number_format(round($purchase_paid_amount),2) ;?>
              </td>
            </tr>
            <tr style="font-size: 10px;font-weight: bolder;">
              <td colspan="<?=($colspan-1)?>">
                <?=$this->lang->line('balance_payable')?>
              </td>
              <td>
                <?php echo number_format(round($purchase->total_taxable_value+$purchase->total_tax-$purchase_paid_amount));?>
              </td>
            </tr>
            <tr style="font-size: 10px;font-weight: bold; ">
              <td colspan="<?=($colspan%2 == 0) ? ($colspan/2) : (round($colspan/2) + 1) ?>">
                <?=$this->lang->line('amount_in_words')?>
              </td>
              <td colspan="<?=($colspan%2 == 0) ? ($colspan/2) : (round($colspan/2) - 1) ?>" style="text-align: right">
                <?php echo $this->numbertowords->convert_number(round($purchase->total_taxable_value+$purchase->total_tax-$purchase_paid_amount));?>
              </td>
            </tr>
        </tbody>
      </table>
      <table style="width: 100%;">
        <tr class="table_header">
          <td colspan="<?=($colspan%2 == 0) ? ($colspan/2) : (round($colspan/2) + 1) ?>" style="font-weight: bolder;"><?=$this->lang->line('terms_condition')?></td>
          <td colspan="<?=($colspan%2 == 0) ? ($colspan/2) : (round($colspan/2) - 1) ?>" style="font-weight: bolder;text-align:right;"><?=$this->lang->line('certified_message')?></td>
        </tr>
        <tr>
          <td colspan="<?=($colspan%2 == 0) ? ($colspan/2) : (round($colspan/2) + 1) ?>">
            <?=$purchase->terms_and_condition?>
          </td>
          <td colspan="<?=($colspan%2 == 0) ? ($colspan/2) : (round($colspan/2) - 1) ?>" style="text-align:right;">
            <?=$this->lang->line('for')?>, <?=strtoupper($company_setting->company_name)?><br/><br/><br/>

            <?php 
             $signature_data = '';

             $company_settings 	= $this->company_settings_model->get_company_records();
             $cid = $company_settings->cid;

             if($company_setting->signature != '')
             {
               $signature_path = './assets/images/'.$cid.'/' . $company_setting->signature; // Adjust the path accordingly
               if (file_exists($signature_path)) {
                 $signature_data = file_get_contents($signature_path);
                 $base64_data    = base64_encode($signature_data);
            ?>
              <img src="data:image/png;base64,<?=$base64_data?>" style="width: 100px;">
            <?php
               } 
              }
              else
              {
                echo '<br/><br/><br/>';
              }
            ?>  
            
            <h3><?=$this->lang->line('signatory')?></h3>
          </td>
        </tr>
      </table>
     
  </body>
</html>
