  <?php $this->load->view('layout/header');?>
    <link href="<?php echo base_url();?>assets/js/dropzone.min.css" rel="stylesheet">

    <div class="wrapper">
      <div class="content-wrapper">
        <section class="content-header">

            <div class="row mb-2">
              <div class="col-sm-12">
                <ol class="breadcrumb breadcrumb-custom float-sm-left">
                  <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
                  <li class="breadcrumb-item "><a href="#"><?=$this->lang->line('header_expense')?></a></li>
                  <li class="breadcrumb-item "><a href="<?=base_url('expense')?>"><?=$this->lang->line('expense_header')?></a></li>
                  <li class="breadcrumb-item active"><?=$this->lang->line('expense_edit')?></li>
                </ol>
              </div>
            </div>
        </section>

        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <form class="form-horizontal" name="editExpenseForm" id="editExpenseForm" method="post" action="<?=base_url('expense/edit')?>" enctype="multipart/form-data">
                <div class="card card-info">
                  <div class="card-header">
                    <h3 class="card-title"><?=$this->lang->line('expense_add')?></h3>
                  </div>
                  <div class="card-body">
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_date')?>
                        <span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-4">
                        <input type="text" name="date" class="form-control form-control-sm field_validation datepicker" id="date" placeholder="<?=$this->lang->line('expense_date')?>" value="<?=set_value('date',date('d-m-Y', strtotime($expense->date)))?>"><?=form_error('date', '<div class="text-danger">', '</div>');?>
                        <span id="err_date" class="error invalid-feedback"><?=form_error('date');?></span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_expense_category')?>
                        <span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <select class="form-control form-control-sm select2bs4 field_validation" name="expense_category_id" id="expense_category_id" placeholder="<?=$this->lang->line('expense_expense_category')?>" width="100%">
                            <option value=""><?=$this->lang->line('select')?></option>
                            <?php
                              foreach ($expense_categories as $value) {
                            ?>
                              <option value="<?=$value->id;?>"
                                <?php 
                                  if(!isset($expense_category_id))
                                  {
                                    if($value->id == $expense->expense_category_id)
                                      echo ' selected';
                                  }
                                  else
                                  {
                                    if($value->id == $expense_category_id)
                                      echo ' selected';
                                  }
                                ?>
                              >
                                <?= ucfirst($value->name);?>
                              </option>
                            <?php 
                              }
                            ?>
                          </select>
                          <span class="input-group-append">
                            <button type="button" class="btn btn-info btn-flat"data-tt="tooltip" title="Add Expense Category (ALT + C)" data-keyboard="true" data-toggle="modal" data-target="#add_expense_category_modal" data-tt="tooltip" accesskey="c"><i class="fas fa-plus"></i>
                            </button>
                          </span>
                          <span id="err_expense_category_id" class="error invalid-feedback"><?=form_error('expense_category_id');?></span>
                        </div>
                        
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_supplier')?>
                      </label>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <select class="form-control form-control-sm select2bs4" name="supplier_id" id="supplier_id" placeholder="<?=$this->lang->line('expense_supplier')?>" width="100%">
                            <option value=""><?=$this->lang->line('expense_other_supplier')?></option>
                            <?php
                              foreach ($suppliers as $value) {
                            ?>
                              <option value="<?=$value->id;?>" 
                                <?php 
                                  if(!isset($supplier_id))
                                  {
                                    if($value->id == $expense->supplier_id)
                                      echo ' selected';
                                  }
                                  else
                                  {
                                    if($value->id == $supplier_id)
                                      echo ' selected';
                                  }
                                ?>
                              >
                                <?= ucfirst($value->company_name);?>
                              </option>
                            <?php 
                              }
                            ?>
                          </select>
                          <span class="input-group-append">
                            <button type="button" class="btn btn-info btn-flat" data-tt="tooltip" title="Add Merchant (ALT + M)" data-toggle="modal" data-target="#add_merchant_modal" data-tt="tooltip" accesskey="m"><i class="fas fa-plus"></i>
                            </button>
                          </span>
                        </div>
                        <span id="info_supplier_id" class="text-info"></span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('expense_amount')?><span class="text-danger">*</span></label>
                      <div class="col-sm-4">
                        <input type="number" name="amount" value="<?=set_value('amount',$expense->amount)?>" class="form-control form-control-sm field_validation" id="amount" placeholder="<?=$this->lang->line('expense_amount')?>">
                        <span id="err_amount" class="error invalid-feedback"><?=form_error('amount');?></span>
                      </div>
                    </div>
                    <div class="form-group row cgst_row tax_row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_cgst')?>
                        <span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-4">
                        <input type="number" name="cgst" value="<?=set_value('igst',$expense->cgst)?>" class="form-control form-control-sm field_validation" id="cgst" placeholder="<?=$this->lang->line('expense_cgst')?>">
                        <?=form_error('cgst', '<div class="text-danger">', '</div>');?>
                        <span id="err_cgst" class="error invalid-feedback"><?=form_error('cgst');?></span>
                      </div>
                    </div>
                    <div class="form-group row sgst_row tax_row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_sgst')?>
                        <span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-4">
                        <input type="number" name="sgst" value="<?=set_value('sgst',$expense->sgst)?>" class="form-control form-control-sm field_validation" id="sgst" placeholder="<?=$this->lang->line('expense_sgst')?>">
                        <span id="err_sgst" class="error invalid-feedback"><?=form_error('sgst');?></span>
                      </div>
                    </div>
                    <div class="form-group row igst_row tax_row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_igst')?>
                        <span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-4">
                        <input type="number" name="igst" value="<?=set_value('igst',$expense->igst)?>" class="form-control form-control-sm field_validation" id="igst" placeholder="<?=$this->lang->line('expense_igst')?>">
                        <span id="err_igst" class="error invalid-feedback"><?=form_error('igst');?></span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_total_amount')?>
                        <span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-4">
                        <input type="number" name="total_amount" value="<?=set_value('total_amount',$expense->total_amount) ?>" class="form-control form-control-sm field_validation" id="total_amount" placeholder="<?=$this->lang->line('expense_total_amount')?>" readonly>
                        <span id="err_total_amount" class="error invalid-feedback"><?=form_error('total_amount');?></span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">
                        <?=$this->lang->line('expense_remarks')?>
                        <span class="text-danger">*</span>
                      </label>
                      <div class="col-sm-4">
                        <input type="text" name="remarks" value="<?=set_value('remarks',$expense->remarks) ?>" class="form-control form-control-sm field_validation" id="remarks" placeholder="<?=$this->lang->line('expense_remarks')?>">
                        <span id="err_remarks" class="error invalid-feedback"><?=form_error('remarks');?></span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('expense_itc')?></label>
                      <div class="col-sm-4">
                        <div class="custom-control custom-checkbox">
                          <input class="custom-control-input" name="itc" type="checkbox" id="itc" value="1"
                            <?php 
                              if($expense->itc != 0 && $expense->itc != null)
                                echo ' checked';
                            ?>
                          >
                          <label for="itc" class="custom-control-label"></label>
                        </div>
                        <span id="err_itc" class="error invalid-feedback"><?=form_error('itc');?></span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('expense_document')?></label>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <div class="custom-file">

                            <button type="button" class="btn btn-primary" data-tt="tooltip" title="Click here to upload the files" data-toggle="modal" data-target="#attachment_modal">Upload File</button>&nbsp;&nbsp;
                            <button type="button" class="btn btn-success" data-tt="tooltip" title="Click here to select the files" data-toggle="modal" data-target="#upload-files">Attach File</button>
                          </div>
                        </div>
                        <span id="err_document" class="error invalid-feedback"><?=form_error('document');?></span>
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        
                      </div>
                      <div class="col-sm-10">
                        <div id="selected_attachment" class="selected_attachment"> 
                          <?php 
                            if($expense->document != '')
                            {
                              $document_array = explode(",", $expense->document);
                              for ($i=0; $i < sizeof($document_array); $i++) 
                              {
                                $file_name_without_ext  = explode(".", $document_array[$i])[0];
                                $file_ext               = explode(".", $document_array[$i])[1];

                                $actual_file_name       = substr($file_name_without_ext, 0, -14).'.'.$file_ext;
                          ?>
                                <div class="btn-group" style="margin-top:5px; margin-left:5px;margin-right:5px;">
                                  <a href="<?=base_url('attachment/download_attachment/'.$document_array[$i])?>" class="btn btn-default" data-tt="tooltip" title="<?php echo $actual_file_name?>">
                                    <i class="fas fa-paperclip"></i> 
                                    <?php 
                                      $file_name_without_ext  = explode(".", $document_array[$i])[0];
                                      $file_ext         = explode(".", $document_array[$i])[1];

                                      $actual_file_name     = substr($file_name_without_ext, 0, -14).'.'.$file_ext;

                                      echo $actual_file_name;
                                    ?>
                                  </a>
                                  <button type="button" class="btn btn-danger delete_attached_file"  id="<?=$document_array[$i]?>">X</button>
                                </div>
                          <?php 
                              }
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <br/>
                  </div>
                  <div class="card-footer">
                    <input type="hidden" name="id" id="id" value="<?=$expense->id?>">
                    <input type="hidden" name="attached_files" value="<?=$expense->document?>" id="attached_files">
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                    <button type="submit" name="submit" id="expenseSubmit" data-tt="tooltip" title="Click here to Save Expense" class="btn btn-info">
                      <?=$this->lang->line('expense_save')?>
                    </button>
                    <a href="<?=base_url('expense')?>" class="btn btn-default float-right">
                      <?=$this->lang->line('expense_cancel')?>
                    </a>
                  </div>
                </div>
              </form>
              <div class="modal fade" id="attachment_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel"><?=$this->lang->line('expense_attach_modal_label')?><</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo base_url('attachment')?>/file_upload" enctype="multipart/form-data" class="dropzone" id="image-upload"  method="POST" style="border-style: dotted;border-color: #bababa; min-height: 275px !important">
                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal"><?=$this->lang->line('close')?></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>   
        </section>
      </div>
      <aside class="control-sidebar control-sidebar-dark"></aside>
      <!-- <div style="position: absolute;top: 15%; right: 20px; width: 300px;" >
        <div class="row">
          <div class="col-md-12">
            <div class="card card-outline card-primary">
              <div class="card-header">
                <h3 class="card-title">Shortcuts for adding Records</h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                </div>
              </div>
              <div class="card-body" style="font-size: 14px;">
                <div class="row">
                  <div class="col-md-9">
                    <?=$this->lang->line('expense_category_add')?>
                  </div>
                  <div class="col-md-3">
                    ALT + C
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-9">
                    <?=$this->lang->line('merchant_add')?>
                  </div>
                  <div class="col-md-3">
                    ALT + M
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> -->
    </div>
    <div class="upload-files">
      <div class="modal fade" id="upload-files" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><?=$this->lang->line('expense_upload_file')?></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" style="max-height: 400px;overflow-y: auto">

              <style type="text/css">
                .cursor-pointer {
                  cursor: pointer;
                }

                .list-group-item{
                  margin-bottom: -2px !important;
                }
              </style>

              <div class="row">
                <div class="col-md-12">
                  <ul class="list-group list_attachment">
                  </ul>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger attach_files"><?=$this->lang->line('expense_attach_file')?></button>
              <button type="button" class="btn btn-default refresh_attachments"><i class="fa fa-refresh"></i><?=$this->lang->line('refresh')?></button>
              <button type="button" class="btn btn-default" data-dismiss="modal"><?=$this->lang->line('close')?></button>
            </div>
          </div>
        </div>
      </div>
    </div>

    
<?php $this->load->view('layout/footer');?>
<?php $this->load->view('expense_category/add_expense_category_modal');?>
<?php $this->load->view('supplier/add_supplier_modal');?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.2.0/min/dropzone.min.js"></script>

<script type="text/javascript">
  Dropzone.options.imageUpload =  {
                  maxFilesize:100,
                  parallelUploads:2,
                  acceptedFiles: ".jpeg,.jpg,.png,.gif,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.html,.zip,.rar,.csv,.pdf"
                };
</script>

<script type="text/javascript">
  $(document).ready(function(e){
    $('.dz-message span').html("Click or Drag & Drop files here to upload");
    $('.dz-message').css('padding-top',"7%");
    $('.dz-message').css('font-size',"20px");
  });
</script>

<script type="text/javascript">
  $(document).ready(function(e){

    $('.tax_row').css('display','none');

    <?php 
      if($expense->gst_registration_type == 1 && $company_setting->state_id == $expense->supplier_state_id)
      {
    ?>
        $('.cgst_row').fadeIn(10);
        $('.sgst_row').fadeIn(10);
    <?php     
      }
      else if($expense->gst_registration_type == 1 && $company_setting->state_id != $expense->supplier_state_id)
      {
    ?>
        $('.igst_row').fadeIn(10);
    <?php
      }
    ?>

    $('#upload-files').on('shown.bs.modal',function(e){
      $.ajax({
        url: '<?php echo base_url('attachment');?>/get_attachment_from_session',
        type: 'GET',
        dataType: 'JSON',
        contentType: false,
        processData: false,
        success: function(response){

          var files               = response.data.split(',');
          
          var selectedFilesId     = new Array();
          var attached_files_id   = $('#attached_files').val();

          if(attached_files_id != '')
          {
            selectedFilesId = attached_files_id.split(",");
          }

          for(var i = 0 ; i < files.length ; i++)
          {
            var attachment_name_array  = files[i].split(".");
            var attachment_name        = attachment_name_array[0];
            var ext                    = attachment_name_array[1];
            var actual_attachment_name = attachment_name.substr(0,attachment_name.length - 14);
            var actual_file            = actual_attachment_name+"."+ext;

            if(selectedFilesId.indexOf(files[i]) == -1 && files[i] != '')
            {
              $('.list_attachment').append('<li class="list-group-item">'
                                            +'<div class="custom-control custom-checkbox">'
                                              +'<input class="custom-control-input" id="'+files[i]+'" type="checkbox" value="'+files[i]+'">'
                                              +'<label class="cursor-pointer d-block custom-control-label" for="'+files[i]+'">'
                                                +actual_file
                                              +'</label>'
                                            +'</div>'
                                          +'</li>');
            }
          }
        }
      });
    });

    $('#upload-files').on('hidden.bs.modal',function(e){
      $('.list_attachment').html('');
    });

    $('#refresh_attachments').click(function(e){
      $.ajax({
        url: '<?php echo base_url('attachment');?>/get_attachment_from_session',
        type: 'GET',
        dataType: 'JSON',
        contentType: false,
        processData: false,
        success: function(response){

          var files               = response.data.split(',');
          
          var selectedFilesId     = new Array();
          var attached_files_id   = $('#attached_files').val();

          if(attached_files_id != '')
          {
            selectedFilesId = attached_files_id.split(",");
          }

          for(var i = 0 ; i < files.length ; i++)
          {
            var attachment_name_array  = files[i].split(".");
            var attachment_name        = attachment_name_array[0];
            var ext                    = attachment_name_array[1];
            var actual_attachment_name = attachment_name.substr(0,attachment_name.length - 14);
            var actual_file            = actual_attachment_name+"."+ext;

            if(selectedFilesId.indexOf(files[i]) == -1 && files[i] != '')
            {
              selectedFilesId.push(files[i]);

              $('.list_attachment').append('<li class="list-group-item">'
                                            +'<div class="custom-control custom-checkbox">'
                                              +'<input class="custom-control-input" id="'+files[i]+'" type="checkbox" value="'+files[i]+'">'
                                              +'<label class="cursor-pointer d-block custom-control-label" for="'+files[i]+'">'
                                                +actual_file
                                              +'</label>'
                                            +'</div>'
                                          +'</li>');
            }
          }

          if(selectedFilesId.length > 0)
          {
            $('#attached_files').val(selectedFilesId.join(','));
          }
        }
      });
    });

    $('.attach_files').click(function(e){

      var attached_files        = $('#attached_files').val();
      var attached_files_array  = new Array();

      if(attached_files != '')
      {
        attached_files_array = attached_files.split(',');
      }

      var selected        = new Array();

      $('.list_attachment input[type=checkbox]').each(function() {
         if ($(this).is(":checked")) {
             selected.push($(this).attr('id'));
         }
      });

      for (var i = selected.length - 1; i >= 0; i--) {

        attached_files_array.push(selected[i]);
 
        var attachment_name_array   = selected[i].split(".");
        var attachment_name         = attachment_name_array[0];
        var ext                     = attachment_name_array[1];
        var actual_attachment_name  = attachment_name.substr(0,attachment_name.length - 14);
        var actual_file             = actual_attachment_name+"."+ext;

        $('#selected_attachment').append('<div class="btn-group" style="margin-top:5px; margin-left:5px;margin-right:5px;">'
                                                +'<a href="#" class="btn btn-default">'
                                                +'<i class="fas fa-paperclip"></i> ' 
                                                +actual_file
                                                +'</a>'
                                                // +'<a href="#" target="_blank" class="btn btn-default">'
                                                // +   '<i class="fa fa-download"></i>'
                                                // +'</a>'
                                                +'<button type="button" class="btn btn-danger delete_attached_file"  id="'+selected[i]+'">X</button'
                                                +'</div> ');
      }

      $('#attached_files').val(attached_files_array.join(','));

      $('#upload-files').modal('hide');
    });

    // list out all the select
    $('#attachment_modal').on('hide.bs.modal', function () {
      $.ajax({
        url: '<?php echo base_url('attachment');?>/get_attachment_from_session',
        type: 'GET',
        dataType: 'JSON',
        contentType: false,
        processData: false,
        success: function(response){

          var files               = response.data.split(',');
          
          var selectedFilesId     = new Array();
          var attached_files_id   = $('#attached_files').val();

          if(attached_files_id != '')
          {
            selectedFilesId = attached_files_id.split(",");
          }

          for(var i = 0 ; i < files.length ; i++)
          {
            var attachment_name_array  = files[i].split(".");
            var attachment_name        = attachment_name_array[0];
            var ext                    = attachment_name_array[1];
            var actual_attachment_name = attachment_name.substr(0,attachment_name.length - 14);
            var actual_file            = actual_attachment_name+"."+ext;

            if(selectedFilesId.indexOf(files[i]) == -1 && files[i] != '')
            {
              selectedFilesId.push(files[i]);

              $('#selected_attachment').append('<div class="btn-group" style="margin-top:5px; margin-left:5px;margin-right:5px;">'
                                                +'<a href="#" class="btn btn-default">'
                                                +'<i class="fas fa-paperclip"></i> ' 
                                                +actual_file
                                                +'</a>'
                                                // +'<a href="#" target="_blank" class="btn btn-default">'
                                                // +   '<i class="fa fa-download"></i>'
                                                // +'</a>'
                                                +'<button type="button" class="btn btn-danger delete_attached_file"  id="'+files[i]+'">X</button'
                                                +'</div> ');
            }
          }

          if(selectedFilesId.length > 0)
          {
            $('#attached_files').val(selectedFilesId.join(','));
          }
          
        }
      });
    });

    // remove image button pill from selected attachment
    $("#selected_attachment").delegate("button", "click", function(e){
      var attached_files_array = $('#attached_files').val().split(",");
      attached_files_array.splice($.inArray($(this).attr('id'), attached_files_array),1);
      $('#attached_files').val(attached_files_array.join(','));
      // remove file pill
      $(this).parent().remove();
    });  

    $("#supplier_id").change(function(e){

      var company_state_id = <?=$this->company_settings_model->get_company_records()->state_id?>;
      var supplier_id      =  $(this).val();


      if(supplier_id != '')
      {
        $.ajax({
          url: '<?php echo base_url('supplier');?>/get_record_details/' + supplier_id,
          type: 'GET',
          dataType: 'JSON',
          contentType: false,
          processData: false,
          success: function(response){

            var supplier_type = '';

            if(response.gst_registration_type == 1)
              supplier_type = 'Registered';
            else if(response.gst_registration_type == 0)
              supplier_type = 'Not Registered';
            else if(response.gst_registration_type == 2)
              supplier_type = 'Composite';

            $('form#addExpenseForm #info_supplier_id').text(supplier_type);

            if(response.gst_registration_type == 1)
            {
              if(response.state_id == company_state_id)
              {
                if(!$(".cgst_row").is(":visible"))
                {
                  $('#igst').val(0.0);
                  $('.cgst_row').fadeIn(900); 
                  $('.sgst_row').fadeIn(1000); 
                  $('.igst_row').fadeOut(10);
                }
              }
              else
              {
                if(!$(".igst_row").is(":visible"))
                { 
                  $('#cgst').val(0.0);
                  $('#sgst').val(0.0);              
                  $('.igst_row').fadeIn(1000); 

                  $('.cgst_row').fadeOut(10);
                  $('.sgst_row').fadeOut(10);
                }
              }
            }
            else
            {
              $('#igst').val(0.0);
              $('#cgst').val(0.0);
              $('#sgst').val(0.0);
              $('.cgst_row').fadeOut(10); 
              $('.sgst_row').fadeOut(10); 
              $('.igst_row').fadeOut(10);

              $('#amount').trigger('keyup');
            }
          }
        });        
      }
      else
      {
        $('.tax_row').fadeOut(10);
        $('#cgst').val(0.0);
        $('#sgst').val(0.0);              
        $('#igst').val(0.0);         

        $('#amount').trigger('keyup');
      }
    }); 

    $("#cgst, #sgst, #igst, #amount").on("keydown keyup change", function(e){

      var amount        = Number($("#amount").val());

      var cgst          = $("#cgst").val();
      var cgst_tax      = ($("#cgst").val()*amount)/100;

      var sgst          = $("#sgst").val();
      var sgst_tax      = ($("#sgst").val()*amount)/100;

      var igst          = $("#igst").val();
      var igst_tax      = ($("#igst").val()*amount)/100;
       
      var total_amount  = amount + cgst_tax + sgst_tax + igst_tax;

      $('#total_amount').val(total_amount.toFixed(2));
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(e){

    $('#expenseSubmit').click(function(e){
      // e.preventDefault();

      var isError = false;
      $('#expenseSubmit').text('<?=$this->lang->line("please_wait")?>');

      $('form#editExpenseForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#editExpenseForm #err_"+id).text(field+ " field is required.");
            $('form#editExpenseForm #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#editExpenseForm #err_"+id).text("");
            $('form#editExpenseForm #'+id).removeClass('is-invalid');
            $('form#editExpenseForm #'+id).addClass('is-valid');
          }
      });


      if(isError == true)
      {
        $('#expenseSubmit').text('<?=$this->lang->line("expense_save")?>');

        return false;
      }  
      else 
      {
        return true;
      }    
    });

    $("form#editExpenseForm .field_validation").on("blur change keyup",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#editExpenseForm #err_"+id).text(field+ " field is required.");
          $('form#editExpenseForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#editExpenseForm #err_"+id).text("");
          $('form#editExpenseForm #'+id).removeClass('is-invalid');
          $('form#editExpenseForm #'+id).addClass('is-valid');
        }
    });

    $('#country_id').change(function(){

      var form = $(this).closest('form');

      var id = $(this).val();

      form.find('#state_id').html('<option value="">Select</option>');
      form.find('#city_id').html('<option value="">Select</option>');

      $.ajax({
        url: "<?php echo base_url('utility/get_states') ?>/"+id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          for(i=0;i<data.length;i++)
          {
            form.find('#state_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }
        }
      });
    });

    $('#state_id').change(function(){
      
      var form = $(this).closest('form');
      
      var id = $(this).val();

      form.find('#city_id').html('<option value="">Select</option>');

      $.ajax({
        url: "<?php echo base_url('utility/get_cities') ?>/"+id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          for(i=0;i<data.length;i++)
          {
            $('#city_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }
        }
      });
    });
  });
</script>