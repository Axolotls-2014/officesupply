<?php $this->load->view('layout/header');?>

<div class="wrapper">
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row mb-2">
        <div class="col-sm-12">
          <ol class="breadcrumb breadcrumb-custom float-sm-left">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item "><a href="#"><?=$this->lang->line('header_people')?></a></li>
            <li class="breadcrumb-item"><a href="<?=base_url('auth/users')?>"><?=$this->lang->line('header_users')?></a></li>
            <li class="breadcrumb-item active"><?=$this->lang->line('user_list')?></li>
          </ol>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><?=$this->lang->line('user_list')?></h3>
              <?php 
                if($this->permission_model->has_permission('add_user'))
                {
              ?>
              <div class="card-tools">
                <ul class="nav nav-pills ml-auto">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?=base_url('auth/create_user')?>"><i class="fas fa-user mr-2"></i><?=$this->lang->line('user_add')?></a>
                  </li>
                </ul>
              </div>
              <?php 
                }
              ?>
            </div>
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th><?=$this->lang->line('user_first_name')?></th>
                    <th><?=$this->lang->line('user_last_name')?></th>
                    <th><?=$this->lang->line('user_username')?></th>
                    <th><?=$this->lang->line('user_user_group')?></th>
                    <th><?=$this->lang->line('user_email')?></th>
                    <th><?=$this->lang->line('user_phone')?></th>
                    <?php 
                      if($this->permission_model->has_permission('edit_user'))
                      {
                    ?>
                    <th><?=$this->lang->line('user_action')?></th>
                    <?php 
                      }
                    ?>
                  </tr>
                </thead>
                
                <tbody>
                  <?php 
                    foreach ($users as $user) 
                    {
                  ?>
                  <tr>                        
                    <td><?php echo $user->first_name;?></td>
                    <td><?php echo $user->last_name;?></td>
                    <td><?php echo $user->username;?></td>
                    <td>
                      <?php 
                        $group_array  = array();
                        $groups       = $this->ion_auth_model->get_users_groups($user->id)->result();

                        foreach ($groups as $value) {
                          $group_array[] = $value->description; 
                        }

                        echo implode(",", $group_array);
                      ?>
                    </td>
                    <td><?php echo $user->email;?></td>
                    <td><?php echo $user->phone;?></td>
                    <?php 
                      if($this->permission_model->has_permission('edit_user'))
                      {
                    ?>
                    <td>
                      <a href="<?php echo base_url('auth/edit_user/'.$user->id);?>" class="btn btn-info btn-xs">
                        <i class="fas fa-edit"></i>
                      </a>
                    </td>
                    <?php 
                      }
                    ?>
                  </tr>
                  <?php  
                    }
                  ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th><?=$this->lang->line('user_first_name')?></th>
                    <th><?=$this->lang->line('user_last_name')?></th>
                    <th><?=$this->lang->line('user_username')?></th>
                    <th><?=$this->lang->line('user_user_group')?></th>
                    <th><?=$this->lang->line('user_email')?></th>
                    <th><?=$this->lang->line('user_phone')?></th>
                    <?php 
                      if($this->permission_model->has_permission('edit_user'))
                      {
                    ?>
                    <th><?=$this->lang->line('user_action')?></th>
                    <?php 
                      }
                    ?>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<?php $this->load->view('layout/footer');?>

<script type="text/javascript">
  
  $(function() {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });

    <?php if($this->session->flashdata('success')) { ?>
        Toast.fire({
          type: 'success',
          title: '<?=$this->session->flashdata('success')?>'
        });
    <?php } ?>
  });
</script>
