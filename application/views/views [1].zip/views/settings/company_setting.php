<?php $this->load->view('layout/header');?>

  <div class="wrapper">
    <div class="content-wrapper">
      <section class="content-header">
          <div class="row mb-2">
            <div class="col-sm-12">
              <ol class="breadcrumb breadcrumb-custom float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
                <li class="breadcrumb-item active"><a href="#"><?=$this->lang->line('header_setting')?></a></li>
                <li class="breadcrumb-item active"><?=$this->lang->line('company_setting_header')?></li>
              </ol>
            </div>
          </div>
      </section>

      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <form class="form-horizontal" name="companySettingForm" id="companySettingForm" method="post" enctype="multipart/form-data">
              <div class="card card-info">
                <div class="card-header">
                  <h3 class="card-title"><?=$this->lang->line('company_setting_header')?></h3>
                </div>
                <div class="card-body">
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_name')?><span class="text-danger">*</span></label>
                    
                    <div class="col-sm-4">
                      <input type="text" name="company_name" value="<?=set_value('company_name',$company_setting->company_name) ?>" class="form-control form-control-sm field_validation" id="company_name" placeholder="<?=$this->lang->line('company_setting_name')?>"><?=form_error('company_name', '<div class="text-danger">', '</div>');?>
                      <span id="err_company_name" class="error invalid-feedback"><!-- <?=form_error('company_name');?> --></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_gst_registration_type')?><span class="text-danger">*</span></label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4 field_validation" name="gst_registration_type" id="gst_registration_type" width="100%" placeholder="<?=$this->lang->line('company_setting_gst_registration_type')?>">
                        <option value="1" <?php if($company_setting->gst_registration_type == 1) echo ' selected'; ?>><?=$this->lang->line('gst_reg_type_reg')?></option>
                        <option value="0" <?php if($company_setting->gst_registration_type == 0) echo ' selected'; ?>><?=$this->lang->line('gst_reg_type_not_reg')?></option>
                        <option value="2" <?php if($company_setting->gst_registration_type == 2) echo ' selected'; ?>><?=$this->lang->line('gst_reg_type_composite')?></option>
                      </select>
                      <span id="err_gst_registration_type" class="error invalid-feedback"><?=form_error('gst_registration_type');?></span>

                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_gstin')?></label>
                    
                    <div class="col-sm-4">
                      <input type="text" name="gstin" value="<?=set_value('gstin',$company_setting->gstin) ?>" class="form-control form-control-sm" id="gstin" placeholder="<?=$this->lang->line('company_setting_gstin').' (Example : 22AAAAA0000A1Z5)'?>">
                      <span id="err_gstin" class="error invalid-feedback"></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_email')?><span class="text-danger">*</span></label>
                    <div class="col-sm-4">
                      <input type="text" name="email" value="<?=set_value('email',$company_setting->email) ?>" class="form-control form-control-sm field_validation" id="email" placeholder="Email"><?=form_error('email', '<div class="text-danger">', '</div>');?>
                      <span id="err_email" class="error invalid-feedback"><!-- <?=form_error('email');?> --></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_phone')?><span class="text-danger">*</span></label>
                    <div class="col-sm-4">
                      <input type="text" name="mobile" value="<?=set_value('mobile',$company_setting->mobile) ?>" class="form-control form-control-sm field_validation" id="mobile" placeholder="<?=$this->lang->line('company_setting_phone')?>"><?=form_error('mobile', '<div class="text-danger">', '</div>');?>
                      <span id="err_mobile" class="error invalid-feedback"><!-- <?=form_error('mobile');?> --></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_country_id')?><span class="text-danger">*</span></label>
                    <div class="col-sm-4">
                     <select class="form-control form-control-sm select2bs4 field_validation" value="<?=$company_setting->country_id?>" name="country_id" id="country_id" width="100%">

                        <?php
                          foreach ($countries as $value) {
                        ?>
                          <option value="<?=$value->id;?>"
                            <?php 
                              if($value->id == $company_setting->country_id)
                                echo ' selected';
                            ?>
                          >
                            <?= $value->name;?>
                          </option>
                          
                        <?php 
                          }
                        ?>
                      </select>
                      <span id="err_country_id" class="error invalid-feedback"></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('company_setting_state_id')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4 field_validation" value="<?=$company_setting->state_id?>" name="state_id" id="state_id" width="100%" placeholder="<?=$this->lang->line('company_setting_state_id')?>">
                        <?php
                          foreach ($states as $value) {
                        ?>
                          <option value="<?=$value->id;?>"
                            <?php 
                              if($value->id == $company_setting->state_id)
                                echo ' selected';
                            ?>
                          >
                            <?= $value->name;?>
                          </option>
                          
                        <?php 
                          }
                        ?>
                      </select>
                      <span id="err_state_id" class="error invalid-feedback"></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_city_id')?><span class="text-danger">*</span></label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4 field_validation" value="<?=$company_setting->city_id?>" name="city_id" id="city_id" width="100%">
                        <?php
                          foreach ($cities as $value) {
                        ?>
                          <option value="<?=$value->id;?>"
                            <?php 
                              if($value->id == $company_setting->city_id)
                                echo ' selected';
                            ?>
                          >
                            <?= $value->name;?>
                          </option>
                          
                        <?php 
                          }
                        ?>
                       
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_address_line1')?></label>
                    <div class="col-sm-4">
                      <input type="text" name="address_line1" value="<?=set_value('address_line1',$company_setting->address_line1) ?>" class="form-control form-control-sm field_validation" id="address_line1" placeholder="<?=$this->lang->line('company_setting_address_line1')?>">
                      <span id="err_address_line1" class="error invalid-feedback"><!-- <?=form_error('address_line1');?> --></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_address_line2')?></label>
                    <div class="col-sm-4">
                      <input type="text" name="address_line2" value="<?=set_value('address_line2',$company_setting->address_line2) ?>" class="form-control form-control-sm" id="address_line2" placeholder="<?=$this->lang->line('company_setting_address_line2')?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('company_setting_default_currency')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4 field_validation" name="currency_id" id="currency_id" width="100%" placeholder="<?=$this->lang->line('company_setting_default_currency')?>">
                        <option value=""><?=$this->lang->line('company_setting_default_currency')?></option>
                        <?php
                          foreach ($currencies as $value) {
                        ?>
                          <option value="<?=$value->id;?>"
                            <?php 
                              if($value->id == $company_setting->currency_id)
                                echo ' selected';
                            ?>
                          >
                            <?= $value->name;?>
                          </option>
                        <?php 
                          }
                        ?>
                      </select>
                      <span id="err_currency_id" class="error invalid-feedback"></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_pincode')?><span class="text-danger">*</span></label>
                    <div class="col-sm-4">
                      <input type="text" name="pincode" value="<?=set_value('pincode',$company_setting->pincode) ?>" class="form-control form-control-sm field_validation" id="pincode" placeholder="<?=$this->lang->line('company_setting_pincode')?>"><?=form_error('pincode', '<div class="text-danger">', '</div>');?>
                      <span id="err_pincode" class="error invalid-feedback"><!-- <?=form_error('pincode');?> --></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('company_setting_bank_detail')?>
                    </label>
                    <div class="col-sm-4">
                      <textarea class="form-control form-control-sm" rows="5" name="bank_detail" id="bank_detail" placeholder="<?=$this->lang->line('company_setting_bank_detail')?>"><?=set_value('bank_detail',str_replace("<br />","",$company_setting->bank_detail)) ?></textarea>
                      <span id="err_pincode" class="error invalid-feedback"></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('company_setting_terms_and_condition')?>
                    </label>
                    
                    <div class="col-sm-4">
                      <textarea class="form-control form-control-sm" rows="5" name="terms_and_condition" id="terms_and_condition" placeholder="<?=$this->lang->line('company_setting_terms_and_condition')?>"><?=set_value('terms_and_condition',str_replace("<br />","",$company_setting->terms_and_condition)) ?></textarea>
                      <span id="err_terms_and_condition" class="error invalid-feedback"></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_logo')?></label>
                    <div class="col-sm-4">
                      <input type="file" name="logo" class="form-control form-control-sm" id="logo">
                     
                    <!--   <a href="<?php echo base_url();?>assets/images/<?php echo $company_setting->logo;?>" data-toggle="lightbox" data-title="<?php echo $company_setting->logo;?>"> -->
                      <?php 
                        if($company_setting->logo != '')
                        {
                      ?>
                      <img src="<?php echo base_url();?>assets/images/<?php echo $company_setting->logo;?>" height="100" width="100" style="padding-top: 5px;">
                      <?php 
                        }
                      ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"><?=$this->lang->line('company_setting_favicon')?></label>
                    <div class="col-sm-4">
                      <input type="file" name="favicon" class="form-control form-control-sm" id="favicon">
                     
                      <?php 
                        if($company_setting->favicon != '')
                        {
                      ?>
                        <img src="<?php echo base_url();?>assets/images/<?php echo $company_setting->favicon;?>" height="100" width="100" style="padding-top: 5px;">
                      <?php 
                        }
                      ?>
                    </div>
                  </div>
                </div>
                <div class="card-footer">
                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                  <button type="submit" name="submit" id="companysettingSubmit" class="btn btn-info" data-tt="tooltip" title="<?=$this->lang->line('click_save')?>"><?=$this->lang->line('company_setting_save')?></button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>
  
    </div>
    <aside class="control-sidebar control-sidebar-dark"></aside>
  </div>

<?php $this->load->view('layout/footer');?>

<script type="text/javascript">

  $(document).ready(function(e){

    var gstReg = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

    $('#companysettingSubmit').click(function(e){
      // e.preventDefault();

      var isError = false;
      $('#companysettingSubmit').text('<?=$this->lang->line("please_wait")?>');

      $('form#companySettingForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#companySettingForm #err_"+id).text(field+ " field is required.");
            $('form#companySettingForm #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#companySettingForm #err_"+id).text("");
            $('form#companySettingForm #'+id).removeClass('is-invalid');
            $('form#companySettingForm #'+id).addClass('is-valid');
          }

          if (!gstReg.test($('form#companySettingForm #gstin').val()) && $('form#companySettingForm #gst_registration_type').val() == 1) 
          {
            if($('form#companySettingForm #gstin').val() == '')
            {
              // $('form#companySettingForm #gstin').val('');
              $("form#companySettingForm #err_gstin").text('GSTIN field is required');
              $('form#companySettingForm #gstin').addClass('is-invalid');
              isError = true;
            }
            else
            {
              // $('form#companySettingForm #gstin').val('');
              $("form#companySettingForm #err_gstin").text('Please enter valid GSTIN');
              $('form#companySettingForm #gstin').addClass('is-invalid');
              isError = true;  
            }
          }
          else
          {
            
            $("form#companySettingForm #err_gstin").text("");
            $('form#companySettingForm #gstin').removeClass('is-invalid');
            $('form#companySettingForm #gstin').addClass('is-valid');
          }
      });


      if(isError == true)
      {
         $('#companysettingSubmit').text('<?=$this->lang->line("company_setting_save")?>');
        return false;
      }  
      else 
      {
        return true;
      }    


    });

    $("form#companySettingForm .field_validation").on("blur keyup change",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#companySettingForm #err_"+id).text(field+ " field is required.");
          $('form#companySettingForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#companySettingForm #err_"+id).text("");
          $('form#companySettingForm #'+id).removeClass('is-invalid');
          $('form#companySettingForm #'+id).addClass('is-valid');
        }
    });

    $("form#companySettingForm #gstin").on("blur keyup change",  function (event){

      if (!gstReg.test($('form#companySettingForm #gstin').val()) && $('form#companySettingForm #gst_registration_type').val() == 1) 
      {        
        if($('form#companySettingForm #gstin').val() == "")
        {
          $("form#companySettingForm #err_gstin").text("GSTIN field is required.");
          $('form#companySettingForm #gstin').addClass('is-invalid');
          return false;
        }
        else
        {
          $("form#companySettingForm #err_gstin").text("Please enter valid GSTIN.");
          $('form#companySettingForm #gstin').addClass('is-invalid');
          return false;
        }
      }
      else
      {
        $("form#companySettingForm #err_gstin").text("");
        $('form#companySettingForm #gstin').removeClass('is-invalid');
        $('form#companySettingForm #gstin').addClass('is-valid');
      }
    });

  });
</script>


<script>
  
  $(document).ready(function(e){
    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    });

    $('#country_id').change(function(){
      var id = $(this).val();
       // alert(id);
      $('#state_id').html('<option value="">Select</option>');
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
           url: "<?php echo base_url('utility/get_states') ?>/"+id,
           type: "GET",
           dataType: "JSON",
           success: function(data){
             for(i=0;i<data.length;i++){
               $('#state_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
             }
           }
         });
    });

    $('#state_id').change(function(){
      var id = $(this).val();
      
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
           url: "<?php echo base_url('utility/get_cities') ?>/"+id,
           type: "GET",
           dataType: "JSON",
           success: function(data){
             for(i=0;i<data.length;i++){
               $('#city_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
             }
           }
         });
    });
  });
</script>
