 <footer class="main-footer">
    <strong>Copyright &copy; <?=date('Y')?> <a href="http://zivaansolutions.com">Zivaan Solutions</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
 </footer>



<script src="<?php echo base_url();?>assets/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url();?>assets/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo base_url();?>assets/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url();?>assets/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?php echo base_url();?>assets/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url();?>assets/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url();?>assets/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url();?>assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url();?>assets/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url();?>assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url();?>assets/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>assets/js/demo.js"></script>
<script src="<?php echo base_url();?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- <script src="<?php echo base_url();?>assets/plugins/select2/js/select2.min.js"></script> -->
<script src="<?php echo base_url();?>assets/plugins/select2/js/select2.full.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/sweetalert2/sweetalert2.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/ekko-lightbox/ekko-lightbox.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/filterizr/jquery.filterizr.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/autocomplete/jquery_auto_complete.js"></script>
<script src="<?php echo base_url();?>assets/plugins/printThis/printThis.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo base_url();?>assets/js/modernizr.js"></script>

  <div class="message-modal">
    <div class="modal fade" id="message">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header message-header text-left">
            <h4 class="modal-title message_title"><?php echo $this->lang->line('message');?></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
            <h4>
              <?php echo $this->lang->line('lbl_cust_delete_modal');?>
            </h4>
          </div>
          <div class="modal-body message-body">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default btn-flat" data-dismiss="modal"><?php echo "Close";?></button>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
  </div>

  <div class="capital-modal">
    <div class="modal fade" id="capital_modal">
      <div class="modal-dialog">
        <div class="modal-content">
          <form name="capitalLedgerForm" id="capitalLedgerForm">
            <div class="modal-header text-left purple-header">
              <h4 class="modal-title"><?=$this->lang->line('ledger_capital_add_amount')?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 col-form-label">
                  <?=$this->lang->line('transaction_amount')?>
                  <span class="text-danger">*</span>
                </label>
                <div class="col-sm-8">
                  <input type="number" name="transaction_amount" value="" class="form-control form-control-sm field_validation" placeholder="<?=$this->lang->line('transaction_amount')?>" required="required">
                  <span id="err_transaction_amount" class="error invalid-feedback"></span>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-sm-12 text-center" >
                  <span class="text-danger">  NOTE : Amount can not be changed later on.</span>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <input type="hidden" name="ledger_id" id="ledger_id" value="<?=CAPITAL_LEDGER?>">
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <button type="submit" name="capitalLedgerSubmit" id="capitalLedgerSubmit" class="btn btn-primary btn-flat"><?=$this->lang->line('save')?></button>
              <button type="button" class="btn btn-default btn-flat" data-dismiss="modal"><?php echo "Close";?></button>
            </div>
          </form>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
  </div>
  
  <div class="cash-to-capital-modal">
    <div class="modal fade" id="cash-to-capital_modal">
      <div class="modal-dialog">
        <div class="modal-content">
          <form name="cashCapitalLedgerForm" id="cashCapitalLedgerForm">
            <div class="modal-header text-left warning-header">
              <h4 class="modal-title"><?=$this->lang->line('ledger_transfer_amount_from_capital_to_cash_header')?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php 
              $capital_ledger = $this->ledger_model->get_single_record(CAPITAL_LEDGER);
            ?>
            <div class="modal-body">
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 col-form-label">
                  <?=$this->lang->line('transaction_amount')?>
                  <span class="text-danger">*</span>
                </label>
                <div class="col-sm-8">
                  <input type="number" name="transaction_amount" value="" class="form-control form-control-sm field_validation" placeholder="<?=$this->lang->line('transaction_amount')?>" required="required" max="<?=$capital_ledger->closing_balance?>">
                  <span id="err_transaction_amount" class="error invalid-feedback"></span>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-sm-12 text-center" >
                  <span class="text-danger">  NOTE : Amount can not be changed later on.</span>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <input type="hidden" name="from_account" id="from_account" value="<?=CAPITAL_LEDGER?>">
              <input type="hidden" name="to_account" id="to_account" value="<?=CASH_GROUP_LEDGER?>">
              <input type="hidden" name="entry_id" value="0">
              <input type="hidden" name="module" value="<?=BANK_MODULE?>">
              <input type="hidden" name="payment_mode" value="0">
              <input type="hidden" name="transaction_type" value="<?=CONTRA_TRANSACTION_TYPE?>">
              <input type="hidden" name="credit_card_no" value="">
              <input type="hidden" name="cheque_no" value="">
              <input type="hidden" name="cheque_date" value="">
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <button type="submit" name="cashCapitalLedgerSubmit" id="cashCapitalLedgerSubmit" class="btn btn-primary btn-flat"><?=$this->lang->line('save')?></button>
              <button type="button" class="btn btn-default btn-flat" data-dismiss="modal"><?php echo "Close";?></button>
            </div>
          </form>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
  </div>
  <div class="guide-modal">
    <div class="modal fade" id="guide_modal">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header text-left teal-header">
            <h4 class="modal-title"><?php echo $this->lang->line('help_question_answers');?></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-5 col-sm-3">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist" aria-orientation="vertical">
                  <a class="nav-link active" id="vert-tabs-accounting-tab" data-toggle="pill" href="#vert-tabs-accounting" role="tab" aria-controls="vert-tabs-accounting" aria-selected="true">Accounting</a>
                  <a class="nav-link" id="vert-tabs-company-setting-tab" data-toggle="pill" href="#vert-tabs-company-setting" role="tab" aria-controls="vert-tabs-company-setting" aria-selected="false">Company Setting</a>
                  <a class="nav-link" id="vert-tabs-application-setting-tab" data-toggle="pill" href="#vert-tabs-application-setting" role="tab" aria-controls="vert-tabs-application-setting" aria-selected="false">Application Setting</a>
                  <a class="nav-link" id="vert-tabs-sales-tab" data-toggle="pill" href="#vert-tabs-sales" role="tab" aria-controls="vert-tabs-sales" aria-selected="false">Sales</a>

                </div>
              </div>
              <div class="col-7 col-sm-9">
                <div class="tab-content" id="vert-tabs-tabContent">
                  <div class="tab-pane text-left fade show active" id="vert-tabs-accounting" role="tabpanel" aria-labelledby="vert-tabs-accounting-tab">
                    <dl>
                      <dt>What is Capital Account ?</dt>
                      <dd>In accounting, a capital account is a general ledger account that is used to record the owner's contributed capital and retained earnings whether it is in any form i.e., Cash Balance, Bank Balance, Fixed Assests etc.</dd>

                      <dt>What is Cash on Hand ?</dt>
                      <dd>Cash on Hand is an Asset account. It is the total amount of any accessible cash. It is either brought by the capital or is received by any Sundry Debtor after sale or bank withdraw.</dd>

                      <dt>How does cash on hand ledger account works ?</dt>
                      <dd>Cash on Hand ledger works as debits(DR) increase its balance and credits(CR) decrease that total. This account, therefore, is said to carry a debit(DR) balance. In Simple form we can say that if Cash is Received it will be a debit Balance and if paid it will be a credit balance.</dd>
                    </dl>
                  </div>
                  <div class="tab-pane fade" id="vert-tabs-company-setting" role="tabpanel" aria-labelledby="vert-tabs-company-setting-tab">
                    <dl>
                      <dt>What is the use of Bank detail & Terms and Condition in Company setting ?</dt>
                      <dd>Mentioned Bank details and Terms & condition will be printed on sales invoice while printing.</dd>
                    </dl>
                  </div>
                  <div class="tab-pane fade" id="vert-tabs-application-setting" role="tabpanel" aria-labelledby="vert-tabs-application-setting-tab">
                    <dl>
                      <dt>How can I change the sidebar menu text size ?</dt>
                      <dd></dd>
                    </dl>
                  </div>
                  <div class="tab-pane fade" id="vert-tabs-sales" role="tabpanel" aria-labelledby="vert-tabs-sales-tab">
                     Pellentesque vestibulum commodo nibh nec blandit. Maecenas neque magna, iaculis tempus turpis ac, ornare sodales tellus. Mauris eget blandit dolor. Quisque tincidunt venenatis vulputate. Morbi euismod molestie tristique. Vestibulum consectetur dolor a vestibulum pharetra. Donec interdum placerat urna nec pharetra. Etiam eget dapibus orci, eget aliquet urna. Nunc at consequat diam. Nunc et felis ut nisl commodo dignissim. In hac habitasse platea dictumst. Praesent imperdiet accumsan ex sit amet facilisis. 
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">
              <?php echo $this->lang->line('btn_modal_close');?>
            </button>
          </div>
        
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
  </div>

  <script type="text/javascript">
    $(document).ready(function(e){

      const CapitalToast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 10000
      });

      $('#capitalLedgerForm').submit(function(e){
        e.preventDefault();

        var capitalLedgerForm     = $(this).closest('form');        
        var capitalLedgerFormData    = capitalLedgerForm.serialize();

        $('#capitalLedgerSubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');

        $.ajax({
          url: "<?php echo base_url('ledger/update_capital_ledger')?>",
          type: "POST",
          data: capitalLedgerFormData,
          dataType: "JSON",
          success: function(data){

            $('#capital_modal').modal('hide');
            
            capitalLedgerForm.find('input[name="transaction_amount"]').val('');

            if(data.code == 1)
            {
              CapitalToast.fire({
                type: 'success',
                title: data.message
              });

              location.reload();
            }
            else
            {
              CapitalToast.fire({
                type: 'error',
                title: data.message
              }); 
              location.reload();
            } 
            $('#capitalLedgerSubmit').text('<?=$this->lang->line("save")?>').removeAttr('disabled');         
          }
        });   
      });

      $('#cashCapitalLedgerForm').submit(function(e){
        e.preventDefault();
        var isError = false;

        $('form#cashCapitalLedgerForm .field_validation').each(function() {
            
            var id    = $(this).attr('id');
            var value = $(this).val();
            var field = $(this).attr('placeholder');

            if(value==null || value==""){
              $("form#cashCapitalLedgerForm #err_"+id).text(field+ " field is required.").fadeIn('slow');
              $('form#cashCapitalLedgerForm #'+id).addClass('is-invalid');
              isError = true;
            }
            else
            {
              $("form#cashCapitalLedgerForm #err_"+id).text("").fadeOut('slow');
              $('form#cashCapitalLedgerForm #'+id).removeClass('is-invalid');
              $('form#cashCapitalLedgerForm #'+id).addClass('is-valid');
            }
        });

        if(isError == true)
        {
          return false;
        }
        else
        {
          var cashCapitalLedgerFormData = $(this).closest('form').serialize();
          $('#cashCapitalLedgerSubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');

          $.ajax({
            url: "<?php echo base_url('transaction/add')?>",
            type: "POST",
            data: cashCapitalLedgerFormData,
            dataType: "JSON",
            success: function(data){

              $('#cash-to-capital_modal').modal('hide');
              if(data.code == 1)
              {
                CapitalToast.fire({
                  type: 'success',
                  title: data.message
                });
                location.reload();
              }
              else
              {
                CapitalToast.fire({
                  type: 'error',
                  title: data.message
                }); 
                location.reload();
              } 

              $('#cashCapitalLedgerSubmit').text('<?=$this->lang->line("save")?>').removeAttr('disabled');
            }
          });  
        }
      });
    });
  </script>
  <script>
    //paste this code under head tag or in a seperate js file.
    // Wait for window load
    $(document).ready(function() {
      // Animate loader off screen
      setTimeout(function(){ 
        $(".se-pre-con").fadeOut(); 
      }, 10);
    });
  </script>
  <script>
    $(function () {
      $("input[data-bootstrap-switch]").each(function(){
        $(this).bootstrapSwitch('state', $(this).prop('checked'));
      });
      $("#example1").DataTable({
        "ordering": false,
        "iDisplayLength": 50,
        "aLengthMenu": [[10, 15, 25, 35, 50, 100, -1], [10, 15, 25, 35, 50, 100, "All"]]
      });
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": false,
        "info": true,
        "autoWidth": false,
        "iDisplayLength": 50,
        "aLengthMenu": [[10, 15, 25, 35, 50, 100, -1], [10, 15, 25, 35, 50, 100, "All"]]
      });
    });

    function show_message(message_header,message_body = null)
    {
      var message_headers = ['success-header','info-header','failure-header','secondary-header']

      for (var i = message_headers.length - 1; i >= 0; i--) 
      {
        if($('.message_header').hasClass(message_headers[i]))
        {
          $('.message_header').removeClass(message_headers[i]);  
        }
      }

      $('.message-header').addClass(message_header);

      if(message_body != null)
      {
        $('.message-body').html(message_body);
      }

      $('#message').modal('show');
    }
  </script>
  <script>
    $(document).ready(function(e){
      
      // Initialize tooltip
      $('[data-tt="tooltip"]').tooltip({trigger : 'hover'}); 
      
      // Mask the date
      $('[data-mask]').inputmask("99-99-9999");

      //Initialize Select2 Elements
      $('.select2bs4').select2({
        theme: 'bootstrap4'
      });

      $('.datepicker').datepicker({
          weekStart: 1,
          daysOfWeekHighlighted: "6,0",
          autoclose: true,
          todayHighlight: true,
          format: 'dd-mm-yyyy'
      });

      // $('.datepicker').datepicker("setDate", new Date());
    });
  </script>

  <script type="text/javascript">
  
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 10000
      });

      <?php if($this->session->flashdata('success')) { ?>
          Toast.fire({
            type: 'success',
            title: '<?=$this->session->flashdata('success')?>'
          });
      <?php } ?>

      <?php if($this->session->flashdata('failure')) { ?>
          Toast.fire({
            type: 'error',
            title: '<?=$this->session->flashdata('failure')?>'
          });
      <?php } ?>

      <?php if($this->session->flashdata('warning')) { ?>
          Toast.fire({
            type: 'warning',
            title: '<?=$this->session->flashdata('warning')?>'
          });
      <?php } ?>
    });
  </script>
  <script>
  window.fwSettings={
    'widget_id':81000001414
    };
    !function(){if("function"!=typeof window.FreshworksWidget){var n=function(){n.q.push(arguments)};n.q=[],window.FreshworksWidget=n}}() 
  </script>
  <script type='text/javascript' src='https://ind-widget.freshworks.com/widgets/81000001414.js' async defer></script>
  <script>/* This is the function to open the widget */
      function openWidget() {FreshworksWidget('open', 'ticketForm');}
  </script>
  <script>
    function initFreshChat() {
      window.fcWidget.init({
        token: "74903aa2-7482-4e7b-bf86-1cd43057a3ee",
        host: "https://wchat.in.freshchat.com"
      });
    }
    function initialize(i,t){var e;i.getElementById(t)?initFreshChat():((e=i.createElement("script")).id=t,e.async=!0,e.src="https://wchat.in.freshchat.com/js/widget.js",e.onload=initFreshChat,i.head.appendChild(e))}function initiateCall(){initialize(document,"freshchat-js-sdk")}window.addEventListener?window.addEventListener("load",initiateCall,!1):window.attachEvent("load",initiateCall,!1);
  </script>
</body>
</html>