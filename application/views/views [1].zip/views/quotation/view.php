<?php $this->load->view('layout/header');?>

<div class="wrapper">
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row mb-2">
        <div class="col-sm-12">
          <ol class="breadcrumb breadcrumb-custom float-sm-left">
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('quotation_header')?></a></li>
            <li class="breadcrumb-item active"><?=$this->lang->line('quotation_view')?></li>
          </ol>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><?=$this->lang->line('quotation_view')?></h3>
              
              <div class="card-tools">
                <?php 
                  if($this->permission_model->has_permission('edit_quotation'))
                  {
                ?>
                <a href="<?=base_url('quotation/edit/'.$quotation->id)?>" class="btn btn-secondary">
                  <i class="fas fa-edit"></i> <?=$this->lang->line('edit')?>
                </a>
                <?php 
                  }
                ?>

                <?php 
                  if($this->permission_model->has_permission('pdf_quotation'))
                  {
                ?>
                <a href="<?=base_url('quotation/pdf/'.$quotation->id)?>" class="btn btn-warning">
                  <i class="far fa-file-pdf"></i> <?=$this->lang->line('generate_pdf')?>
                </a>
                <?php 
                  }
                ?>
              </div>
              
            </div>
            <div class="card-body">
              <div class="invoice p-3 mb-3">
                <!-- title row -->
                <div class="row">
                  <div class="col-12 text-center">
                    <?=$this->lang->line('quotation_under_act_gst')?> <br/><?=$this->lang->line('quotation_for_recipient')?>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12">
                    <h4>
                      <i class="fas fa-globe"></i> <?=$company_setting->company_name?>
                      <small class="float-right"><?=$this->lang->line('date')?>: <?=date('d-m-Y', strtotime($quotation->quotation_date))?></small>
                    </h4>
                  </div>
                  <!-- /.col -->
                </div>
                <div class="row">
                  <div class="col-12">
                    <table width="100%" class="table">
                      <tr style="font-size: 16px;font-weight: bolder;">
                        <td><?=$this->lang->line('name_address_supplier')?></td>
                        <td><?=$this->lang->line('bill_to')?></td>
                        <td><?=$this->lang->line('quotation_detail')?></td>
                      </tr>
                      <tr>
                        <td>
                          <address>
                            <strong><?=$company_setting->company_name?></strong><br>
                            <?=$company_setting->address_line1?><br>
                            <?=$company_setting->address_line2?><br>
                            <?=$company_setting->city_name.', '.$company_setting->state_name.', '.$company_setting->country_name?><br>
                            <?=$company_setting->pincode?><br>
                            <?=$this->lang->line('phone')?>: <?=$company_setting->mobile?><br>
                            <?=$this->lang->line('email')?>: <?=$company_setting->email?><br>
                            <strong><?=$this->lang->line('gstin')?>: <?=$company_setting->gstin?></strong><br>
                          </address>
                        </td>
                        <td>
                          <address>
                            <strong><?=$customer_detail->customer_name?></strong><br>
                            <?=$customer_detail->address?><br>
                            <?=$customer_detail->city_name.', '.$customer_detail->state_name.', '.$customer_detail->country_name?><br>
                            <?=$this->lang->line('phone')?>: <?=$customer_detail->phone?><br>
                            <?=$this->lang->line('email')?>: <?=$customer_detail->email?><br>
                            <?=$this->lang->line('gstin')?>: <?=$customer_detail->gstin?><br>
                          </address>
                        </td>
                        <td>
                          <b><?=$this->lang->line('quotation_label')?> #</b><?=$quotation->reference_no?><br>

                          <b><?=$this->lang->line('receipt_voucher_no')?></b> <br/>

                          <b><?=$this->lang->line('quotation_rcm_applicability')?>: </b><?=($quotation->rcm == "Y") ? "Yes" : "No"?>

                        </td>
                      </tr>
                    </table>
                  </div>
                </div>
               
                <!-- Table row -->
                <div class="row">
                  <div class="col-12 table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th><?=$this->lang->line('sr')?></th>
                          <th><?=$this->lang->line('product')?></th>
                          <th><?=$this->lang->line('hsn')?></th>
                          <th><?=$this->lang->line('qty')?></th>
                          <th><?=$this->lang->line('price')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('discount')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('total_taxable_value')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('tax')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('subtotal')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                          $i = 1;
                          $total_quantity = 0;
                          $total_price    = 0;
                          $total_discount_amount = 0;
                          $total_taxable_value = 0;
                          $total_tax = 0;
                          $total_subtotal = 0;
                          foreach ($quotation_items as $row) 
                          {
                            $total_quantity         += $row->quantity;
                            $total_price            += $row->price;
                            $total_discount_amount  += $row->discount_amount;
                            $total_taxable_value    += $row->taxable_value;
                            $total_tax              += $row->cgst_tax+$row->sgst_tax+$row->igst_tax;
                            $total_subtotal         += $row->sub_total;
                        ?>
                          <tr>
                            <td><?=$i++?></td>
                            <td><?=$row->product_name.'<br/>'.$row->product_description?></td>
                            <td><?=$row->hsn?></td>
                            <td><?=$row->quantity?></td>
                            <td><?=$row->price?></td>
                            <td><?=$row->discount_amount?></td>
                            <td><?=$row->taxable_value?></td>
                            <td>
                              <?php 
                                if($company_setting->country_id == $customer_detail->country_id)
                                {
                                  if($quotation->rcm == 'N' && $company_setting->gstin != '')
                                  {
                                    if($company_setting->state_id == $customer_detail->state_id)
                                    {
                              ?>
                                      <?=$this->lang->line('cgst')?> : <?=$row->cgst_tax?>
                                      (<?=$row->cgst?>%)
                                      <br><?=$this->lang->line('sgst')?> : <?=$row->sgst_tax?>
                                      (<?=$row->sgst?>%)
                              <?php
                                    }
                                    else
                                    {
                              ?>
                                      <?=$this->lang->line('igst')?> : <?=$row->igst_tax?>
                                      (<?=$row->cgst?>%)
                              <?php 
                                    }
                                  }
                                  else
                                  {
                              ?>
                                    N/A  
                              <?php
                                  }
                                }
                                else
                                {
                              ?>
                                  N/A
                              <?php
                                }
                              ?>
                            </td>
                            <td><?=$row->sub_total?></td>
                          </tr>
                        <?php 
                          }
                        ?>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="3">
                              <?=$this->lang->line('total_amount_due')?>   
                            </td>
                            <td><?=$total_quantity?></td>
                            <td><?=$total_price?></td>
                            <td><?=$total_discount_amount?></td>
                            <td><?=$total_taxable_value?></td>
                            <td><?=$total_tax?></td>
                            <td><?=$total_subtotal?></td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="8">
                              <?=$this->lang->line('advance_adjusted')?>
                            </td>
                            <td><?="0.0"?></td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="8">
                              <?=$this->lang->line('rounded_off')?> 
                            </td>
                            <td>
                              <?php 
                                if((round($quotation->total_taxable_value+$quotation->total_tax) - ($quotation->total_taxable_value+$quotation->total_tax)) > 0)
                                {
                                  echo '+'.number_format((round($quotation->total_taxable_value+$quotation->total_tax) - ($quotation->total_taxable_value+$quotation->total_tax)),2);
                                }
                                else
                                {
                                  echo number_format((round($quotation->total_taxable_value+$quotation->total_tax) - ($quotation->total_taxable_value+$quotation->total_tax)),2);
                                }
                              ?>
                            </td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="8">
                              <?=$this->lang->line('balance_payable')?>
                            </td>
                            <td>
                              <?php echo round($quotation->total_taxable_value+$quotation->total_tax);?>
                            </td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bold; ">
                            <td colspan="5">
                              <?=$this->lang->line('amount_in_words')?>
                            </td>
                            <td colspan="4" style="text-align: right">
                              <?php echo $this->numbertowords->convert_number(round($quotation->total_taxable_value+$quotation->total_tax));?>
                            </td>
                          </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <!-- /.row -->

                <div class="row">
                  <div class="col-12">
                    <table width="100%" class="table">
                      <tr style="font-size: 16px;font-weight: bolder;">
                        <td width="50%">
                          <?=$this->lang->line('bank_detail')?>
                        </td>
                        <td>
                          <?=$this->lang->line('remarks')?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?=$quotation->bank_detail?>
                        </td>
                        <td>
                          <?=$quotation->external_note?>
                        </td>
                      </tr>
                      <tr style="font-size: 16px;font-weight: bolder;">
                        <td width="50%">
                          <?=$this->lang->line('terms_condition')?>
                        </td>
                        <td>
                          <?=$this->lang->line('certified_message')?>                         
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?=$quotation->terms_and_condition?>
                        </td>
                        <td>
                          <?=$this->lang->line('for')?>, <?=strtoupper($company_setting->company_name)?>
                          <br/>
                          <br/>
                          <br/>
                          <?=$this->lang->line('signatory')?>


                        </td>
                      </tr>
                    </table>
                  </div>
                </div>

                <!-- this row will not appear when printing -->
                <div class="row no-print">
                  <div class="col-12">  


                    

                  <?php 
                    if($this->permission_model->has_permission('print_quotation'))
                    {
                  ?>
                    <button type="button" class="btn btn-success float-left print_invoice">
                      <i class="fas fa-print"></i> <?=$this->lang->line('print')?>
                    </button>
                  <?php 
                    }
                  ?>
                    <!-- <button type="button" class="btn btn-success float-right">
                      <i class="far fa-credit-card"></i> Submit Payment
                    </button>
                    <a class="btn btn-primary float-right" style="margin-right: 5px;" href="<?=base_url('quotation/pdf/'.$quotation->id)?>" target="_blank">
                      <i class="fas fa-download"></i> Generate PDF
                    </a> -->
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<?php $this->load->view('layout/footer');?>

<script type="text/javascript">
  $(document).ready(function(e){
    $('.print_invoice').click(function(e){
      $('.invoice').printThis();
    });
  });
</script>