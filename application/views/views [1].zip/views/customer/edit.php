<?php $this->load->view('layout/header');?>

  <div class="wrapper">
    <div class="content-wrapper">
      <section class="content-header">
          <div class="row mb-2">
            <div class="col-sm-12">
              <ol class="breadcrumb breadcrumb-custom float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
                <li class="breadcrumb-item "><a href="#"><?=$this->lang->line('header_people')?></a></li>
                <li class="breadcrumb-item "><a href="<?=base_url('customer/list')?>"><?=$this->lang->line('header_customer')?></a></li>
                <li class="breadcrumb-item active"><?=$this->lang->line('customer_edit')?></li>
              </ol>
            </div>
          </div>
      </section>

      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <form class="form-horizontal" name="editCustomerForm" id="editCustomerForm" method="post" action="<?php echo base_url('customer/edit');?>">
              <div class="card card-info">
                <div class="card-header">
                  <h3 class="card-title"><?=$this->lang->line('customer_edit')?></h3>
                </div>
                <div class="card-body">
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_name')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      <input type="text" name="customer_name" value="<?=set_value('customer_name',$customer->customer_name) ?>" class="form-control form-control-sm field_validation" id="customer_name" placeholder="<?=$this->lang->line('customer_name')?>">
                      <span id="err_customer_name" class="error invalid-feedback"><?=form_error('customer_name');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('customer_gstin')?></label>
                    <div class="col-sm-4">
                      <input type="text" name="gstin" value="<?=set_value('gstin',$customer->gstin) ?>" class="form-control form-control-sm" id="gstin" placeholder="<?=$this->lang->line('customer_gstin')?>">
                      <span id="err_gstin" class="error invalid-feedback"><?=form_error('gstin');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_email')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      <input type="text" name="email" value="<?php echo $customer->email;?>" class="form-control form-control-sm" id="email" placeholder="<?=$this->lang->line('customer_email')?>">
                      <span id="err_email" class="error invalid-feedback"><?=form_error('email');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_phone')?>
                      <span class="text-danger">*</span>  
                    </label>
                    <div class="col-sm-4">
                      <input type="text" name="phone" value="<?php echo $customer->phone;?>" class="form-control form-control-sm field_validation" id="phone" placeholder="<?=$this->lang->line('customer_phone')?>">
                      <span id="err_phone" class="error invalid-feedback"><?=form_error('phone');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_country_id')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      
                      <select class="form-control form-control-sm select2bs4" value="<?php echo $customer->country_id;?>" name="country_id" id="country_id" width="100%">

                        <?php
                          foreach ($countries as $value) {
                        ?>
                          <option value="<?=$value->id;?>"
                            <?php 
                              if($value->id == $customer->country_id)
                                echo ' selected';
                            ?>
                          >
                            <?= $value->name;?>
                          </option>
                        <?php 
                          }
                        ?>
                      </select>
                      
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_state_id')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4" value="<?php echo $customer->state_id;?>"  name="state_id" id="state_id" width="100%">

                         <?php
                          foreach ($states as $value) {
                        ?>
                          <option value="<?=$value->id;?>"
                            <?php
                              if(isset($state_id))
                              {
                                if($state_id == $value->id)
                                  echo ' selected';
                              } 
                              else
                              {
                                if($value->id == $customer->state_id)
                                  echo ' selected';
                              }

                            ?>
                          >
                            <?= $value->name;?>
                          </option>
                          
                        <?php 
                          }
                        ?>
                       
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('customer_city_id')?></label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4" value="<?php echo $customer->city_id;?>" name="city_id" id="city_id" width="100%">
                       
                          <?php
                          foreach ($cities as $value) {
                        ?>
                          <option value="<?=$value->id;?>"
                            <?php 
                              if(isset($city_id))
                              {
                                if($city_id == $value->id)
                                  echo ' selected';
                              }
                              else
                              {
                                if($value->id == $customer->city_id)
                                  echo ' selected';
                              }
                            ?>
                          >
                            <?= $value->name;?>
                          </option>
                          
                        <?php 
                          }
                        ?>

                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('customer_address')?></label>
                    <div class="col-sm-4">
                      <input type="text" name="address" value="<?php echo set_value('address',$customer->address);?>" class="form-control form-control-sm" id="address" placeholder="<?=$this->lang->line('customer_address')?>">
                      <span id="err_address" class="error invalid-feedback"><?=form_error('address');?></span>
                    </div>
                  </div>
                  
                </div>
                <div class="card-footer">
                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                  <input type="hidden" name="id" value="<?=$customer->id?>">
                  <button type="submit" name="submit" id="customerSubmit" class="btn btn-info"><?=$this->lang->line('customer_save')?></button>
                 <a href="<?=base_url('customer')?>" class="btn btn-default float-right"><?=$this->lang->line('customer_cancel')?></a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>
  
    </div>
    <aside class="control-sidebar control-sidebar-dark"></aside>
  </div>

<?php $this->load->view('layout/footer');?>


<script type="text/javascript">

 
  $(document).ready(function(e){

    var gstReg = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

    $('#customerSubmit').click(function(e){
     //   e.preventDefault();

      var isError = false;
      $('#customerSubmit').text('<?=$this->lang->line("please_wait")?>');

      $('form#editCustomerForm .field_validation').each(function() {
        
         var id    = $(this).attr('id');
         var value = $(this).val();
         var field = $(this).attr('placeholder');

         if(value==null || value==""){
          $("form#editCustomerForm #err_"+id).text(field+ " field is required.");
           $('form#editCustomerForm #'+id).addClass('is-invalid');
           isError = true;
         }
         else
         {
           $("form#editCustomerForm #err_"+id).text("");
          $('form#editCustomerForm #'+id).removeClass('is-invalid');
           $('form#editCustomerForm #'+id).addClass('is-valid');
         }
      });

      if (!gstReg.test($('form#editCustomerForm #gstin').val()) && $('form#editCustomerForm #gstin').val() != '') 
      {
        // $('form#editCustomerForm #gstin').val('');
        $("form#editCustomerForm #err_gstin").text('Please enter valid GSTIN');
        $('form#editCustomerForm #gstin').addClass('is-invalid');
        isError = true;  
      
      }
      else
      { 
        $("form#editCustomerForm #err_gstin").text("");
        $('form#editCustomerForm #gstin').removeClass('is-invalid');
        $('form#editCustomerForm #gstin').addClass('is-valid');
      }


      if(isError == true)
      {
        $('#customerSubmit').text('<?=$this->lang->line("customer_save")?>');
        return false;
      }  
      else 
      {
        return true;
      }    
    });

    $("form#editCustomerForm .field_validation").on("blur change keyup",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
          if(value==null || value==""){
            $("form#editCustomerForm #err_"+id).text(field+ " field is required.");
            $('form#editCustomerForm #'+id).addClass('is-invalid');
            return false;
          }
          else
          {
            $("form#editCustomerForm #err_"+id).text("");
            $('form#editCustomerForm #'+id).removeClass('is-invalid');
            $('form#editCustomerForm #'+id).addClass('is-valid');
          }
        });

    $("form#editCustomerForm #gstin").on("blur keyup change",  function (event){

      if (!gstReg.test($('form#editCustomerForm #gstin').val()) && $('form#editCustomerForm #gstin').val() != '') 
      { 
        $("form#editCustomerForm #err_gstin").text("Please enter valid GSTIN.");
        $('form#editCustomerForm #gstin').addClass('is-invalid');
        return false;
      }
      else
      {
        $("form#editCustomerForm #err_gstin").text("");
        $('form#editCustomerForm #gstin').removeClass('is-invalid');
        $('form#editCustomerForm #gstin').addClass('is-valid');
      }
    });

    $('#country_id').change(function(){
      var id = $(this).val();
      $('#state_id').html('<option value="">Select</option>');
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
        url: "<?php echo base_url('utility/get_states') ?>/"+id,
        type: "GET",
        dataType: "JSON",
        success: function(data){
          for(i=0;i<data.length;i++)
          {
            $('#state_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }
        }
      });
    });

    $('#state_id').change(function(){
      var id = $(this).val();
      
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
         url: "<?php echo base_url('utility/get_cities') ?>/"+id,
         type: "GET",
         dataType: "JSON",
         success: function(data)
         {
            for(i=0;i<data.length;i++)
            {
              $('#city_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
         }
      });
    });

  });
</script>


<script>

  $(document).ready(function(e){
    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    });

    
  });
</script>