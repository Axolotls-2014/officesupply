<?php $this->load->view('layout/header');?>

  <div class="wrapper">
    <div class="content-wrapper">
      <section class="content-header">
          <div class="row mb-2">
            <div class="col-sm-12">
              <ol class="breadcrumb breadcrumb-custom float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
                <li class="breadcrumb-item "><a href="#"><?=$this->lang->line('header_people')?></a></li>
                <li class="breadcrumb-item "><a href="<?=base_url('service')?>"><?=$this->lang->line('header_customer')?></a></li>
                <li class="breadcrumb-item active"><?=$this->lang->line('customer_add')?></li>
              </ol>
            </div>
          </div>
      </section>

      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <form class="form-horizontal" name="addCustomerForm" id="addCustomerForm" method="post" action="">
              <div class="card card-info">
                <div class="card-header">
                  <h3 class="card-title"><?=$this->lang->line('customer_add')?></h3>
                </div>
                <div class="card-body">
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_name')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      <input type="text" name="customer_name" value="<?=set_value('customer_name') ?>" class="form-control form-control-sm field_validation" id="customer_name" placeholder="<?=$this->lang->line('customer_name')?>">
                      <span id="err_customer_name" class="error invalid-feedback"><?=form_error('customer_name');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_gstin')?>
                    </label>
                    <div class="col-sm-4">
                      <input type="text" name="gstin" value="<?=set_value('gstin') ?>" class="form-control form-control-sm" id="gstin" placeholder="<?=$this->lang->line('customer_gstin')?>">
                      <span id="err_gstin" class="error invalid-feedback"><?=form_error('gstin');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_email')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      <input type="text" name="email" value="<?=set_value('email') ?>" class="form-control form-control-sm" id="email" placeholder="<?=$this->lang->line('customer_email')?>">
                      <span id="err_email" class="error invalid-feedback"><?=form_error('email');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_phone')?>
                      <span class="text-danger">*</span> 
                    </label>
                    <div class="col-sm-4">
                      <input type="text" name="phone" value="<?=set_value('phone') ?>" class="form-control form-control-sm field_validation" id="phone" placeholder="<?=$this->lang->line('customer_phone')?>">
                      <span id="err_phone" class="error invalid-feedback"><?=form_error('phone');?></span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_country_id')?>
                      <span class="text-danger">*</span>
                    </label>
                    <div class="col-sm-4">
                      
                      <select class="form-control form-control-sm select2bs4 field_validation" name="country_id" id="country_id" width="100%">
                        <?php
                          foreach ($countries as $value) {
                        ?>
                          <option value="<?=$value->id;?>" <?php echo set_select('country_id', $value->id); ?>>
                            <?= $value->name;?>
                          </option>
                        <?php 
                          }
                        ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                      <?=$this->lang->line('customer_state_id')?>
                      <span class="text-danger">*</span>  
                    </label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4 field_validation"  name="state_id" id="state_id" width="100%">
                        <?php
                          if(isset($states))
                          {
                            foreach ($states as $value) 
                            {
                        ?>
                            <option value="<?=$value->id;?>" <?php echo set_select('state_id', $value->id); ?>>
                              <?= $value->name;?>
                            </option>
                        <?php 
                            }
                          }
                        ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('customer_city_id')?></label>
                    <div class="col-sm-4">
                      <select class="form-control form-control-sm select2bs4" name="city_id" id="city_id" width="100%">
                        <?php
                          if(isset($cities))
                          {
                            foreach ($cities as $value) 
                            {
                        ?>
                            <option value="<?=$value->id;?>" <?php echo set_select('city_id', $value->id); ?>>
                              <?= $value->name;?>
                            </option>
                        <?php 
                            }
                          }
                        ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"><?=$this->lang->line('customer_address')?></label>
                    <div class="col-sm-4">
                      <input type="text" name="address" value="<?=set_value('address') ?>" class="form-control form-control-sm" id="address" placeholder="<?=$this->lang->line('customer_address')?>">
                      <span id="err_address" class="error invalid-feedback"><?=form_error('address', '<div class="text-danger">', '</div>');?></span>
                    </div>
                  </div>
                  
                </div>
                <div class="card-footer">
                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                  <button type="submit" name="submit" id="customerSubmit" class="btn btn-info"><?=$this->lang->line('customer_save')?></button>
                  <a href="<?=base_url('customer')?>" class="btn btn-default float-right"><?=$this->lang->line('customer_cancel')?></a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>
  
    </div>
    <aside class="control-sidebar control-sidebar-dark"></aside>
  </div>

<?php $this->load->view('layout/footer');?>


<script type="text/javascript">

 
  $(document).ready(function(e){

    var gstReg = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

    $('#customerSubmit').click(function(e){
      // e.preventDefault();

      var isError = false;
      $('#customerSubmit').text('<?=$this->lang->line("please_wait")?>');

      $('form#addCustomerForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#addCustomerForm #err_"+id).text(field+ " field is required.");
            $('form#addCustomerForm #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#addCustomerForm #err_"+id).text("");
            $('form#addCustomerForm #'+id).removeClass('is-invalid');
            $('form#addCustomerForm #'+id).addClass('is-valid');
          }
      });

      if (!gstReg.test($('form#addCustomerForm #gstin').val()) && $('form#addCustomerForm #gstin').val() != '') 
      {
        // $('form#addCustomerForm #gstin').val('');
        $("form#addCustomerForm #err_gstin").text('Please enter valid GSTIN');
        $('form#addCustomerForm #gstin').addClass('is-invalid');
        isError = true;  
      
      }
      else
      { 
        $("form#addCustomerForm #err_gstin").text("");
        $('form#addCustomerForm #gstin').removeClass('is-invalid');
        $('form#addCustomerForm #gstin').addClass('is-valid');
      }

      if(isError == true)
      {
        $('#customerSubmit').text('<?=$this->lang->line("customer_save")?>');
        return false;
      }  
      else 
      {
        return true;
      }    


    });

    $("form#addCustomerForm .field_validation").on("blur change keyup",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#addCustomerForm #err_"+id).text(field+ " field is required.");
          $('form#addCustomerForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#addCustomerForm #err_"+id).text("");
          $('form#addCustomerForm #'+id).removeClass('is-invalid');
          $('form#addCustomerForm #'+id).addClass('is-valid');
        }
    });

    $("form#addCustomerForm #gstin").on("blur keyup change",  function (event){

      if (!gstReg.test($('form#addCustomerForm #gstin').val()) && $('form#addCustomerForm #gstin').val() != '') 
      { 
        $("form#addCustomerForm #err_gstin").text("Please enter valid GSTIN.");
        $('form#addCustomerForm #gstin').addClass('is-invalid');
        return false;
      }
      else
      {
        $("form#addCustomerForm #err_gstin").text("");
        $('form#addCustomerForm #gstin').removeClass('is-invalid');
        $('form#addCustomerForm #gstin').addClass('is-valid');
      }
    });

    $('#country_id').change(function(){
      var id = $(this).val();
       // alert(id);
      $('#state_id').html('<option value="">Select</option>');
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
        url: "<?php echo base_url('utility/get_states') ?>/"+id,
        type: "GET",
        dataType: "JSON",
        success: function(data){
         for(i=0;i<data.length;i++){
           $('#state_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }
        }
      });
    });

    $('#state_id').change(function(){
      var id = $(this).val();
      
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
         url: "<?php echo base_url('utility/get_cities') ?>/"+id,
         type: "GET",
         dataType: "JSON",
         success: function(data){
           for(i=0;i<data.length;i++){
             $('#city_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
           }
         }
      });
    });

  });
</script>

