<?php 
  $tabindex = 101;
?>  
<div class="example-modal">
  <div class="modal fade" id="add_customer_modal">
    <div class="modal-dialog">
      <div class="modal-content">
        <form role="form" method="post" name="addCustomerForm" id="addCustomerForm">
          <div class="modal-header text-left">
            <h4 class="modal-title"><?php echo $this->lang->line('customer_add');?></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
            <h4>
              <?php echo $this->lang->line('lbl_cust_delete_modal');?>
            </h4>
          </div>
          <div class="modal-body">
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('customer_name')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <input type="text" name="customer_name" value="<?=set_value('customer_name') ?>" class="form-control form-control-sm field_validation" id="customer_name" placeholder="<?=$this->lang->line('customer_name')?>" tabindex="<?=$tabindex++?>"><?=form_error('customer_name', '<div class="text-danger">', '</div>');?>
                <span id="err_customer_name" class="error invalid-feedback"><?=form_error('customer_name');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('customer_phone')?>
                <span class="text-danger">*</span> 
              </label>
              <div class="col-sm-6">
                <input type="text" name="phone" value="<?=set_value('phone') ?>" class="form-control form-control-sm field_validation" id="phone" placeholder="<?=$this->lang->line('customer_phone')?>" tabindex="<?=$tabindex++?>"><?=form_error('phone', '<div class="text-danger">', '</div>');?>
                <span id="err_phone" class="error invalid-feedback"><?=form_error('phone');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label"><?=$this->lang->line('customer_email')?></label>
              <div class="col-sm-6">
                <input type="text" name="email" value="<?=set_value('email') ?>" class="form-control form-control-sm" id="email" placeholder="<?=$this->lang->line('customer_email')?>" tabindex="<?=$tabindex++?>"><?=form_error('email', '<div class="text-danger">', '</div>');?>
                <span id="err_email" class="error invalid-feedback"><?=form_error('email');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label"><?=$this->lang->line('customer_gstin')?></label>
              <div class="col-sm-6">
                <input type="text" name="gstin" value="<?=set_value('gstin') ?>" class="form-control form-control-sm" id="gstin" placeholder="<?=$this->lang->line('customer_gstin')?>" tabindex="<?=$tabindex++?>"><?=form_error('gstin', '<div class="text-danger">', '</div>');?>
                <span id="err_gstin" class="error invalid-feedback"><?=form_error('gstin');?></span>
              </div>
            </div>
            
            
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('customer_country_id')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                
                <select class="form-control form-control-sm select2bs4 field_validation" name="country_id" id="country_id" width="100%" placeholder="<?=$this->lang->line('customer_country_id')?>" tabindex="<?=$tabindex++?>">
                  <?php
                    foreach ($countries as $value) {
                  ?>
                    <option value="<?=$value->id;?>" <?php echo set_select('country_id', $value->id); ?>>
                      <?= $value->name;?>
                    </option>
                  <?php 
                    }
                  ?>
                </select>
                <span id="err_country_id" class="error invalid-feedback"><?=form_error('phone');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('customer_state_id')?>
                <span class="text-danger">*</span>  
              </label>
              <div class="col-sm-6">
                <select class="form-control form-control-sm select2bs4 field_validation"  name="state_id" id="state_id" width="100%" placeholder="<?=$this->lang->line('customer_state_id')?>" tabindex="<?=$tabindex++?>">
                  <?php
                    if(isset($states))
                    {
                      foreach ($states as $value) 
                      {
                  ?>
                      <option value="<?=$value->id;?>" <?php echo set_select('state_id', $value->id); ?>>
                        <?= $value->name;?>
                      </option>
                  <?php 
                      }
                    }
                  ?>
                </select>
                <span id="err_state_id" class="error invalid-feedback"><?=form_error('state_id');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label"><?=$this->lang->line('customer_city_id')?></label>
              <div class="col-sm-6">
                <select class="form-control form-control-sm select2bs4" name="city_id" id="city_id" width="100%" tabindex="<?=$tabindex++?>">
                  <?php
                    if(isset($cities))
                    {
                      foreach ($cities as $value) 
                      {
                  ?>
                      <option value="<?=$value->id;?>" <?php echo set_select('city_id', $value->id); ?>>
                        <?= $value->name;?>
                      </option>
                  <?php 
                      }
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label"><?=$this->lang->line('customer_address')?></label>
              <div class="col-sm-6">
                <input type="text" name="address" value="<?=set_value('address') ?>" class="form-control form-control-sm" id="address" placeholder="<?=$this->lang->line('customer_address')?>" tabindex="<?=$tabindex++?>"><?=form_error('address', '<div class="text-danger">', '</div>');?>
                <span id="err_address" class="error invalid-feedback"><?=form_error('address', '<div class="text-danger">', '</div>');?></span>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

            <button type="submit" name="submit" id="customerSubmit" tabindex="<?=$tabindex?>" class="btn btn-primary">Submit</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">
              <?php echo $this->lang->line('btn_modal_close');?>
            </button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
  </div>
</div>

<script type="text/javascript">

  $(document).ready(function(e){

    const CustomerToast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 10000
    });

    $('#customerSubmit').click(function(e){
      e.preventDefault();

      var isError = false;

      $('form#addCustomerForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#addCustomerForm #err_"+id).text(field+ " field is required.");
            if($('form#addCustomerForm #'+id).hasClass('is-valid')){
              $('form#addCustomerForm #'+id).removeClass('is-valid');
            }
            $('form#addCustomerForm #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#addCustomerForm #err_"+id).text("");
            $('form#addCustomerForm #'+id).removeClass('is-invalid');
            $('form#addCustomerForm #'+id).addClass('is-valid');
          }
      });


      if(isError == true)
      {
        return false;
      }  
      else 
      {
        var formData = $('#addCustomerForm').serialize();

        $.ajax({
            url: '<?php echo base_url("customer/add") ?>',
            type: 'POST',
            dataType : 'json',
            data: formData,                       
            success: function (response) {

              var customer = response.customer;

              if(response.code==1)
              {
                $('#add_customer_modal').modal('hide');

                if($('#customer_id').length)
                {
                  $('#customer_id').html('');
                  $('#customer_id').append('<option value="">Select</option>');
                  
                  for(i=0;i<response['customers'].length;i++)
                  { 
                    $('#customer_id').append('<option value="' + response['customers'][i].id + '">' + response['customers'][i].customer_name+'</option>');
                  }

                  $('#customer_id').val(response['id']).attr("selected","selected");  

                  if($("#warehouse_id").length)
                  { 
                    if($("#warehouse_id").val() != '')
                    {
                      $("#customer_id").closest('.row').siblings().fadeIn(10);
                    }
                    $('#customer_state_id').val(customer.state_id);
                    $('#customer_country_id').val(customer.country_id);

                    $("#product_table_body tr").remove();
                    calculateGrandTotal();
                  }

                  // show_message('success-header',response.message);
                  CustomerToast.fire({
                    type: 'success',
                    title: response.message
                  });  
                }
                else
                {
                  // show_message('success-header',response.message);
                  CustomerToast.fire({
                    type: 'success',
                    title: response.message
                  });  

                  location.reload(true);
                }
              }
              else
              {
                // show_message('failure-header',response.message);
                CustomerToast.fire({
                  type: 'error',
                  title: response.message
                });
              }
            },
            error: function () 
            { 
              show_message('failure-header','Please contact the administrator if you are keep facing this issue.');   
            }
        });
      }    
    });
    $("form#addCustomerForm .field_validation").on("blur keyup",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#addCustomerForm #err_"+id).text(field+ " field is required.");
          if($('form#addCustomerForm #'+id).hasClass('is-valid')){
            $('form#addCustomerForm #'+id).removeClass('is-valid');
          }
          $('form#addCustomerForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#addCustomerForm #err_"+id).text("");
          $('form#addCustomerForm #'+id).removeClass('is-invalid');
          $('form#addCustomerForm #'+id).addClass('is-valid');
        }
    });
    $(document).on('hidden.bs.modal','#add_customer_modal', function () {
      $('form#addCustomerForm .field_validation').each(function() {
        var id    = $(this).attr('id');
        $("form#addCustomerForm #"+id).val("");
        $("form#addCustomerForm #err_"+id).text("");
        $('form#addCustomerForm #'+id).removeClass('is-invalid');
        $('form#addCustomerForm #'+id).removeClass('is-valid');
      });
    });
    $('#add_customer_modal').on('shown.bs.modal', function () {

      $("form#addCustomerForm #customer_name").focus();
      
      var company_country_id  = '<?=$this->company_settings_model->get_company_records()->country_id?>';

      $('#country_id').html('<option value="">Select</option>');

      $.ajax({
        url: "<?php echo base_url('utility/get_countries') ?>/",
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          for(i=0;i<data.length;i++)
          {
            $('#country_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }

          $('#country_id').val(company_country_id).trigger('change');
        }
      });
    });

    $('#country_id').change(function(){

      var id = $(this).val();

      var company_state_id    = '<?=$this->company_settings_model->get_company_records()->state_id?>';
       // alert(id);
      $('#state_id').html('<option value="">Select</option>');
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
        url: "<?php echo base_url('utility/get_states') ?>/"+id,
        type: "GET",
        dataType: "JSON",
        success: function(data){
          for(i=0;i<data.length;i++){
            $('#state_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }

          $('#state_id').val(company_state_id).trigger('change');
        }
      });
    });

    $('#state_id').change(function(){
      var id = $(this).val();
      
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
         url: "<?php echo base_url('utility/get_cities') ?>/"+id,
         type: "GET",
         dataType: "JSON",
         success: function(data){
           for(i=0;i<data.length;i++){
             $('#city_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
           }
         }
      });
    });
  });
  
</script>