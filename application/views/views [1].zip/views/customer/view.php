<?php $this->load->view('layout/header');?>


<div class="wrapper">
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row mb-2">
        <div class="col-sm-12">
          <ol class="breadcrumb breadcrumb-custom float-sm-left">
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('header_people')?></a></li>
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('customer_header')?></a></li>
            <li class="breadcrumb-item active"><?=$this->lang->line('customer_view')?></li>
          </ol>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header secondary-header">
              <h3 class="card-title"><?=$this->lang->line('customer_view')?></h3>
              <!-- <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-tt="tooltip" title="<?=$this->lang->line('hide_details')?>">
                  <i class="fas fa-minus"></i>
                </button>
              </div> -->
            </div>
            <div class="card-body p-0">

              <table class="table table-striped">
                <tr>
                  <td width="20%"><label><?=$this->lang->line('customer_name')?></label></td>
                  <td width="5%"> : </td>
                  <td><?=$customer->customer_name ?></td>
                </tr>
                <tr>
                  <td><label><?=$this->lang->line('customer_gstin')?></label></td>
                  <td> : </td>
                  <td><?=$customer->gstin ?></td>
                </tr>
                <tr>
                  <td><label><?=$this->lang->line('customer_email')?></label></td>
                  <td> : </td>
                  <td><?=$customer->email ?></td>
                </tr>
                <tr>
                  <td><label><?=$this->lang->line('customer_phone')?></label></td>
                  <td> : </td>
                  <td><?=$customer->phone ?></td>
                </tr>
                <tr>
                  <td><label><?=$this->lang->line('customer_country_id')?></label></td>
                  <td> : </td>
                  <td><?=$customer->country_name ?></td>
                </tr>
                <tr>
                  <td><label><?=$this->lang->line('customer_state_id')?></label></td>
                  <td> : </td>
                  <td><?=$customer->state_name ?></td>
                </tr>
                <tr>
                  <td><label><?=$this->lang->line('customer_city_id')?></label></td>
                  <td> : </td>
                  <td><?=$customer->city_name ?></td>
                </tr>
                <tr>
                  <td><label><?=$this->lang->line('customer_address')?></label></td>
                  <td> : </td>
                  <td><?=$customer->address ?></td>
                </tr>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>

      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header purple-header">
              <h3 class="card-title"><?=$this->lang->line('sale_view')?></h3>
              <div class="card-tools">
                
              </div>
            </div>
            <div class="card-body p-0 m-0">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th><?=$this->lang->line('sale_reference_no')?></th>
                    <th><?=$this->lang->line('sale_invoice_date')?></th>
                    <th><?=$this->lang->line('sale_customer')?></th>
                    <th><?=$this->lang->line('sale_total_discount').' ('.$this->session->userdata('currency_symbol').')'?></th>
                    <th><?=$this->lang->line('sale_total_taxable_value').' ('.$this->session->userdata('currency_symbol').')'?></th>
                    <th><?=$this->lang->line('sale_tds').' ('.$this->session->userdata('currency_symbol').')'?></th>
                    <th><?=$this->lang->line('sale_total_tax').' ('.$this->session->userdata('currency_symbol').')'?></th>
                    <th><?=$this->lang->line('sale_total').' ('.$this->session->userdata('currency_symbol').')'?></th>
                   
                  </tr>
                </thead>
                <tbody>
                  <?php 

                    $total_taxable_value  = 0;
                    $total_discount       = 0;
                    $total_tax            = 0;
                    $total                = 0;
                    $total_tds            = 0;

                    if(sizeof($sales) > 0)
                    {
                      foreach ($sales as $value) 
                      {
                        $total_taxable_value  += $value->total_taxable_value;
                        $total_discount       += $value->total_discount;
                        $total_tax            += $value->total_tax;
                        $total                += $value->total;
                        $total_tds            += $value->tds
                  ?>
                  <tr>                        
                    <td><?=$value->reference_no?></td>
                    <td><?php echo date('d-m-Y', strtotime($value->invoice_date));?></td>
                    <td><?php echo $value->customer_name;?></td>
                    <td><?=$value->total_discount?></td>
                    <td><?=$value->total_taxable_value?></td>
                    <td><?=$value->tds?></td>
                    <td><?=$value->total_tax?></td>
                    <td><?=$value->total?></td>
                  </tr>
                  <?php  
                      }
                    }
                    else
                    {
                  ?>
                  <tr>
                    <td colspan="8">No Record(s) are available.</td>
                  </tr>
                  <?php
                    }
                  ?>
                </tbody>
                <tfoot class="bg-gray disabled footer_data">
                  <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_discount?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_taxable_value?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_tds?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_tax?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total?></th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<?php $this->load->view('layout/footer');?>