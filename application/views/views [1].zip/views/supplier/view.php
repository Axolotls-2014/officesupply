<?php $this->load->view('layout/header');?>

<div class="wrapper">
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row mb-2">
        <div class="col-sm-12">
          <ol class="breadcrumb breadcrumb-custom float-sm-left">
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('header_expense')?></a></li>
            <li class="breadcrumb-item"><a href="<?=base_url('supplier')?>"><?=$this->lang->line('supplier_header')?></a></li>
            <li class="breadcrumb-item active"><?=$this->lang->line('supplier_view')?></li>
          </ol>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header secondary-header">
              <h3 class="card-title"><?=$this->lang->line('supplier_view')?></h3>
              <!-- <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div> -->
            </div>
            <div class="card-body p-0">
              <table class="table table-striped">
                <tbody>
                  <tr>
                    <td width="20%"><label><?=$this->lang->line('supplier_company_name')?></label></td>
                    <td width="5%"> : </td>
                    <td><?=$supplier->company_name ?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_gst_registration_type')?></label></td>
                    <td> : </td>
                    <td>
                      <?php 
                        if($supplier->gst_registration_type == 0)
                        {
                          echo $this->lang->line('gst_reg_type_not_reg');
                        }
                        else if($supplier->gst_registration_type == 2)
                        {
                          echo $this->lang->line('gst_reg_type_composite'); 
                        }
                        else if($supplier->gst_registration_type == 1)
                        {
                          echo $this->lang->line('gst_reg_type_reg'); 
                        }
                      ?>  
                    </td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_gstin')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->gstin?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_email')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->email?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_phone')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->phone?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_address')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->address?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_country_id')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->country_name?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_state_id')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->state_name ?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_city_id')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->city_name ?></td>
                  </tr>
                  <tr>
                    <td><label><?=$this->lang->line('supplier_website')?></label></td>
                    <td> : </td>
                    <td><?=$supplier->website ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header purple-header">
              <h3 class="card-title"><?=$this->lang->line('expense_list')?></h3>
            </div>
            <div class="card-body m-0 p-0">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th width="9%"><?=$this->lang->line('expense_date')?></th>
                    <th><?=$this->lang->line('expense_expense_category')?></th>
                    <th><?=$this->lang->line('expense_supplier')?></th>
                    <th><?=$this->lang->line('expense_document')?></th>
                    <th><?=$this->lang->line('expense_remarks')?></th>
                    <!-- <th width="9%"><?=$this->lang->line('expense_amount')?></th>
                    <th width="9%"><?=$this->lang->line('expense_cgst')?></th>
                    <th width="9%"><?=$this->lang->line('expense_sgst')?></th>
                    <th width="9%"><?=$this->lang->line('expense_igst')?></th> -->
                    <th width="9%"><?=$this->lang->line('expense_total_amount').'('.$this->session->userdata('currency_symbol').')'?></th>
                    <th width="9%"><?=$this->lang->line('expense_paid_amount').'('.$this->session->userdata('currency_symbol').')'?></th>
                    <th width="9%"><?=$this->lang->line('expense_due_amount').'('.$this->session->userdata('currency_symbol').')'?></th>
                 
                  </tr>
                </thead>
                
                <tbody>
                  <?php 
                    $total_amount   = 0;
                    $total_cgst     = 0;
                    $total_sgst     = 0;
                    $total_igst     = 0;
                    $total_t_amount = 0;
                    $total_paid_amount = 0;

                    if(sizeof($expenses) > 0)
                    {
                      foreach ($expenses as $value) 
                      {
                        $total_amount   += $value->amount;
                        $total_cgst     += $value->cgst_tax;
                        $total_sgst     += $value->sgst_tax;
                        $total_igst     += $value->igst_tax;
                        $total_t_amount += $value->total_amount


                  ?>
                  <tr>                        
                    
                    <td><?php echo date('d-m-Y', strtotime($value->date));?></td>
                    <td><?php echo $value->expense_category_name;?></td>
                    <td><?php echo $value->company_name;?></td>
                    
                    <td>
                      <div id="document_list">
                        <?php 
                          

                          if($value->document != '' || $value->document != null)
                          {
                            $document_array = explode(",", $value->document);
                            for ($i=0; $i < sizeof($document_array); $i++) 
                            {
                              $file_name_without_ext  = explode(".", $document_array[$i])[0];
                              $file_ext         = explode(".", $document_array[$i])[1];

                              $actual_file_name     = substr($file_name_without_ext, 0, -14).'.'.$file_ext;
                        ?>
                        <div class="btn-group" style="padding-bottom: 10px;">
                          <a target="_blank" class="btn btn-warning btn-xs" id="<?=$document_array[$i]?>" href="<?=base_url('attachment/download_attachment/'.$document_array[$i])?>" data-tt="tooltip" title="<?php echo $actual_file_name?>">
                            <i class="fa fa-paperclip"></i>
                          </a>
                        </div>
                        <?php 
                            }
                          }
                        ?>
                      </div>
                    </td>
                    <td>
                      <?=$value->remarks?>
                    </td>
                    <!-- <td><?php echo $value->amount;?></td>
                    <td><?php echo $value->cgst;?></td>
                    <td><?php echo $value->sgst;?></td>
                    <td><?php echo $value->igst;?></td> -->
                    <td><?php echo $value->total_amount;?></td>
                    <td>
                      <?php
                        $paid_amount = $this->transaction_model->get_total_transaction_amount($value->id,'E');
                        $total_paid_amount += $paid_amount;
                        echo $paid_amount;
                      ?>
                    </td>
                    <td><?php echo $value->total_amount-$paid_amount;?></td>
                    
                    
                  </tr>
                  <?php  
                      }
                    }
                    else
                    {
                  ?>
                  <tr>
                    <td colspan="11"><?php echo $this->lang->line('no_records_available');?></td>
                  </tr>
                  <?php
                    }
                  ?>
                </tbody>
                <tfoot>
                  <tr class="bg-gray disabled footer_data">
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <!-- <th><?=$this->session->userdata('currency_symbol').' '.$total_amount?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_cgst?>s</th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_sgst?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_igst?></th> -->
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_t_amount?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.$total_paid_amount?></th>
                    <th><?=$this->session->userdata('currency_symbol').' '.($total_t_amount-$total_paid_amount)?></th>
                    
                  </tr>
                </tfoot>
              </table>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<?php $this->load->view('layout/footer');?>