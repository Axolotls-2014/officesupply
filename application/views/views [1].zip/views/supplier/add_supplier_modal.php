
<div class="example-modal">
  <div class="modal fade" id="add_supplier_modal">
    <div class="modal-dialog">
      <div class="modal-content">
        <form role="form" method="post" name="addSupplierForm" id="addSupplierForm">
          <div class="modal-header text-left">
            <h4 class="modal-title"><?php echo $this->lang->line('supplier_add');?></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
            <h4>
              <?php echo $this->lang->line('lbl_cust_delete_modal');?>
            </h4>
          </div>
          <div class="modal-body">
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_company_name')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <input type="text" name="company_name" value="<?=set_value('company_name') ?>" class="form-control form-control-sm field_validation" id="company_name" placeholder="<?=$this->lang->line('supplier_company_name')?>"><?=form_error('company_name', '<div class="text-danger">', '</div>');?>
                <span id="err_company_name" class="error invalid-feedback"><?=form_error('company_name');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputPassword3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_gst_registration_type')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <select class="form-control form-control-sm select2bs4 field_validation" name="gst_registration_type" id="gst_registration_type" width="100%" placeholder="<?=$this->lang->line('supplier_gst_registration_type')?>">
                  <option value=""><?=$this->lang->line('select')?></option>
                  <option value="1"><?=$this->lang->line('gst_reg_type_reg')?></option>
                  <option value="0"><?=$this->lang->line('gst_reg_type_not_reg')?></option>
                  <option value="2"><?=$this->lang->line('gst_reg_type_composite')?></option>
                </select>
                <span id="err_gst_registration_type" class="error invalid-feedback"><?=form_error('gst_registration_type');?></span>
              </div>
            </div>
            <div class="form-group row gstin_row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_gstin')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <input type="text" name="gstin" value="<?=set_value('gstin') ?>" class="form-control form-control-sm" id="gstin" placeholder="<?=$this->lang->line('supplier_gstin')?>">
                <span id="err_gstin" class="error invalid-feedback"><?=form_error('gstin', '<div class="text-danger">', '</div>');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_contact_person_name')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <input type="text" name="contact_person_name" value="<?=set_value('contact_person_name') ?>" class="form-control form-control-sm field_validation" id="contact_person_name" placeholder="<?=$this->lang->line('supplier_contact_person_name')?>"><?=form_error('contact_person_name', '<div class="text-danger">', '</div>');?>
                <span id="err_contact_person_name" class="error invalid-feedback"><?=form_error('contact_person_name');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_contact_person_designation')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <input type="text" name="contact_person_designation" value="<?=set_value('contact_person_designation') ?>" class="form-control form-control-sm field_validation" id="contact_person_designation" placeholder="<?=$this->lang->line('supplier_contact_person_designation')?>"><?=form_error('contact_person_designation', '<div class="text-danger">', '</div>');?>
                <span id="err_contact_person_designtion" class="error invalid-feedback"><?=form_error('contact_person_designation');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_email')?>
              </label>
              <div class="col-sm-6">
                <input type="text" name="email" value="<?=set_value('email') ?>" class="form-control form-control-sm" id="email" placeholder="<?=$this->lang->line('supplier_email')?>">
                <span id="err_email" class="error invalid-feedback"><?=form_error('email');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_phone')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <input type="number" name="phone" value="<?=set_value('phone') ?>" class="form-control form-control-sm field_validation" id="phone" placeholder="<?=$this->lang->line('supplier_phone')?>"><?=form_error('phone', '<div class="text-danger">', '</div>');?>
                <span id="err_phone" class="error invalid-feedback"><?=form_error('phone');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_address')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <input type="text" name="address" value="<?=set_value('address') ?>" class="form-control form-control-sm field_validation" id="address" placeholder="<?=$this->lang->line('supplier_address')?>"><?=form_error('address', '<div class="text-danger">', '</div>');?>
                <span id="err_address" class="error invalid-feedback"><?=form_error('address', '<div class="text-danger">', '</div>');?></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_country_id')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <select class="form-control form-control-sm select2bs4 field_validation" name="country_id" id="country_id" placeholder="<?=$this->lang->line('supplier_country_id')?>" width="100%">
                  <option value=""><?=$this->lang->line('select')?></option>
                </select>
                <span id="err_country_id" class="error invalid-feedback"></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label">
                <?=$this->lang->line('supplier_state_id')?>
                <span class="text-danger">*</span>
              </label>
              <div class="col-sm-6">
                <select class="form-control form-control-sm select2bs4 field_validation" name="state_id" id="state_id" placeholder="<?=$this->lang->line('supplier_state_id')?>" width="100%">
                  <option value=""><?=$this->lang->line('select')?></option>
                </select>
                <span id="err_state_id" class="error invalid-feedback"></span>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label"><?=$this->lang->line('supplier_city_id')?></label>
              <div class="col-sm-6">
                <select class="form-control form-control-sm select2bs4" name="city_id" id="city_id" width="100%">
                  <option value=""><?=$this->lang->line('select')?></option>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-4 col-form-label"><?=$this->lang->line('supplier_website')?></label>
              <div class="col-sm-6">
                <input type="text" name="website" value="<?=set_value('website') ?>" class="form-control form-control-sm" id="website" placeholder="<?=$this->lang->line('supplier_website')?>">
                <span id="err_website" class="error invalid-feedback"><?=form_error('website');?></span>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

            <button type="submit" name="submit" id="supplierSubmit" class="btn btn-primary"><?php echo $this->lang->line('submit');?></button>
            <button type="button" class="btn btn-default" data-dismiss="modal">
              <?php echo $this->lang->line('btn_modal_close');?>
            </button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
  </div>
</div>

<script type="text/javascript">

  $(document).ready(function(e){

    $('.gstin_row').css('display','none');

    // regular expression for gstin format
    var gstReg = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

    const SupplierToast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 10000
    });

    $('#supplierSubmit').click(function(e){
      e.preventDefault();

      var isError = false;

      $('form#addSupplierForm .field_validation').each(function() {
          
          var id    = $(this).attr('id');
          var value = $(this).val();
          var field = $(this).attr('placeholder');

          if(value==null || value==""){
            $("form#addSupplierForm #err_"+id).text(field+ " field is required.");
            if($('form#addSupplierForm #'+id).hasClass('is-valid')){
              $('form#addSupplierForm #'+id).removeClass('is-valid');
            }
            $('form#addSupplierForm #'+id).addClass('is-invalid');
            isError = true;
          }
          else
          {
            $("form#addSupplierForm #err_"+id).text("");
            $('form#addSupplierForm #'+id).removeClass('is-invalid');
            $('form#addSupplierForm #'+id).addClass('is-valid');
          }

          if (!gstReg.test($('form#addSupplierForm #gstin').val()) && $('form#addSupplierForm #gst_registration_type').val() == 1) 
          {
            if($('form#addSupplierForm #gstin').val() == '')
            {
              // $('form#addSupplierForm #gstin').val('');
              $("form#addSupplierForm #err_gstin").text('GSTIN field is required');
              $('form#addSupplierForm #gstin').addClass('is-invalid');
              isError = true;
            }
            else
            {
              // $('form#addSupplierForm #gstin').val('');
              $("form#addSupplierForm #err_gstin").text('Please enter valid GSTIN');
              $('form#addSupplierForm #gstin').addClass('is-invalid');
              isError = true;  
            }
          }
          else
          {
            
            $("form#addSupplierForm #err_gstin").text("");
            $('form#addSupplierForm #gstin').removeClass('is-invalid');
            $('form#addSupplierForm #gstin').addClass('is-valid');
          }
      });


      if(isError == true)
      {
        return false;
      }  
      else 
      {
        var formData = $('#addSupplierForm').serialize();
        $('#supplierSubmit').text('<?=$this->lang->line("please_wait")?>').attr('disabled','disabled');

        $.ajax({
            url: '<?php echo base_url("supplier/add") ?>',
            type: 'POST',
            dataType : 'json',
            data: formData,                       
            success: function (response) {

              var supplier = response.supplier;

              if(response.code==1)
              {
                $('#add_supplier_modal').modal('hide');
                $('#supplierSubmit').text('<?=$this->lang->line("submit")?>').removeAttr('disabled');
                
                $('#supplier_id').html('');
                $('#supplier_id').append('<option value="">Select</option>');
                
                for(i=0;i<response['suppliers'].length;i++)
                { 
                  $('#supplier_id').append('<option value="' + response['suppliers'][i].id + '">' + response['suppliers'][i].company_name+'</option>');
                }

                $('#supplier_id').val(response['id']).attr("selected","selected");

                if($("#warehouse_id").length)
                { 
                  if($("#warehouse_id").val() != '')
                  {
                    $("#supplier_id").closest('.row').siblings().fadeIn(10);  
                  }
                  $('#supplier_state_id').val(supplier.state_id);
                  $('#supplier_country_id').val(supplier.country_id);
                  $('#supplier_gstin').val(supplier.gstin);

                  $("#product_table_body tr").remove();
                  calculateGrandTotal();
                }

                // show_message('success-header',response.message);
                SupplierToast.fire({
                  type: 'success',
                  title: response.message
                });
              }
              else
              {
                // show_message('failure-header',response.message);
                SupplierToast.fire({
                  type: 'error',
                  title: response.message
                });
              }
            },
            error: function () 
            { 
              show_message('failure-header','Please contact the administrator if you are keep facing this issue.');   
            }
        });
      }    
    });

    $("form#addSupplierForm .field_validation").on("blur change keyup",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#addSupplierForm #err_"+id).text(field+ " field is required.");
          if($('form#addSupplierForm #'+id).hasClass('is-valid')){
            $('form#addSupplierForm #'+id).removeClass('is-valid');
          }
          $('form#addSupplierForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#addSupplierForm #err_"+id).text("");
          $('form#addSupplierForm #'+id).removeClass('is-invalid');
          $('form#addSupplierForm #'+id).addClass('is-valid');
        }
    });

    $(document).on('hidden.bs.modal','#add_supplier_modal', function () {

      $('.gstin_row').css('display','none');

      $('form#addSupplierForm .form-control').each(function() {
        var id = $(this).attr('id');
        $("form#addSupplierForm #"+id).val("");
        $("form#addSupplierForm #err_"+id).text("");
        $('form#addSupplierForm #'+id).removeClass('is-invalid');
        $('form#addSupplierForm #'+id).removeClass('is-valid');
      });
    });
    $('#add_supplier_modal').on('shown.bs.modal', function () {

      $("form#addSupplierForm #company_name").focus();

      var company_country_id  = '<?=$this->company_settings_model->get_company_records()->country_id?>';
    
      $('#country_id').html('<option value="">Select</option>');

      $.ajax({
        url: "<?php echo base_url('utility/get_countries') ?>/",
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          for(i=0;i<data.length;i++)
          {
            $('#country_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }
          $('#country_id').val(company_country_id).trigger('change');
        }
      });
    });

    $("form#addSupplierForm #gstin").on("blur keyup change",  function (event){

      if (!gstReg.test($('form#addSupplierForm #gstin').val()) && $('form#addSupplierForm #gst_registration_type').val() == 1) 
      {        
        if($('form#addSupplierForm #gstin').val() == "")
        {
          $("form#addSupplierForm #err_gstin").text("GSTIN field is required.");
          $('form#addSupplierForm #gstin').addClass('is-invalid');
          return false;
        }
        else
        {
          $("form#addSupplierForm #err_gstin").text("Please enter valid GSTIN.");
          $('form#addSupplierForm #gstin').addClass('is-invalid');
          return false;
        }
      }
      else
      {
        $("form#addSupplierForm #err_gstin").text("");
        $('form#addSupplierForm #gstin').removeClass('is-invalid');
        $('form#addSupplierForm #gstin').addClass('is-valid');
      }
    });

    $("form#addSupplierForm #gst_registration_type").on("blur keyup change",  function (event){

      if ($('form#addSupplierForm #gst_registration_type').val() == 1) 
      {   
        $('.gstin_row').fadeIn(10);

        if($('form#addSupplierForm #gstin').val() == "")
        {
          $("form#addSupplierForm #err_gstin").text("GSTIN field is required.");
          $('form#addSupplierForm #gstin').addClass('is-invalid');
          return false;
        }
        else
        {
          $("form#addSupplierForm #err_gstin").text("Please enter valid GSTIN.");
          $('form#addSupplierForm #gstin').addClass('is-invalid');
          return false;
        }
      }
      else
      {
        $('.gstin_row').fadeOut(10);

        $("form#addSupplierForm #err_gstin").text("");
        $('form#addSupplierForm #gstin').removeClass('is-invalid');
        $('form#addSupplierForm #gstin').addClass('is-valid');
      }
    });

    $('#country_id').change(function(){

      var id = $(this).val();

      var company_state_id    = '<?=$this->company_settings_model->get_company_records()->state_id?>';
       // alert(id);
      $('#state_id').html('<option value="">Select</option>');
      $('#city_id').html('<option value="">Select</option>');
      $.ajax({
        url: "<?php echo base_url('utility/get_states') ?>/"+id,
        type: "GET",
        dataType: "JSON",
        success: function(data){
          for(i=0;i<data.length;i++){
            $('#state_id').append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
          }
          $('#state_id').val(company_state_id).trigger('change');
        }
      });
    });
  });
  
</script>