<table class="table table-bordered table-striped">
	<thead>
	  <tr>
	    <th><?=$this->lang->line('purchase_reference_no')?></th>
      <th><?=$this->lang->line('purchase_invoice_no')?></th>
      <th><?=$this->lang->line('purchase_date')?></th>
      <th><?=$this->lang->line('purchase_supplier')?></th>
      <th><?=$this->lang->line('purchase_total_discount').' ('.$this->session->userdata('currency_symbol').')'?></th>
      <th><?=$this->lang->line('purchase_total_taxable_value').' ('.$this->session->userdata('currency_symbol').')'?></th>
      <th><?=$this->lang->line('purchase_igst_tax')?></th>
	    <th><?=$this->lang->line('purchase_cgst_tax')?></th>
	    <th><?=$this->lang->line('purchase_sgst_tax')?></th>
      <th><?=$this->lang->line('purchase_total').' ('.$this->session->userdata('currency_symbol').')'?></th>

	  </tr>
	</thead>
	<tbody>
    <?php

    	$total_taxable_value 	= 0.0;
    	$total_discount 			= 0.0;
    	$total_tax 						= 0.0;
    	$total 								= 0.0;
    	$total_igst 					= 0.0;
	  	$total_cgst 					= 0.0;
	  	$total_sgst 					= 0.0;
    	

      if(sizeof($purchases) > 0)
      {
        foreach ($purchases as $value) 
        {
        	$total_taxable_value 	+= $value->total_taxable_value;
        	$total_discount 			+= $value->total_discount;
        	$total_tax 						+= $value->total_tax;
        	$total 								+= $value->total;

        	$purchase = $this->purchase_model->get_purchase_tax_individual($value->id);

	      	$total_igst 					+= $purchase->igst_tax;
	      	$total_cgst 					+= $purchase->cgst_tax;
	      	$total_sgst 					+= $purchase->sgst_tax;
    ?>
    <tr>                        
      <td><?=$value->reference_no?></td>
      <td><?=$value->invoice_no?></td>
      <td><?=date('d-m-Y', strtotime($value->purchase_date));?></td>
      <td><?=$value->company_name;?></td>
      <td><?=$value->total_discount?></td>
      <td><?=$value->total_taxable_value?></td>
      <td><?=$purchase->igst_tax?></td>
	    <td><?=$purchase->cgst_tax?></td>
	    <td><?=$purchase->sgst_tax?></td>
      <td><?=$value->total?></td>
    </tr>
    <?php  
        }
      }
      else
      {
    ?>
    <tr>
      <td colspan="10"><?=$this->lang->line('no_records_available')?></td>
    </tr>
    <?php
      }
    ?>
  </tbody>
	<tfoot class="bg-gray disabled footer_data">
		<tr>
	    <th colspan="4"></th>
	    <th><?=$this->session->userdata('currency_symbol').' '.$total_discount?></th>
	    <th><?=$this->session->userdata('currency_symbol').' '.$total_taxable_value?></th>
	    <th><?=$this->session->userdata('currency_symbol').' '.$total_igst?></th>
	    <th><?=$this->session->userdata('currency_symbol').' '.$total_cgst?></th>
	    <th><?=$this->session->userdata('currency_symbol').' '.$total_sgst?></th>
	    <th><?=$this->session->userdata('currency_symbol').' '.$total?></th>
	  </tr>
	</tfoot>
</table>