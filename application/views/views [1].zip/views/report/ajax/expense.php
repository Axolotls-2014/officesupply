<table class="table table-bordered table-striped">
  <thead>
    <tr>
      <th><?=$this->lang->line('expense_date')?></th>
      <th><?=$this->lang->line('expense_expense_category')?></th>
      <th><?=$this->lang->line('expense_supplier')?></th>
      <th><?=$this->lang->line('expense_amount').'('.$this->session->userdata('currency_symbol').')'?></th>
      <th><?=$this->lang->line('expense_cgst').'('.$this->session->userdata('currency_symbol').')'?></th>
      <th><?=$this->lang->line('expense_sgst').'('.$this->session->userdata('currency_symbol').')'?></th>
      <th><?=$this->lang->line('expense_igst').'('.$this->session->userdata('currency_symbol').')'?></th>
      <th><?=$this->lang->line('expense_total_amount').'('.$this->session->userdata('currency_symbol').')'?></th>
    </tr>
  </thead>
  <tbody>
    <?php

    	$total_amount 		= 0;
    	$total_cgst   		= 0;
    	$total_sgst 			= 0;
    	$total_igst 			= 0;
    	$total_t_amount 	= 0;

      if(sizeof($expenses) > 0)
      {
        foreach ($expenses as $value) 
        {
        	$cgst 					= ($value->amount*$value->cgst)/100;
        	$sgst 					= ($value->amount*$value->sgst)/100;
        	$igst 					= ($value->amount*$value->igst)/100;

        	$total_amount 	+= $value->amount;
        	$total_cgst   	+= $cgst;
        	$total_sgst   	+= $sgst;
        	$total_igst   	+= $igst;
        	$total_t_amount += $value->total_amount;
    ?>
    <tr>                        
      <td><?php echo date('d-m-Y', strtotime($value->date));?></td>
      <td><?php echo $value->expense_category_name;?></td>
      <td><?php echo $value->company_name;?></td>
      <td><?php echo $value->amount;?></td>
      <td><?php echo $cgst;?></td>
      <td><?php echo $sgst;?></td>
      <td><?php echo $igst;?></td>
      <td><?php echo $value->total_amount;?></td>
    </tr>
    <?php  
        }
      }
      else
      {
    ?>
    <tr>
      <td colspan="8"><?=$this->lang->line('no_records_available')?></td>
    </tr>
    <?php
      }
    ?>
  </tbody>
  <tfoot  class="bg-gray disabled footer_data">
  	<tr>
  		<th colspan="3"></th>
      <th><?=$this->session->userdata('currency_symbol').' '.$total_amount?></th>
      <th><?=$this->session->userdata('currency_symbol').' '.$total_cgst?></th>
      <th><?=$this->session->userdata('currency_symbol').' '.$total_sgst?></th>
      <th><?=$this->session->userdata('currency_symbol').' '.$total_igst?></th>
      <th><?=$this->session->userdata('currency_symbol').' '.$total_t_amount;?>
  	</tr>
  </tfoot>
</table> 