<div class="row">
	<div class="col-md-12">
		<table width="100%" class="table table-bordered">
			<tr>
				<td width="90%" align="right">Year Ending</td>
				<td width="10%" align="right"><strong><?=$year_ending?></strong></td>
			</tr>
		</table>
	</div>
</div>

