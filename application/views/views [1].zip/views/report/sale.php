<?php $this->load->view('layout/header'); ?>

	<style type="text/css">
		.footer_data{
			font-size: 20px;
		}
	</style>
  	<div class="wrapper">
	  	<div class="content-wrapper">
		    <section class="content-header">
		      <div class="row mb-2">
		        <div class="col-sm-12">
		          <ol class="breadcrumb breadcrumb-custom float-sm-left">
		            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
		            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('header_reports')?></a></li>
		            <li class="breadcrumb-item active"><?=$this->lang->line('sales_report')?></li>
		          </ol>
		        </div>
		      </div>
		    </section>

		    <!-- Main content -->
		    <section class="content">
		    	<div class="row">
		    		<div class="col-md-12">
            <!-- general form elements disabled -->
            	<form role="form" id="saleReportForm" name="saleReportForm" method="POST" action="<?php echo base_url("report/sale") ?>" target="_blank">
	            	<div class="card card-primary">
		              <div class="card-header">
		                <h3 class="card-title">
		                	<i class="fas fa-funnel-dollar"></i>
		                	<?=$this->lang->line('filter_report')?>
		                </h3>
		                <div class="card-tools">

		                  <div class="input-group">
		                    <button type="button" class="btn btn-default float-right" id="daterange-btn">
		                      <i class="far fa-calendar-alt"></i> Date range picker
		                      <i class="fas fa-caret-down"></i>
		                    </button>
		                  </div>
		            
	                    <!-- <button type="button" class="btn btn-tool" data-card-widget="collapse">
	                    	<i class="fas fa-minus"></i>
	                    </button> -->
	                  </div>
		              </div>
	              	<!-- /.card-header -->
		              <div class="card-body"> 
	                  <div class="row">
	                    <div class="col-sm-4">
	                      <div class="form-group">
				                  <label><?=$this->lang->line('from_date')?></label>
				                  <div class="input-group">
				                    <div class="input-group-prepend">
				                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
				                    </div>
				                    <input type="text" class="form-control datepicker" name="from_date" id="from_date" style="z-index:999 !important">
				                  </div>
				                </div>
	                    </div>
	                    <div class="col-sm-4">
	                      <div class="form-group">
				                  <label><?=$this->lang->line('to_date')?></label>
				                  <div class="input-group">
				                    <div class="input-group-prepend">
				                      <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
				                    </div>
				                    <input type="text" class="form-control datepicker" name="to_date" id="to_date" value="<?=date('d-m-Y')?>">
				                  </div>
				                </div>
	                    </div>
	                    <div class="col-sm-4">
	                    	<div class="form-group">
                          <label for="customer"><?=$this->lang->line('sale_customer')?></label>
                          <select class="form-control form-control-sm select2bs4" name="customer_id" id="customer_id" width="100%" class="add-row">
                            <option value=""><?=$this->lang->line('select')?></option>
                            <?php
                              foreach ($customers as $value) {
                            ?>
                              <option value="<?=$value->id;?>" <?php echo set_select('id', $value->id); ?>>
                                <?= $value->customer_name;?>
                              </option>
                            <?php 
                              }
                            ?>
                          </select>
                          <span id="err_customer_id" class="error invalid-feedback"><?=form_error('customer_id');?></span>
                        </div>
	                    </div>
	                  </div>
		              </div>
	              	<!-- /.card-body -->
		              <div class="card-footer">
		              	<input type="hidden" name="action_type" id="action_type" value="">
		              	<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
		              	<button type="submit" name="submit" id="submitSaleReport" class="btn btn-info"><?=$this->lang->line('search')?></button>
		              </div>
	            	</div>
	            </form>
	            <div class="card card-primary">
	              <div class="card-header">
	                <h3 class="card-title"><?=$this->lang->line('sales_report')?></h3>
	                <div class="card-tools">
	                	<button type="button" class="btn btn-tool bt-danger" id="export">
                    	<i class="fas fa-file-export"></i>
                    	<?=$this->lang->line('export')?>
                    </button>
                    <button type="button" class="btn btn-tool" id='print'>
                    	<i class="fas fa-print"></i>
                    	<?=$this->lang->line('print')?>
                    </button>
                    <button type="button" class="btn btn-tool" id='pdf'>
                    	<i class="fas fa-file-pdf"></i>
                    	<?=$this->lang->line('pdf')?>
                    </button>
                  </div>
	              </div>
	              <!-- /.card-header -->
	              <div class="card-body sales_list">
	                <table class="table table-bordered table-striped">
		                <thead>
		                  <tr>
		                    <th><?=$this->lang->line('sale_reference_no')?></th>
		                    <th><?=$this->lang->line('sale_invoice_date')?></th>
		                    <th><?=$this->lang->line('sale_customer')?></th>
		                    <th><?=$this->lang->line('sale_total_discount').' ('.$this->session->userdata('currency_symbol').')'?></th>
		                    <th><?=$this->lang->line('sale_total_taxable_value').' ('.$this->session->userdata('currency_symbol').')'?></th>
		                    <th><?=$this->lang->line('sale_tds').' ('.$this->session->userdata('currency_symbol').')'?></th>
		                    <th><?=$this->lang->line('sale_total_igst_tax')?></th>
										    <th><?=$this->lang->line('sale_total_cgst_tax')?></th>
										    <th><?=$this->lang->line('sale_total_sgst_tax')?></th>
		                    <th><?=$this->lang->line('sale_total').' ('.$this->session->userdata('currency_symbol').')'?></th>
		                  </tr>
		                </thead>
		                <tbody>
		                  <?php

		                  	$total_taxable_value 	= 0.0;
		                  	$total_discount 			= 0.0;
		                  	$total_tax 						= 0.0;
		                  	$total 								= 0.0;
		                  	$total_igst 					= 0.0;
										  	$total_cgst 					= 0.0;
										  	$total_sgst 					= 0.0;
										  	$total_tds 						= 0.0;									  	
		                  	

		                    if(sizeof($sales) > 0)
		                    {
		                      foreach ($sales as $value) 
		                      {
		                      	$total_taxable_value 	+= $value->total_taxable_value;
		                      	$total_discount 			+= $value->total_discount;
		                      	$total_tax 						+= $value->total_tax;
		                      	$total 								+= $value->total;
		                      	$total_tds 						+= $value->tds;

		                      	$sale = $this->sale_model->get_sale_tax_individual($value->id);

										      	$total_igst 					+= $sale->igst_tax;
										      	$total_cgst 					+= $sale->cgst_tax;
										      	$total_sgst 					+= $sale->sgst_tax;
		                  ?>
		                  <tr>                        
		                    <td><?=$value->reference_no?></td>
		                    <td><?=date('d-m-Y', strtotime($value->invoice_date));?></td>
		                    <td><?=$value->customer_name;?></td>
		                    <td><?=$value->total_discount?></td>
		                    <td><?=$value->total_taxable_value?></td>
		                    <td><?=$value->tds?></td>
		                    <td><?=$sale->igst_tax?></td>
										    <td><?=$sale->cgst_tax?></td>
										    <td><?=$sale->sgst_tax?></td>
		                    <td><?=$value->total?></td>
		                  </tr>
		                  <?php  
		                      }
		                    }
		                    else
		                    {
		                  ?>
		                  <tr>
		                    <td colspan="9"><?=$this->lang->line('no_records_available')?></td>
		                  </tr>
		                  <?php
		                    }
		                  ?>
		                </tbody>
		                <tfoot class="bg-gray disabled footer_data">
		                	<tr>
		                    <th colspan="3"></th>
		                    <th><?=$this->session->userdata('currency_symbol').' '.$total_discount?></th>
		                    <th><?=$this->session->userdata('currency_symbol').' '.$total_taxable_value?></th>
		                    <th><?=$this->session->userdata('currency_symbol').' '.$total_tds?></th>
		                    <th><?=$this->session->userdata('currency_symbol').' '.$total_igst?></th>
										    <th><?=$this->session->userdata('currency_symbol').' '.$total_cgst?></th>
										    <th><?=$this->session->userdata('currency_symbol').' '.$total_sgst?></th>
		                    <th><?=$this->session->userdata('currency_symbol').' '.$total?></th>
		                  </tr>
		                </tfoot>
		              </table>
	              </div>
	            </div>
	            <!-- /.card -->
	          </div>
		    	</div>

		    </section>
		    <!-- /.content -->
	  	</div>
	    <aside class="control-sidebar control-sidebar-dark"></aside>
	    
  	</div>
  
<?php $this->load->view('layout/footer'); ?>

<script type="text/javascript">
	$(document).ready(function(e){
		$('#submitSaleReport').click(function(e){
			// e.preventDefault();

			var action_type = $('#action_type').val();

			if(action_type == 'export')
			{
				return true;
			}
			else if(action_type == 'pdf')
			{
				return true;
			}
			else if(action_type == 'print')
			{
				return true;
			}
			else
			{
				e.preventDefault();

				var formData = $('#saleReportForm').serialize();
				$(this).text('<?=$this->lang->line('searching')?>');

				setTimeout(function(){ 

					$.ajax({
		        url: '<?php echo base_url("report/sale") ?>',
		        type: 'POST',
		        dataType : 'json',
		        data: formData,                       
		        success: function (response) {
		          $('.sales_list').html(response.sales);
		          $('#submitSaleReport').text('<?=$this->lang->line('search')?>');
		        },
		        error: function () 
		        { 
		          show_message('failure-header','Please contact the administrator if you are keep facing this issue.');   
		        }
		      });	
				}, 2000);
			}
		});

		$('#export').click(function(e){
			$('#action_type').val('export');
			$('#submitSaleReport').trigger('click');  
			$('#action_type').val('');
		});
		$('#print').click(function(e){
			$('#action_type').val('print');		
			$('#submitSaleReport').trigger('click');  
			$('#action_type').val('');
		});
		$('#pdf').click(function(e){
			$('#action_type').val('pdf');
			$('#submitSaleReport').trigger('click');  
			$('#action_type').val('');
		});

		//Date range as a button
    $('#daterange-btn').daterangepicker({

        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {

      	// alert(start.format('DD-MM-Y') + ' - ' + end.format('DD-MM-Y'));
      	$('#from_date').val(start.format('DD-MM-Y'));
				$('#to_date').val(end.format('DD-MM-Y'));


        // $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
    })
	});
</script>