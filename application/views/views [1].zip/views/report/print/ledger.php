
<style type="text/css">
	td{
		padding: 4px;
	}
  .footer_data{
    font-size: 12px;
    background-color: #dee2e6;
  }
</style>

<table width="100%" style="text-align: center;font-size: 12px;">
	<tr>
		<td>
			<?=$company_setting->company_name?>
		</td>
	</tr>
	<tr>
		<td>
			<?=$company_setting->address_line1.', '.$company_setting->address_line2.', '.$company_setting->city_name.', '.$company_setting->state_name.', '.$company_setting->country_name.'. - '.$company_setting->pincode ?>
		</td>
	</tr>
	<tr>
		<td>
			<?= $this->lang->line('print_email').': '.$company_setting->email.', '.$this->lang->line('print_mobile').'.: '.$company_setting->mobile.'. '?>
		</td>
	</tr>
	<tr>
		<td>
			<?=$this->lang->line('ledger_report')?>
		</td>
	</tr>
	<tr>
		<td>
			<?=$this->lang->line('print_from_date').': '.$from_date.' - '.$this->lang->line('print_to_date').': '.$to_date?>
		</td>
	</tr>
</table>
<br/>
<table width="100%" border="1" style="text-align: center;font-size: 12px;" cellspacing="0" cellpadding="0">
	<tr class="bg-light">
		<td width="40%"><b><?=$ledger_detail->title?></b></td>
		<td width="15%">Opening Bal.</td>
		<td width="15%">
			<b>
				<?php
					$o_balance = 0;
					$c_balance = 0;
					$opening_balance = 0;

					$from_date 	= ($from_date == '') ? null : date('Y-m-d',strtotime($from_date));
					$to_date 		= ($to_date == '') ? null : date('Y-m-d',strtotime($to_date));

					if($from_date == null)
					{
						$opening_balance = $ledger_detail->opening_balance;
					}
					else
					{

						$opening_balance = $ledger_detail->opening_balance;

						$transactions = $this->transaction_model->get_transaction_by_ledger_id_for_closing_balance($ledger_detail->id,$from_date);

						if($transactions != null)
						{
							foreach ($transactions as $trans) 
							{
								if($trans->voucher_type == 'D')
								{
									$opening_balance += $trans->cr_amount;
								}
								else
								{
									$opening_balance -= $trans->dr_amount;
								}
							}	
						}
						
					}

					$o_balance = $opening_balance;

					echo $opening_balance;
					
				?>
			</b>
		</td>
		<td width="15%">Closing Bal.</td>
		<td width="15%">
			<b>
				<?php 

					$from_date 	= ($from_date == '') ? null : date('Y-m-d',strtotime($from_date));
					$to_date 		= ($to_date == '') ? null : date('Y-m-d',strtotime($to_date));

					$transactions 		= $this->transaction_model->get_transaction_by_ledger_id($ledger_detail->id,$from_date, $to_date);

					if($transactions != null)
					{
						foreach ($transactions as $trans) 
						{
							// if($ledger_detail->group_title == SUNDRY_CREDITORS_GROUP)
							// {
							// 	if($trans->voucher_type == 'D')
							// 	{
							// 		$opening_balance += $trans->dr_amount;
							// 	}
							// 	else
							// 	{
							// 		$opening_balance -= $trans->cr_amount;
							// 	}	
							// }
							// else
							// {
								if($trans->voucher_type == 'D')
								{
									$opening_balance += $trans->cr_amount;
								}
								else
								{
									$opening_balance -= $trans->dr_amount;
								}	
							// }
							
						}	
					}

					$c_balance = $opening_balance;
					echo abs($c_balance);
				?>
			</b>
		</td>
	</tr>
</table>
<br/>
<table width="100%" border="1" style="text-align: center;font-size: 12px;" cellspacing="0" cellpadding="0">
	<tr style="font-size:12px;font-weight: bolder" class="bg-secondary disabled">
		<td width="20%">Date</td>
		<td width="40%">Particulars</td>
		<td width="20%"><?=$this->lang->line('dr_amount')?></td>
		<td width="20%"><?=$this->lang->line('cr_amount')?></td>
	</tr>
	<tr>
		<td></td>
		<td>
			<u><?=strtoupper("Opening Balance")?></u>
		</td>
		<td>
			<?=$o_balance?>
		</td>
		<td>0.000</td>
	</tr>
	<?php 
		$total_cr_amount = 0;
		$total_dr_amount = 0;

		foreach ($transaction_details as $value) 
		{
			$transaction 	= $this->transaction_model->get_single_record($value->transaction_id);
			$from_account = $transaction->from_account;
			$to_account 	= $transaction->to_account;
	?>	
			
			<tr>
				<td><?=date('d-m-Y',strtotime($value->transaction_date))?></td>
				<td align="left">
					<?php
						if($transaction->module == SALE_MODULE)
						{
							$sale = $this->sale_model->get_sale_single_record($transaction->entry_id);

							if($transaction->module == SALE_MODULE && $from_account == $ledger_detail->id)
							{
								$ledger 					= $this->ledger_model->get_single_record($to_account);
								echo $ledger->title.' - '.$ledger->group_title." ";

							}
							else
							{
								$ledger = $this->ledger_model->get_single_record($from_account);
								echo $ledger->title.' - '.$ledger->group_title.' ';		
								echo ' [<a href="'.base_url('sale/view/'.$sale->id).'" target="_blank">'.$sale->reference_no.'</a>]';
							}
							
						}
						else if($transaction->module == EXPENSE_MODULE)
						{
							if($to_account != '')
							{
								if($transaction->module == EXPENSE_MODULE && $to_account == $ledger_detail->id)
								{
									if($from_account != '')
									{
										$ledger 					= $this->ledger_model->get_single_record($from_account);
										echo $ledger->title.' - '.$ledger->group_title;		
									}
									else
									{
										echo strtoupper($transaction->reference_no);
									}
								}
								else
								{
									$ledger = $this->ledger_model->get_single_record($to_account);
									echo $ledger->title.' - '.$ledger->group_title;		
								}
							}
							else
							{
								$expense 					= $this->expense_model->get_single_record($transaction->entry_id);
								$expense_category = $this->expense_category_model->get_single_record($expense->expense_category_id);
								$ledger 					= $this->ledger_model->get_single_record($expense_category->ledger_id);
								echo $ledger->title.' - '.$ledger->group_title;	
							}
						}
						else if($transaction->module == PURCHASE_MODULE)
						{
							if($transaction->module == PURCHASE_MODULE && $to_account == $ledger_detail->id)
							{
								
									$ledger 					= $this->ledger_model->get_single_record($from_account);
									echo $ledger->title.' - '.$ledger->group_title;		
								
							}
							else
							{
								$ledger = $this->ledger_model->get_single_record($to_account);
								echo $ledger->title.' - '.$ledger->group_title;		
							}
						}
						else if($transaction->module == BANK_MODULE)
						{
							if($transaction->module == BANK_MODULE && $to_account == $ledger_detail->id)
							{
								$ledger = $this->ledger_model->get_single_record($from_account);
								echo $ledger->title.' - '.$ledger->group_title;			
							}
							else
							{
								$ledger = $this->ledger_model->get_single_record($to_account);
								echo $ledger->title.' - '.$ledger->group_title;		
							}	
						}
					?>
				</td>
				<td>
					<?php
						if($ledger_detail->group_title == BANK_ACCOUNT_GROUP || $ledger_detail->group_title == CAPITAL_ACCOUNT_GROUP || $ledger_detail->group_title == CASH_GROUP)
						{
							$total_cr_amount += $value->cr_amount;
							echo $value->cr_amount;	
						}
						else
						{
							$total_dr_amount += $value->dr_amount;
							echo $value->dr_amount;
							
						}
					?>
				</td>
				<td>
					<?php 
						if($ledger_detail->group_title == BANK_ACCOUNT_GROUP || $ledger_detail->group_title == CAPITAL_ACCOUNT_GROUP || $ledger_detail->group_title == CASH_GROUP)
						{
							$total_dr_amount += $value->dr_amount;
							echo $value->dr_amount;	
						}
						else
						{
							$total_cr_amount += $value->cr_amount;
							echo $value->cr_amount;
						}
					?>
				</td>
			</tr>
	<?php
		}
	?>			
	<tr>
		<td></td>
		<td>
			<u><?=strtoupper("Closing Balance")?></u>
		</td>
		<td>
			<?php 
				if($ledger_detail->group_title == BANK_ACCOUNT_GROUP || $ledger_detail->group_title == CAPITAL_ACCOUNT_GROUP || $ledger_detail->group_title == CASH_GROUP)
				{
					if($c_balance < 0)
					{
						echo abs($c_balance);
					}
					else
					{
						echo '0.000';
					}
				}
				else
				{
					if($c_balance > 0)
					{
						echo $c_balance;
					}
					else
					{
						echo '0.000';
					}
				}
			?>
		</td>
		<td>
			<?php 
				if($ledger_detail->group_title == BANK_ACCOUNT_GROUP || $ledger_detail->group_title == CAPITAL_ACCOUNT_GROUP || $ledger_detail->group_title == CASH_GROUP)
				{
					if($c_balance < 0)
					{
						echo '0.000';
					}
					else
					{
						echo abs($c_balance);
					}
				}
				else
				{
					if($c_balance > 0)
					{
						echo '0.000';
					}
					else
					{
						echo abs($c_balance);
					}
				}
			?>
		</td>
		<!-- <?php 
			if($c_balance > 0)
			{
		?>
				<td>
					<?=$c_balance?>
				</td>
				<td>
					0.0
				</td>
		<?php
			}
			else
			{
		?>
				<td>
					0.0
				</td>
				<td>
					<?=abs($c_balance)?>
				</td>
		<?php
			}
		?> -->
		
	</tr>
	<tr style="font-size: 12px;font-weight: bold" class="bg-light">
		<td width="20%"></td>
		<td width="40%"></td>
		<td width="20%">
			<?php 
				if($ledger_detail->group_title == BANK_ACCOUNT_GROUP || $ledger_detail->group_title == CAPITAL_ACCOUNT_GROUP || $ledger_detail->group_title == CASH_GROUP)
				{
					if($c_balance < 0)
					{
						echo $total_cr_amount+$c_balance;
					}
					else
					{
						echo $total_cr_amount;
					}
				}
				else
				{
					if($c_balance > 0)
					{
						echo $total_dr_amount+$c_balance;
					}
					else
					{
						echo $total_dr_amount;
					}
				}
			?>
		</td>
		<td width="20%">
			<?php 
				if($ledger_detail->group_title == BANK_ACCOUNT_GROUP || $ledger_detail->group_title == CAPITAL_ACCOUNT_GROUP || $ledger_detail->group_title == CASH_GROUP)
				{
					if($c_balance < 0)
					{
						echo $total_dr_amount;	
					}
					else
					{
						echo $total_dr_amount+abs($c_balance);
					}
				}
				else
				{
					if($c_balance > 0)
					{
						echo $total_cr_amount;
					}
					else
					{
						echo $total_cr_amount+abs($c_balance);
					}
				}
			?>
		</td>
	</tr>
</table>
<script>window.print();</script>