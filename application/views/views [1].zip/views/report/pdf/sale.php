<style type="text/css">
	th,td{
		padding: 4px;
	}
	.footer_data{
		font-size: 14px;
		background-color: #dee2e6;
	}
</style>
<table width="100%" style="text-align: center;font-size: 14px;">
	<tr>
		<td>
			<?=$company_setting->company_name?>
		</td>
	</tr>
	<tr>
		<td>
			<?=$company_setting->address_line1.', '.$company_setting->address_line2.', '.$company_setting->city_name.', '.$company_setting->state_name.', '.$company_setting->country_name.'. - '.$company_setting->pincode ?>
		</td>
	</tr>
	<tr>
		<td>
			<?= $this->lang->line('print_email').': '.$company_setting->email.', '.$this->lang->line('print_mobile').'.: '.$company_setting->mobile.'. '?>
		</td>
	</tr>
	<tr>
		<td>
			<?=$this->lang->line('sales_report')?>
		</td>
	</tr>
	<tr>
		<td>
			<?=$this->lang->line('print_from_date').': '.$from_date.' - '.$this->lang->line('print_to_date').': '.$to_date?>
		</td>
	</tr>
</table>
<table border="1" style="text-align: center;font-size: 12px" width="100%" cellpadding="0" cellspacing="0">
	<thead>
	  <tr>
	    <th><?=$this->lang->line('sale_reference_no')?></th>
	    <th><?=$this->lang->line('sale_invoice_date')?></th>
	    <th><?=$this->lang->line('sale_customer')?></th>
	    <th><?=$this->lang->line('sale_total_discount')?></th>
	    <th><?=$this->lang->line('sale_total_taxable_value')?></th>
	    <th><?=$this->lang->line('sale_tds')?></th>
	    <th><?=$this->lang->line('sale_total_igst_tax')?></th>
	    <th><?=$this->lang->line('sale_total_cgst_tax')?></th>
	    <th><?=$this->lang->line('sale_total_sgst_tax')?></th>
	    <th><?=$this->lang->line('sale_total')?></th>
	  </tr>
	</thead>
	<tbody>
	  <?php

	  	$total_taxable_value 	= 0.0;
	  	$total_discount 			= 0.0;
	  	$total_tax 						= 0.0;
	  	$total 								= 0.0;
	  	$total_profit					= 0.0;
	  	$total_igst 					= 0.0;
	  	$total_cgst 					= 0.0;
	  	$total_sgst 					= 0.0;
	  	$total_tds 						= 0.0;
	  	
	  	

	    if(sizeof($sales) > 0)
	    {
	      foreach ($sales as $value) 
	      {
	      	$total_taxable_value 	+= $value->total_taxable_value;
	      	$total_discount 			+= $value->total_discount;
	      	$total_tax 						+= $value->total_tax;
	      	$total 								+= $value->total;
	      	$total_profit 				+= $total-$total_tax-$total_discount;
	      	$total_tds 						+= $value->tds;

	      	$sale = $this->sale_model->get_sale_tax_individual($value->id);

	      	$total_igst 					+= $sale->igst_tax;
	      	$total_cgst 					+= $sale->cgst_tax;
	      	$total_sgst 					+= $sale->sgst_tax;
	  ?>
	  <tr>                        
	    <td><?=$value->reference_no?></td>
	    <td><?=date('d-m-Y', strtotime($value->invoice_date));?></td>
	    <td><?=$value->customer_name;?></td>
	    <td><?=$value->total_discount?></td>
	    <td><?=$value->total_taxable_value?></td>
	    <td><?=$value->tds?></td>
	    <td><?=$sale->igst_tax?></td>
	    <td><?=$sale->cgst_tax?></td>
	    <td><?=$sale->sgst_tax?></td>
	    <td><?=$value->total?></td>
	  </tr>
	  <?php  
	      }
	    }
	    else
	    {
	  ?>
	  <tr>
	    <td colspan="9"><?=$this->lang->line('no_records_available')?></td>
	  </tr>
	  <?php
	    }
	  ?>
	</tbody>
	<tfoot class="bg-gray disabled footer_data">
		<tr>
	    <th colspan="3"></th>
	    <th><?=$total_discount?></th>
	    <th><?=$total_taxable_value?></th>
	    <th><?=$total_tds?></th>
	    <th><?=$total_igst?></th>
	    <th><?=$total_cgst?></th>
	    <th><?=$total_sgst?></th>
	    <th><?=$total?></th>
	  </tr>
	</tfoot>
</table>
