<table class="table table-bordered">
	<thead>
		<tr style="background-color: #D3D3D3">
			<th><?=$this->lang->line('warehouse_name')?></th>
			<th><?=$this->lang->line('quantity')?></th>
			<th><?=$this->lang->line('cost')?></th>
			<th><?=$this->lang->line('price')?></th>
		</tr>
	</thead>
	<tbody>
		<?php

			$total_quantity = 0;
			$total_cost 		= 0;
			$total_price    = 0;

			if(sizeof($product_quantity_data) > 0)
			{

				foreach ($product_quantity_data as $value) 
				{
					if($value->quantity > 0)
					{
						$total_quantity += $value->quantity;
						$total_cost 		+= $value->cost;
						$total_price 		+= $value->price;
					}
		?>
		<tr>
			<td><?=$this->warehouse_model->get_single_record($value->warehouse_id)->name?></td>
			<td><?=$value->quantity?></td>
			<td><?=$value->cost?></td>
			<td><?=$value->price?></td>
		</tr>
		<?php
				}	 
		?>
		<tr style="font-weight: bolder;background-color: #ccc">
			<td>
				<?=$this->lang->line('total');?>
			</td>	
			<td><?=$total_quantity?></td>
			<td><?=$total_quantity*$total_cost?></td>
			<td><?=$total_quantity*$total_price?></td>
		</tr>
		<?php
			}
			else
			{
		?>
			<tr>
				<td colspan="4"></td>
			</tr>
		<?php
			} 
		?>

	</tbody>
	
</table>