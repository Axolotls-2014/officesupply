<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
      body{
        font-size: 10px;
      }
      tr{
        font-size: 10px;
      }
      table, th, td {
        border-collapse: collapse;
      }

      th, td {
        text-align: left;
        border-bottom: 1px solid #ddd;
        padding: 8px;
      }
    </style>
  </head>
  <body>
      <center><h3><?=$this->lang->line('tax_purchase_under_gst')?> <br/><?=$this->lang->line('quotation_for_recipient')?></h3></center>
      <h3 style="float: left"><i class="fa fa-globe"></i> <?=$company_setting->company_name?></h3><h3 style="float: right"><?=$this->lang->line('date')?>: <?=date('d-m-Y', strtotime($purchase->purchase_date))?></h3>
      <br/><br/>                     
      <table style="width:100%">
        <tr>
          <th style="width: 30%;"><?=$this->lang->line('bill_to')?></th>
          <th style="width: 30%;"><?=$this->lang->line('name_address_supplier')?></th>
          <th style="width: 30%;"><?=$this->lang->line('purchase_details')?></th>
        </tr>
        <tr>
          <td>
            <strong><?=$company_setting->company_name?></strong><br>
            <?=$company_setting->address_line1?><br>
            <?=$company_setting->address_line2?><br>
            <?=$company_setting->city_name.', '.$company_setting->state_name.', '.$company_setting->country_name?><br>
            <?=$company_setting->pincode?><br>
            <?=$this->lang->line('phone')?>: <?=$company_setting->mobile?><br>
            <?=$this->lang->line('email')?>: <?=$company_setting->email?><br>
            <strong><?=$this->lang->line('gstin_of_supplier')?>: <?=$company_setting->gstin?></strong><br>
          </td>
          <td style="vertical-align: text-top;">
            <strong><?=$supplier_detail->company_name?></strong><br>
            <?=$supplier_detail->address?><br>
            <?=$supplier_detail->city_name.', '.$supplier_detail->state_name.', '.$supplier_detail->country_name?><br>
            <?=$this->lang->line('phone')?>: <?=$supplier_detail->phone?><br>
            <?=$this->lang->line('email')?>: <?=$supplier_detail->email?><br>
            <?=$this->lang->line('gstin')?>: <?=$supplier_detail->gstin?><br>
          </td>
          <td style="vertical-align: text-top;">
            <b><?=$this->lang->line('purchase_id')?></b><?=$purchase->reference_no?><br>
            <b><?=$this->lang->line('receipt_voucher_no')?></b>
            
          </td>
        </tr>
      </table>
      <br/>
      <table style="width: 100%; font-size: 10px;">
        <thead>
          <tr>
            <th width="2%"><?=$this->lang->line('sr')?></th>
            <th><?=$this->lang->line('product')?></th>
            <th><?=$this->lang->line('hsn')?></th>
            <th><?=$this->lang->line('qty')?></th>
            <th><?=$this->lang->line('purchase_cost')?> </th>
            <th><?=$this->lang->line('discount')?> </th>
            <th><?=$this->lang->line('purchase_uom')?> </th>
            <th><?=$this->lang->line('total_taxable_value')?> </th>
            <th width="15%"><?=$this->lang->line('tax')?> </th>
            <th><?=$this->lang->line('subtotal')?> </th>
          </tr>
        </thead>
         <tbody>
          <?php 
            $i = 1;
            $total_quantity = 0;
            $total_cost    = 0;
            $total_discount_amount = 0;
            $total_taxable_value = 0;
            $total_tax = 0;
            $total_subtotal = 0;
            foreach ($purchase_items as $row) 
            {
              $total_quantity         += $row->quantity;
              $total_cost             += $row->cost;
              $total_discount_amount  += $row->discount_amount;
              $total_taxable_value    += $row->taxable_value;
              $total_tax              += $row->cgst_tax+$row->sgst_tax+$row->igst_tax;
              $total_subtotal         += $row->subtotal;
          ?>
            <tr>
              <td><?=$i++?></td>
              <td><?=$row->product_name.'<br/>'.$row->description?></td>
              <td><?=$row->hsn?></td>
              <td><?=$row->quantity?></td>
              <td><?=$row->cost?></td>
              <td><?=$row->discount_amount?></td>
              <td><?=$row->uom_uom?></td>    
              <td><?=$row->taxable_value?></td>
              <td>
                <?php 
                  if($company_setting->country_id == $supplier_detail->country_id && !($company_setting->gstin =='' && $supplier_detail->gstin == ''))
                  {
                    if($company_setting->state_id == $supplier_detail->state_id)
                    {
                ?>
                      CGST : <?=$row->cgst_tax?>
                      (<?=$row->cgst?>%)
                      <br>SGST : <?=$row->sgst_tax?>
                      (<?=$row->sgst?>%)
                <?php
                    }
                    else
                    {
                ?>
                      IGST : <?=$row->igst_tax?>
                      (<?=$row->cgst?>%)
                <?php 
                    }
                  }
                  else
                  {
                ?>
                    N/A
                <?php
                  }
                ?>
              </td>
              <td><?=$row->subtotal?></td>
            </tr>
          <?php 
            }
          ?>
            <tr style="font-size: 10px;font-weight: bolder;">
              <td colspan="3">
                <?=$this->lang->line('total_amount_due')?>   
              </td>
              <td><?=$total_quantity?></td>
              <td><?=$total_cost?></td>
              <td><?=$total_discount_amount?></td>
              <td></td>
              <td><?=$total_taxable_value?></td>
              <td><?=$total_tax?></td>
              <td><?=$total_subtotal?></td>
            </tr>
            <tr style="font-size: 10px;font-weight: bolder;">
              <td colspan="9">
                <?=$this->lang->line('advance_adjusted')?> 
              </td>
              <td><?="0.0"?></td>
            </tr>
            <tr style="font-size: 10px;font-weight: bolder;">
              <td colspan="9">
                <?=$this->lang->line('rounded_off')?>
              </td>
              <td>
                <?php 
                  if((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)) > 0)
                  {
                    echo '+'.number_format((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)),2);
                  }
                  else
                  {
                    echo '-'.number_format((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)),2);
                  }
                ?>
              </td>
            </tr>
            <tr style="font-size: 10px;font-weight: bolder;">
              <td colspan="9">
                <?=$this->lang->line('balance_payable')?>
              </td>
              <td>
                <?php echo round($purchase->total_taxable_value+$purchase->total_tax);?>
              </td>
            </tr>
            <tr style="font-size: 10px;font-weight: bold; ">
              <td colspan="5">
                <?=$this->lang->line('amount_in_words')?>
              </td>
              <td colspan="5" style="text-align: right">
                <?php echo $this->numbertowords->convert_number(round($purchase->total_taxable_value+$purchase->total_tax));?>
              </td>
            </tr>
        </tbody>
      </table>
      <table style="width: 100%;">
        <tr>
          <td colspan="6" style="font-weight: bolder;"><?=$this->lang->line('terms_condition')?></td>
          <td colspan="3" style="font-weight: bolder;"><?=$this->lang->line('certified_messages')?></td>
        </tr>
        <tr>
          <td colspan="6">
            <?=$purchase->terms_and_condition?>
          </td>
          <td colspan="3">
            <?=$this->lang->line('for')?>, <?=strtoupper($company_setting->company_name)?><br/><br/><br/>
            <h3><?=$this->lang->line('signatory')?></h3>
          </td>
        </tr>
      </table>
     
  </body>
</html>
