<?php 
  $this->load->view('layout/header');
  $currency = $this->company_settings_model->get_company_records()->currency_symbol;
?>

<style type="text/css">
  .search { position: relative; }
  .search input { text-indent: 20px;}
  .search .fa-search { 
    position: absolute;
    top: 9px;
    left: 20px;
    font-size: 18px;
    padding-left: 8px;
  }
  .search_product{
    background-color: #F8F8F8;
    height: 35px;
    padding-left: 25px;
    font-size: 18px;
  }

  .search_product::-webkit-input-placeholder { /* Chrome/Opera/Safari */
    padding-left: 5px;
    font-size: 18px;
  }
  .search_product::-moz-placeholder { /* Firefox 19+ */
    font-size: 18px;
  }
  .search_product:-ms-input-placeholder { /* IE 10+ */
    font-size: 18px;
  }
  .search_product:-moz-placeholder { /* Firefox 18- */
    font-size: 18px;
  }
  .product_row{
    background: #fffee9 !important;
  }
  .highlight_row{
    /*animation: fadeOut 5s forwards;*/
    background: #fed9c6 !important;
    -webkit-transition: all 0.5s ease;
    -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
  }
  .quantity_update_message{
    width: 100% !important;
    padding-left: 40% !important;
  }

  .discount_type{
    padding-left: 20px;
  }
  .discount_amount{
    padding-right: 10px !important;
  }
  .delete_item{
    cursor:pointer;
  }
  .total_data{
    font-size: 18px;
    font-weight: bolder;
  }



</style>
  <div class="wrapper">
    <div class="content-wrapper">
      <section class="content-header">
          <div class="row mb-2">
            <div class="col-sm-12">
              <ol class="breadcrumb breadcrumb-custom float-sm-left">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item "><a href="#"><?=$this->lang->line('header_inventory')?></a></li>
                <li class="breadcrumb-item "><a href="<?=base_url('purchase')?>"><?=$this->lang->line('purchase_header')?></a></li>
                <li class="breadcrumb-item active"><?=$this->lang->line('purchase_edit')?></li>
              </ol>
            </div>
          </div>
      </section>

      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <form class="form-horizontal" name="editPurchaseForm" id="editPurchaseForm" method="POST" action="<?=base_url('purchase/edit')?>">
              <div class="card">
                <div class="card-header"><?=$this->lang->line('purchase_edit')?></h6>
                </div>
                <div class="card-body">
                  <div class="col-sm-12">
                    <div class="row">
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_reference_no')?></label>
                          <input type="text" class="form-control" id="reference_no" name="reference_no" value="<?=$purchase->reference_no?>" readonly>
                        </div>
                      </div>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_invoice_no')?></label>
                          <input type="text" class="form-control" id="invoice_no" name="invoice_no" value="<?=$purchase->invoice_no?>" placeholder="<?=$this->lang->line('purchase_invoice_no')?>">
                          <span id="err_invoice_no" class="error invalid-feedback"><?=form_error('invoice_no');?></span>
                        </div>
                      </div>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_date')?></label>
                          <input type="text" class="form-control datepicker" id="purchase_date" name="purchase_date" value="<?=date('d-m-Y', strtotime($purchase->purchase_date))?>" placeholder="Invoice Date">
                          <span id="err_purchase_date" class="error invalid-feedback"><?=form_error('purchase_date');?></span>
                        </div>
                      </div>
                      <div class="col-sm-3">
                        <div class="form-group">
                          <label for="supplier"><?=$this->lang->line('purchase_warehouse')?><span class="validation-color">*</span>
                          </label>
                          <div class="input-group input-group-sm">
                            <?php
                              foreach ($warehouses as $value) 
                              {
                                if($value->id == $purchase->warehouse_id)
                                {
                                  echo $value->name;
                                }
                              }
                            ?>
                            <input type="hidden" name="warehouse_id" id="warehouse_id" value="<?=$purchase->warehouse_id?>">
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-3">
                        <div class="form-group">
                          <label for="supplier"><?=$this->lang->line('purchase_supplier')?><span class="validation-color">*</span>
                          </label>
                          <div class="input-group input-group-sm">
                            <?php
                              foreach ($supplier as $value) 
                              { 
                                if($value->id == $purchase->supplier_id)
                                {
                                  echo $value->company_name;
                                }
                              }
                            ?>
                          </div>
                          <input type="hidden" name="supplier_id" id="supplier_id" value="<?=$purchase->supplier_id?>">
                          <input type="hidden" name="supplier_gstin" id="supplier_gstin" value="<?=$supplier_detail->gstin?>">
                          <input type="hidden" name="supplier_state_id" id="supplier_state_id" value="<?=$supplier_detail->state_id?>">
                          <input type="hidden" name="supplier_country_id" id="supplier_country_id" value="<?=$supplier_detail->country_id?>">
                          <span id="err_supplier_id" class="error invalid-feedback"><?=form_error('supplier_id');?></span>
                        </div>
                      </div>
                      
                    </div>
                    
                    <div class="row">
                      <div class="col-sm-12 ">
                        <div class="well">
                          <div class="row">
                            <div class="col-sm-12">
                              <a href="" data-toggle="modal" data-tt="tooltip" data-target="#add_product_modal" class="float-right"><?=$this->lang->line('purchase_add_new_product')?></a>
                            </div>
                            <div class="col-sm-12 search">
                              <span class="fa fa-search"></span>
                              <input id="search_product" class="form-control search_product"  type="text" name="search_product"  placeholder="<?=$this->lang->line('purchase_item_search')?>">
                            </div>
                            <div class="col-sm-8">
                              <span class="validation-color" id="err_product"></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" style="height: 20px;"></div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group">
                          <label><?=$this->lang->line('purchase_items')?></label>
                          <table class="table items table-striped table-bordered table-condensed table-hover product_table" name="product_data" id="product_data">
                            <thead>
                              <tr>
                                <th width="2%">
                                  <img src="<?php  echo base_url(); ?>assets/images/bin1.png" />
                                </th>
                                <th class="span2" width="15%"><?=$this->lang->line('product_description')?></th>
                                <th class="span2" width="8%"><?=$this->lang->line('purchase_qty')?></th>
                                <th class="span2" width="10%"><?=$this->lang->line('purchase_cost')?></th>
                                <th class="span2" width="14%"><?=$this->lang->line('purchase_discount')?></th>
                                <th class="span2" width="11%"><?=$this->lang->line('purchase_uom')?></th>
                                <th class="span2" width="8%"><?=$this->lang->line('purchase_taxable_value')?></th>
                                <th class="span2" width="12%"><?=$this->lang->line('purchase_tax')?></th>
                                <th class="span2" width="5%"><?=$this->lang->line('purchase_inclusive')?></th>
                                <th class="span2" width="7%"><?=$this->lang->line('purchase_total')?></th>
                              </tr>
                            </thead>
                            <tbody id="product_table_body">
                              <?php 
                                foreach ($purchase_items as $row) {
                              ?>
                                <tr class="product_row">
                                  <td>
                                    <span class="delete_item"><i class="fas fa-minus-circle text-danger"></i>
                                    </span>
                                    <input type="hidden" name="product_id" value="<?=$row->product_id?>">
                                  </td>

                                  <td>
                                    <span name="description"><?=$row->description?></span>
                                  </td>
                                  
                                  <td>
                                    <input type="number" class="form-control" name="quantity" value="<?=$row->quantity?>" step="1" min="1">
                                    <span name="quantity_update_message" class="quantity_update_message"></span>
                                  </td>
                                  
                                  <td>
                                    <span id="cost_span">
                                      <input type="number" class="form-control text-right" name="cost" step="0.01" value="<?=$row->cost?>" min="1">
                                    </span>
                                  </td>
                                  
                                  <td>
                                    <select class="form-control select2bs4" name="item_discount" style="width: 100%;">
                                      <option value="">Select</option>
                                      <?php 
                                        foreach ($discounts as $value) {
                                      ?>
                                        <option value="<?=$value->id?>"
                                          <?php 
                                            if($value->id == $row->discount_id)
                                              echo ' selected';
                                          ?>
                                        >
                                          <?=$value->name.' ('.$value->value.$this->session->userdata('currency_symbol').')' ?>
                                        </option>
                                      <?php
                                        }
                                      ?>
                                      </option>
                                    </select>
                                    <span name="span_discount_type" class="discount_type">Discount Value :  <?=$this->session->userdata('currency_symbol')?> </span>
                                    <input type="hidden" name="discount_type" value="<?=$row->discount_type?>">
                                    <span name="discount_amount" class="discount_amount"><?=$row->discount_amount?></span>
                                    <input type="hidden" name="discount_value" value="<?=$row->discount_value?>">
                                  </td>
                                  <td>
                                    <input type="hidden" name="uom_id" value="<?=$row->uom_id?>" data-uom_name="<?=$row->uom_name?>" data-uom_uom="<?=$row->uom_uom?>">  
                                    <?=$row->uom_uom?>
                                  </td>
                                  
                                  
                                  <td><span name="taxable_value"><?=$row->taxable_value?></span></td>
                                  
                                  <td>
                                    <?php 
                                      if($company_setting->country_id == $supplier_detail->country_id && !($company_setting->gstin == '' && $supplier_detail->gstin == ''))
                                      {
                                        if($company_setting->state_id == $supplier_detail->state_id)
                                        {
                                    ?>
                                          <input type="hidden" name="tax_id" value="1">CGST : <span name="c_tax"><?=$row->cgst_tax?></span>
                                          (<span name="cgst"><?=$row->cgst?></span>)
                                          <br>SGST : <span name="s_tax"><?=$row->sgst_tax?></span>
                                          (<span name="sgst"><?=$row->sgst?></span>)
                                          <span name="i_tax" style="display:none"><?=$row->igst_tax?></span>
                                          <span name="igst" style="display:none"><?=$row->igst?></span>
                                    <?php
                                        }
                                        else
                                        {
                                    ?>
                                          <input type="hidden" name="tax_id" value="1">IGST : <span name="i_tax"><?=$row->igst_tax?></span>
                                          (<span name="igst"><?=$row->igst?></span>)
                                          <span name="c_tax" style="display:none"><?=$row->cgst_tax?></span>
                                          <span name="cgst" style="display:none"><?=$row->cgst?></span>
                                          <span name="s_tax" style="display:none"><?=$row->sgst_tax?></span>
                                          <span name="sgst" style="display:none"><?=$row->sgst?></span>
                                    <?php 
                                        }
                                      }
                                      else
                                      {
                                    ?>
                                        N/A
                                        <span name="c_tax" style="display:none"><?=$row->cgst_tax?></span>
                                        <span name="cgst" style="display:none"><?=$row->cgst?></span>
                                        <span name="s_tax" style="display:none"><?=$row->sgst_tax?></span>
                                        <span name="sgst" style="display:none"><?=$row->sgst?></span>
                                        <span name="i_tax" style="display:none"><?=$row->igst_tax?></span>
                                        <span name="igst" style="display:none"><?=$row->igst?></span>
                                    <?php
                                      }
                                    ?>
                                    
                                  </td>
                                  
                                  <td>
                                    <input type="hidden" name="tax_type" value="<?=$row->tax_type?>">
                                    <?=($row->tax_type == 0) ? 'No' : 'Yes';?>
                                  </td>
                                  
                                  <td><span name="subtotal"><?=$row->subtotal?></span></td>
                                </tr>
                              <?php 
                                }
                              ?>
                            </tbody>
                          </table>
                          <table class="table table-striped table-bordered table-condensed table-hover total_data" style="font-size: 18px;">
                            <tr>
                              <td align="right" colspan="7"> <?=$this->lang->line('purchase_total_discount')?>(<?=$currency?>)</td>
                              <td align='right' class="text-danger">
                                -<span id="total_discount"><?=$purchase->total_discount?></span>
                                <input type="hidden" name="total_discount" id="t_discount" value="<?=$purchase->total_discount?>">
                              </td>
                            </tr>
                            <tr>
                              <td align="right" colspan="7"><?=$this->lang->line('purchase_total_taxable_value')?>(<?=$currency?>)</td>
                              <td align='right' class="text-success">
                                +<span id="total_taxable_value"><?=$purchase->total_taxable_value?></span>
                                <input type="hidden" name="total_taxable_value" id="t_taxable_value" value="<?=$purchase->total_taxable_value?>">
                              </td>
                            </tr>
                            
                            <tr>
                              <td align="right" colspan="7"><?=$this->lang->line('purchase_total_tax')?>(<?=$currency?>)</td>
                              <td align='right' class="text-success">
                                +<span id="total_tax"><?=$purchase->total_tax?></span>
                                <input type="hidden" name="total_tax" id="t_tax" value="<?=$purchase->total_tax?>">
                              </td>
                            </tr>
                            <tr>
                              <td align="right" colspan="7"><?=$this->lang->line('purchase_total')?>(<?=$currency?>)</td>
                              <td align='right'>
                                <span id="total"><?=$purchase->total?></span>
                                <input type="hidden" name="total" id="t" value="<?=$purchase->total?>">
                              </td>
                            </tr>
                          </table>

                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="control-group">                     
                          <div class="controls">
                            <div class="tabbable">
                              <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                                <li class="nav-item">
                                  <a class="nav-link active" href="#external_note" data-toggle="pill"><?php echo $this->lang->line('purchase_external_note'); ?></a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#internal_note" data-toggle="pill"><?php echo $this->lang->line('purchase_internal_note'); ?></a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#bank_detail" data-toggle="pill"><?php echo $this->lang->line('purchase_bank_detail'); ?></a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#terms_and_condition" data-toggle="pill"><?php echo $this->lang->line('purchase_terms_and_condition'); ?></a>
                                </li>
                              </ul>                           
                              <br>
                              <div class="tab-content">
                                <div class="tab-pane active" id="external_note">
                                  <textarea class="col-sm-12 form-control" name="external_note" rows="4" placeholder="<?php echo $this->lang->line('purchase_external_note'); ?>"><?=str_replace("<br />","",$purchase->external_note)?></textarea>
                                </div>
                                <div class="tab-pane" id="internal_note">
                                  <textarea class="col-sm-12 form-control" name="internal_note" rows="4" placeholder="<?php echo $this->lang->line('purchase_internal_note'); ?>"><?=str_replace("<br />","",$purchase->internal_note)?></textarea>
                                </div>
                                <div class="tab-pane" id="bank_detail">
                                  <textarea class="col-sm-12 form-control" name="bank_detail" rows="4" placeholder="<?php echo $this->lang->line('purchase_bank_detail'); ?>"><?=str_replace("<br />","",$purchase->bank_detail)?></textarea>
                                </div>
                                <div class="tab-pane" id="terms_and_condition">
                                  <textarea class="col-sm-12 form-control" name="terms_and_condition" rows="4" placeholder="<?php echo $this->lang->line('purchase_terms_and_condition'); ?>"><?=str_replace("<br />","",$purchase->terms_and_condition)?></textarea>
                                </div>
                              </div>
                            </div>   
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-footer">
                  <input type="hidden" name="id" value="<?=$purchase->id?>">
                  <input type="hidden" name="purchase_items" id="purchase_items" value="">
                  <input type="hidden" name="company_state_id" id="company_state_id" value="<?=$company_setting->state_id?>">
                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                  <input type="hidden" name="company_country_id" id="company_country_id" value="<?=$company_setting->country_id?>">
                  <button type="submit" name="submit" id="purchaseSubmit" class="btn btn-info"><?=$this->lang->line('purchase_add')?></button>
                  <!-- <button type="submit" name="submit" id="purchaseSubmitPayNow" value="pay" name="pay" class="btn btn-info">Add purchase & Pay Now</button>                      -->
                  <span class="btn btn-default float-right" id="cancel" onclick="cancel('purchase')"><?=$this->lang->line('purchase_cancel')?></span>
                </div>
            </form>
          </div>
        </div>
      </section>
  
    </div>
    <aside class="control-sidebar control-sidebar-dark"></aside>
  </div>

<?php 
  $this->load->view('layout/footer');
  $this->load->view('supplier/add_supplier_modal');
  $this->load->view('warehouse/add_warehouse_modal');
?>

<div class="modal fade" id="emptyPurchaseItemWarningModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header warning-header">
        <h5 class="modal-title" id="exampleModalLabel">Message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        There are no item(s) in Invoice. Please atleast 1 item in invoice.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/disableautofill/src/jquery.disableAutoFill.min.js"></script>

<script type="text/javascript">

  $(document).ready(function(e){

      // $("#supplier_id").closest('.row').siblings().css('display','none');

      // $("#supplier_id").select2({disabled:readonly});

      $('#supplier_id').change(function(e){

        var supplier_id = $(this).val();
        if(supplier_id != '')
        {
          $("#supplier_id").closest('.row').siblings().fadeIn(10);

          $.ajax({
              url: "<?php echo base_url('supplier/get_record_details') ?>",
              type: "POST",
              dataType: "json",
              data: {
                  'supplier_id' : supplier_id,
                  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
              },
              success: function(data){
                var supplier = data.supplier;
                $('#supplier_state_id').val(supplier.state_id);
                $('#supplier_country_id').val(supplier.country_id);
              }
          });
        }
      }); 

      // product search code begin

      var c_mapping = { };

      $(function(){
        $('#search_product').autoComplete({
          minChars: 1,
          source: function(term, suggest){
            term = term.toLowerCase();

            $.ajax({
              url: "<?php echo base_url('product/search') ?>",
              type: "POST",
              dataType: "json",
              data:{
                'term': term,
                'module': '<?=PURCHASE_MODULE?>',
                '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
              },
              success: function(data){
                var products = data;
                var suggestions = [];
                for(var i = 0; i < products.length; ++i) {
                    suggestions.push(products[i].id+' - '+products[i].name+' - '+products[i].product_category_name);
                    c_mapping[products[i].id] = products[i].name;
                }
                suggest(suggestions);
              }
            });
          },
          onSelect: function(event, ui) {
            var str = ui.split(' - ');
            
            var product_id = str[0];

            $.ajax({
              url: "<?php echo base_url('product/get_record_detail') ?>",
              type: "POST",
              dataType: "json",
              data:{
                'product_id': product_id, 
                'module': '<?=PURCHASE_MODULE?>',
                '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
              },
              success: function(data){
                var product = data.product;

                if(!is_product_exist_in_row(product.id))
                {
                  add_row(data);
                }
                else
                {
                  highlight_row(product.id);
                }

                calculateGrandTotal();
                $('#search_product').val('');
              }
            });
          } 
        });
      });

      function add_row(data)
      {
        var supplier_country_id = $('#supplier_country_id').val();
        var supplier_state_id   = $('#supplier_state_id').val();
        var supplier_gstin      = $('#supplier_gstin').val();

        var company_country_id  = $('#company_country_id').val();
        var company_state_id    = $('#company_state_id').val();
        var company_gstin       = '<?=$company_setting->gstin?>';

        var product   = data.product;
        var discounts = data.discount;

        var select_discount = "";
            select_discount += '<select class="form-control select2bs4" name="item_discount" style="width: 100%;">';
            select_discount += '<option value="">Select</option>';
              for(a=0;a<discounts.length;a++)
              {
                var type_symbol;
                if(discounts[a].type == 0)
                {
                  type_symbol = "<?=$this->session->userdata('currency_symbol')?>";
                }
                else
                {
                  type_symbol = "%"; 
                }
                select_discount += '<option value="' + discounts[a].id + '">' + discounts[a].name+'('+discounts[a].value  + type_symbol +')'+ '</option>';
              }
            select_discount += '</select>'
            select_discount += '<span name="span_discount_type" class="discount_type">Discount Value :  <?=$this->session->userdata('currency_symbol');?> </span><input type="hidden" name="discount_type" value="0">';
            select_discount += '<span name="discount_amount" class="discount_value">0.0</span><input type="hidden" name="discount_value" value="'+0+'">';

        var input_uom = '<input type="hidden" name="uom_id" value="'+product.uom_id+'" data-uom_name="'+product.uom_name+'" data-uom_uom="'+product.uom_uom+'">'+product.uom_uom;

        var input_quantity =  '<input type="number" class="form-control" name="quantity" value="1" step="1" min="1"><span name="quantity_update_message" class="quantity_update_message"></span>';
        var taxable_value  =  '<span name="taxable_value">'+product.cost+'</span>';

        /************    tax begin   *****************/
        var tax = '<input type="hidden" name="tax_id" value="'+product.tax_id+'">';

        if(company_country_id == supplier_country_id && !(supplier_gstin == '' && company_gstin == ''))
        {
          if(company_state_id == supplier_state_id)
          {
            tax += 'CGST : <span name="c_tax">'+0.0+'</span>(<span name="cgst">'+product.cgst+'</span>)<br/>';
            tax += 'SGST : <span name="s_tax">'+0.0+'</span>(<span name="sgst">'+product.sgst+'</span>)';
            tax += '<span name="i_tax"style="display:none">0</span><span name="igst" style="display:none">0</span>';
          }
          else
          {
            tax += 'IGST : <span name="i_tax">'+0.0+'</span>(<span name="igst">'+product.igst+'</span>)<br/>';
            tax += '<span name="c_tax" style="display:none">0</span><span name="cgst" style="display:none">0</span>';
            tax += '<span name="s_tax" style="display:none">0</span><span name="sgst" style="display:none">0</span>';
          }
        }
        else
        {
          tax += 'N/A';
          tax += '<span name="i_tax" style="display:none">0</span><span name="igst" style="display:none">0</span>';
          tax += '<span name="c_tax" style="display:none">0</span><span name="cgst" style="display:none">0</span>';
          tax += '<span name="s_tax" style="display:none">0</span><span name="sgst" style="display:none">0</span>';
        }

        /************    tax end   *****************/

        /************    tax type begin   *****************/

        var tax_type  = '<input type="hidden" name="tax_type" value="'+product.tax_type+'">';
        tax_type      += (product.tax_type == 0) ? "No" : "Yes";

        /************    tax type end   *****************/

        var newRow = $('<tr class="product_row">');
            var cols = "";

            cols += '<td>'
                      + '<span class="delete_item"><i class="fas fa-minus-circle text-danger"></i></span>'
                      + '<input type="hidden" name="product_id" value="'+product.id+'">' 
                    +'</td>';
            cols += '<td><span name="description">'+product.name+'<br/>'+product.description+'</span></td>';
            cols += '<td>'+input_quantity+'</td>';
            cols += '<td>' 
                      +'<span id="cost_span">'
                        +'<input type="number" class="form-control text-right" name="cost" step="0.01" value="0" min="1">'
                      +'</span>'
                    +'</td>';
            cols += '<td>'+select_discount+'</td>';
            cols += '<td>'+input_uom+'</td>';
            cols += '<td>'+taxable_value+'</td>';
            cols += '<td>'+tax+'</td>';
           
            cols += '<td>'+tax_type+'</td>';
            cols += '<td><span name="subtotal"></span></td>';
            cols += '</tr>';

            newRow.append(cols);
            $("table.product_table").append(newRow);
            $('.select2bs4').select2({theme: 'bootstrap4'});

            calculateRow(newRow);
      }

      function is_product_exist_in_row(product_id)
      {
        var isproductExist = false;
        $("#product_table_body").find('tr').each(function () {

          var tr = $(this).closest("tr");

          if(tr.find('input[name^="product_id"]').val() == product_id)
          {
            isproductExist = true;
          }
        });

        return isproductExist;
      }

      function highlight_row(product_id)
      {
        $("#product_table_body").find('tr').each(function () {
          var tr  = $(this).closest("tr");

          if(tr.find('input[name^="product_id"]').val() == product_id)
          {
            tr.addClass('highlight_row');

            var existing_quantity = +tr.find('input[name^="quantity"]').val();
            // alert(existing_quantity + 1);
            tr.find('input[name^="quantity"]').val(existing_quantity + 1).trigger('change');
            tr.find('span[name^="quantity_update_message"]').text('+1');

            setTimeout(function(){
              tr.removeClass('highlight_row');
              tr.find('span[name^="quantity_update_message"]').text('');
            },3000);
          }
        });        
      }

      $("table.product_table").on('change', 'input[name^="cost"], input[name^="quantity"], select[name^="item_discount"]', function (event) {

        if($(this).attr('name') == 'item_discount')
        {
          var discount_id = $(this).val();
          var tr          = $(this).closest('tr');

          $.ajax({
            url: "<?php echo base_url('discount/get_record_detail') ?>",
            type: "POST",
            dataType: "json",
            data:{
              'discount_id' : discount_id,
              '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            success: function(data){
              var discount = data.discount;
              var discount_type = '';

              tr.find('input[name^="discount_type"]').val(discount.type);
              tr.find('input[name^="discount_value"]').val(discount.value);
              
              calculateRow(tr);
              calculateGrandTotal();
            }
          });  
        }
        else
        {
          calculateRow($(this).closest("tr"));
          calculateGrandTotal();
        }
       });
      
      $('table.product_table').on('click',"span.delete_item", function(e){
        var tr = $(this).closest('tr');
        tr.remove();
        calculateGrandTotal();
      });

      function calculateRow(row)
      {
        var tax_type    = row.find('input[name^="tax_type"]').val();

        if(tax_type == 0)
        {
          var product_id  = row.find('input[name^="product_id"]').val();
          var quantity    = parseFloat(row.find('input[name^="quantity"]').val());
          var cost       = parseFloat(row.find('input[name^="cost"]').val());
          var final_discount_value = 0;

          var taxable_value   = parseFloat(quantity * cost);

          var discount_type   = row.find('input[name^="discount_type"]').val();
          var discount_value  = parseFloat(row.find('input[name^="discount_value"]').val());  

          var final_discount_value = 0;

          if(discount_type == 0)
          {
            final_discount_value = discount_value;
          }
          else
          {
            final_discount_value = (taxable_value * discount_value)/100;
          }

          taxable_value   = taxable_value - final_discount_value;
          
          var igst        = parseFloat(row.find('span[name^="igst"]').text());
          var cgst        = parseFloat(row.find('span[name^="cgst"]').text());
          var sgst        = parseFloat(row.find('span[name^="sgst"]').text());

          var igst_tax    = parseFloat((taxable_value * igst)/100) ;
          var cgst_tax    = parseFloat((taxable_value * cgst)/100) ;
          var sgst_tax    = parseFloat((taxable_value * sgst)/100) ;

          var subtotal       = parseFloat(taxable_value + igst_tax + cgst_tax + sgst_tax);

          row.find('span[name^="i_tax"]').text(igst_tax.toFixed(2));
          row.find('span[name^="c_tax"]').text(cgst_tax.toFixed(2));
          row.find('span[name^="s_tax"]').text(sgst_tax.toFixed(2));
          row.find('span[name^="discount_amount"]').text(final_discount_value.toFixed(2));

          row.find('span[name^="taxable_value"]').text(taxable_value.toFixed(2));
          row.find('span[name^="subtotal"]').text(subtotal.toFixed(2));  
        }
        else
        {
          var final_discount_value = 0;
          var quantity    = parseFloat(row.find('input[name^="quantity"]').val());
          var cost       = parseFloat(row.find('input[name^="cost"]').val());

          var discount_type   = row.find('input[name^="discount_type"]').val();
          var discount_value  = parseFloat(row.find('input[name^="discount_value"]').val()); 

          var subtotal       = (quantity * cost);

          if(discount_type == 0)
          {
            final_discount_value = discount_value;
          }
          else
          {
            final_discount_value = (subtotal * discount_value)/100;
          }

          subtotal = subtotal - final_discount_value;

          // alert(final_discount_value);

          var igst        = parseFloat(row.find('span[name^="igst"]').text());
          var cgst        = parseFloat(row.find('span[name^="cgst"]').text());
          var sgst        = parseFloat(row.find('span[name^="sgst"]').text());

          var igst_tax    = parseFloat(subtotal * igst / (100 + igst));
          var cgst_tax    = parseFloat(subtotal * cgst / (100 + cgst));
          var sgst_tax    = parseFloat(subtotal * sgst / (100 + sgst));

          var taxable_value = subtotal - igst_tax - cgst_tax - sgst_tax;

          row.find('span[name^="i_tax"]').text(igst_tax.toFixed(2));
          row.find('span[name^="c_tax"]').text(cgst_tax.toFixed(2));
          row.find('span[name^="s_tax"]').text(sgst_tax.toFixed(2));
          row.find('span[name^="discount_amount"]').text(final_discount_value.toFixed(2));

          row.find('span[name^="taxable_value"]').text(taxable_value.toFixed(2));
          row.find('span[name^="subtotal"]').text(subtotal.toFixed(2));   

        }
        
      }

      function calculateGrandTotal()
      {
        var total_taxable_value = 0.0;
        var total_cgst          = 0.0;
        var total_sgst          = 0.0;
        var total_igst          = 0.0;
        var total               = 0.0;
        var total_discount      = 0.0;

        $("#product_table_body").find('tr').each(function () {
            var tr              = $(this).closest("tr");
            total_taxable_value += parseFloat(tr.find('span[name^="taxable_value"]').text());
            total_discount      += parseFloat(tr.find('span[name^="discount_amount"]').text());
            total_cgst          += parseFloat(tr.find('span[name^="c_tax"]').text());
            total_sgst          += parseFloat(tr.find('span[name^="s_tax"]').text());
            total_igst          += parseFloat(tr.find('span[name^="i_tax"]').text());
            total               += parseFloat(tr.find('span[name^="subtotal"]').text()); 
        });

        $('#total_taxable_value').text(total_taxable_value.toFixed(2));
        $('#t_taxable_value').val(total_taxable_value.toFixed(2));

        $('#total_discount').text(total_discount.toFixed(2));
        $('#t_discount').val(total_discount.toFixed(2));

        $('#total_tax').text((total_cgst+total_sgst+total_igst).toFixed(2));
        $('#t_tax').val((total_cgst+total_sgst+total_igst).toFixed(2));

        $('#total').text(total.toFixed(2));
        $('#t').val(total.toFixed(2));
      }

      $('#editPurchaseForm').submit(function(e){
        // e.preventDefault();

        var isError = false;
        $('#purchaseSubmit').text('<?=$this->lang->line("please_wait")?>');

        $('form#editPurchaseForm .field_validation').each(function() {
            var id    = $(this).attr('id');
            var value = $(this).val();
            var field = $(this).attr('placeholder');

            if(value==null || value==""){
              $("form#editPurchaseForm #err_"+id).text(field+ " field is required.").fadeIn('slow');
              $('form#editPurchaseForm #'+id).addClass('is-invalid');
              isError = true;
            }
            else
            {
              $("form#editPurchaseForm #err_"+id).text("").fadeOut('slow');
              $('form#editPurchaseForm #'+id).removeClass('is-invalid');
              $('form#editPurchaseForm #'+id).addClass('is-valid');
            }
        });

        var productDataArray = [];

        $("#product_table_body").find('tr').each(function () {

            var tr              = $(this).closest("tr");
            var productData     = {};

            productData['product_id']       = tr.find('input[name^="product_id"]').val();
            productData['description']      = tr.find('span[name^="description"]').text();
            productData['quantity']         = tr.find('input[name^="quantity"]').val();
            productData['cost']             = tr.find('input[name^="cost"]').val();
            productData['taxable_value']    = parseFloat(productData['quantity'])*parseFloat(productData['cost']);
            productData['discount_id']      = tr.find('select[name^="item_discount"]').val();
            productData['uom_id']           = tr.find('input[name^="uom_id"]').val();
            productData['uom_name']         = tr.find('input[name^="uom_id"]').data('uom_name');
            productData['uom_uom']          = tr.find('input[name^="uom_id"]').data('uom_uom');
            productData['discount_type']    = tr.find('input[name^="discount_type"]').val();
            productData['discount_value']   = tr.find('input[name^="discount_value"]').val();
            productData['discount_amount']  = tr.find('span[name^="discount_amount"]').text();
            productData['tax_id']           = tr.find('input[name^="tax_id"]').val();
            productData['tax_type']         = tr.find('input[name^="tax_type"]').val();
            productData['igst']             = tr.find('span[name^="igst"]').text();
            productData['igst_tax']         = tr.find('span[name^="i_tax"]').text();
            productData['cgst']             = tr.find('span[name^="cgst"]').text();
            productData['cgst_tax']         = tr.find('span[name^="c_tax"]').text();
            productData['sgst']             = tr.find('span[name^="sgst"]').text();
            productData['sgst_tax']         = tr.find('span[name^="s_tax"]').text();
            productData['subtotal']        = tr.find('span[name^="subtotal"]').text();

            productDataArray.push(JSON.stringify(productData));
        });

        if(productDataArray.length > 0)
        {
          $('#purchase_items').val(productDataArray.join('|'));
        }
        else
        {
          isError = true;
          $('#emptyPurchaseItemWarningModal').modal('show');
        }

        if(isError == true)
        {
          $('#purchaseSubmit').text('<?=$this->lang->line("purchase_add")?>');
          return false;
        }
        else 
        {
          return true;
        }
      });

      $("form#editPurchaseForm .field_validation").on("blur keyup change",  function (event){
        var id    = $(this).attr('id');
        var value = $(this).val();
        var field = $(this).attr('placeholder');
        
        if(value==null || value==""){
          $("form#editPurchaseForm #err_"+id).text(field+ " field is required.").fadeIn('slow');
          $('form#editPurchaseForm #'+id).addClass('is-invalid');
          return false;
        }
        else{
          $("form#editPurchaseForm #err_"+id).text("").fadeOut('slow');
          $('form#editPurchaseForm #'+id).removeClass('is-invalid');
          $('form#editPurchaseForm #'+id).addClass('is-valid');
        }
      });
  });
</script>