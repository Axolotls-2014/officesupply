<?php $this->load->view('layout/header');?>

<div class="wrapper">
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row mb-2">
        <div class="col-sm-12">
          <ol class="breadcrumb breadcrumb-custom float-sm-left">
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('home')?></a></li>
            <li class="breadcrumb-item "><a href="#"><?=$this->lang->line('header_inventory')?></a></li>
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('header_purchase')?></a></li>
            <li class="breadcrumb-item active"><?=$this->lang->line('purchase_view')?></li>
          </ol>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><?=$this->lang->line('purchase_view')?></h3>
              <?php 
                if($this->permission_model->has_permission('edit_purchase'))
                {
              ?>
              <div class="card-tools">
                <a href="<?=base_url('purchase/edit/'.$purchase->id)?>" class="btn btn-secondary">
                  <i class="fas fa-edit"></i> <?=$this->lang->line('edit')?>
                </a>
                <a href="<?=base_url('purchase/pdf/'.$purchase->id)?>" class="btn btn-warning">
                  <i class="far fa-file-pdf"></i> <?=$this->lang->line('generate_pdf')?>
                </a>
              </div>
              <?php 
                }
              ?>
            </div>
            <div class="card-body">
              <div class="invoice p-3 mb-3">

                <?php
                  $purchase_amount      = $purchase->total;
                  $purchase_paid_amount = $this->transaction_model->get_total_transaction_amount($purchase->id,PURCHASE_MODULE,PAYMENT_TRANSACTION_TYPE);  
                ?>
                <div class="ribbon-wrapper ribbon-lg">
                  <div class="ribbon 
                    <?php 
                      if($purchase_paid_amount == $purchase_amount)
                      {
                        echo 'bg-success';
                      }
                      else if($purchase_paid_amount < $purchase_amount && $purchase_paid_amount > 0)
                      {
                        echo 'bg-warning';
                      }
                      else
                      {
                        echo 'bg-danger'; 
                      }
                    ?>
                  ">
                    <?php
                      if($purchase_paid_amount >= $purchase_amount)
                      {
                        echo $this->lang->line('paid');
                      }
                      else if($purchase_paid_amount < $purchase_amount && $purchase_paid_amount > 0)
                      {
                        echo $this->lang->line('partially_paid');
                      }
                      else
                      {
                        echo $this->lang->line('unpaid'); 
                      }
                    ?>
                  </div>
                </div>
                <!-- title row -->
                <div class="row">
                  <div class="col-12 text-center">
                    <?=$this->lang->line('tax_purchase_under_gst')?> <br/><?=$this->lang->line('quotation_for_recipient')?>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12">
                    <h4>
                      <i class="fas fa-globe"></i> <?=$company_setting->company_name?>
                      <small class="float-right"> <?=$this->lang->line('date')?>: <?=date('d-m-Y', strtotime($purchase->purchase_date))?></small>
                    </h4>
                  </div>
                  <!-- /.col -->
                </div>
                <div class="row">
                  <div class="col-12">
                    <table width="100%" class="table">
                      <tr style="font-size: 16px;font-weight: bolder;">
                        <td><?=$this->lang->line('bill_to')?></td>
                        <td><?=$this->lang->line('name_address_supplier')?></td>
                        <td><?=$this->lang->line('purchase_details')?></td>
                      </tr>
                      <tr>
                        <td>
                          <address>
                            <strong><?=$company_setting->company_name?></strong><br>
                            <?=$company_setting->address_line1?><br>
                            <?=$company_setting->address_line2?><br>
                            <?=$company_setting->city_name.', '.$company_setting->state_name.', '.$company_setting->country_name?><br>
                            <?=$company_setting->pincode?><br>
                            <?=$this->lang->line('phone')?>: <?=$company_setting->mobile?><br>
                            <?=$this->lang->line('email')?>: <?=$company_setting->email?><br>
                            <strong><?=$this->lang->line('gstin_of_supplier')?>: <?=$company_setting->gstin?></strong><br>
                          </address>
                        </td>
                        <td>
                          <address>
                            <strong><?=$supplier_detail->company_name?></strong><br>
                            <?=$supplier_detail->address?><br>
                            <?=$supplier_detail->city_name.', '.$supplier_detail->state_name.', '.$supplier_detail->country_name?><br>
                            <?=$this->lang->line('phone')?>: <?=$supplier_detail->phone?><br>
                            <?=$this->lang->line('email')?>: <?=$supplier_detail->email?><br>
                            <?=$this->lang->line('gstin')?>: <?=$supplier_detail->gstin?><br>
                          </address>
                        </td>
                        <td>
                          <b><?=$this->lang->line('purchase_id')?></b><?=$purchase->reference_no?><br>
                          <b><?=$this->lang->line('receipt_voucher_no')?></b> <br/>
                        </td>
                      </tr>
                    </table>
                  </div>
                </div>
               
                <!-- Table row -->
                <div class="row">
                  <div class="col-12 table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th><?=$this->lang->line('sr')?></th>
                          <th><?=$this->lang->line('product')?></th>
                          <th><?=$this->lang->line('hsn')?></th>
                          <th><?=$this->lang->line('qty')?></th>
                          <th><?=$this->lang->line('purchase_cost')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('discount')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('purchase_uom')?></th>
                          <th><?=$this->lang->line('total_taxable_value')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('tax')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                          <th><?=$this->lang->line('subtotal')?> (<?=$this->session->userdata('currency_symbol')?>)</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                          $i = 1;
                          $total_quantity = 0;
                          $total_cost    = 0;
                          $total_discount_amount = 0;
                          $total_taxable_value = 0;
                          $total_tax = 0;
                          $total_subtotal = 0;
                          foreach ($purchase_items as $row) 
                          {
                            $total_quantity         += $row->quantity;
                            $total_cost             += $row->cost;
                            $total_discount_amount  += $row->discount_amount;
                            $total_taxable_value    += $row->taxable_value;
                            $total_tax              += $row->cgst_tax+$row->sgst_tax+$row->igst_tax;
                            $total_subtotal         += $row->subtotal;
                        ?>
                          <tr>
                            <td><?=$i++?></td>
                            <td><?=$row->product_name.'<br/>'.$row->description?></td>
                            <td><?=$row->hsn?></td>
                            <td><?=$row->quantity?></td>
                            <td><?=$row->cost?></td>
                            <td><?=$row->discount_amount?></td>
                            <th><?=$row->uom_uom?></th>
                            <td><?=$row->taxable_value?></td>
                            <td>
                              <?php 
                                if($company_setting->country_id == $supplier_detail->country_id && !($company_setting->gstin == '' && $supplier_detail->gstin == ''))
                                {
                                  if($company_setting->state_id == $supplier_detail->state_id)
                                  {
                              ?>
                                    CGST : <?=$row->cgst_tax?>
                                    (<?=$row->cgst?>%)
                                    <br>SGST : <?=$row->sgst_tax?>
                                    (<?=$row->sgst?>%)
                              <?php
                                  }
                                  else
                                  {
                              ?>
                                    IGST : <?=$row->igst_tax?>
                                    (<?=$row->igst?>%)
                              <?php 
                                  }
                                }
                                else
                                {
                              ?>
                                  N/A
                              <?php
                                }
                              ?>
                            </td>
                            <td><?=$row->subtotal?></td>
                          </tr>
                        <?php 
                          }
                        ?>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="3">
                              <?=$this->lang->line('total_amount_due')?>   
                            </td>
                            <td><?=$total_quantity?></td>
                            <td><?=$total_cost?></td>
                            <td><?=$total_discount_amount?></td>
                            <td></td>
                            <td><?=$total_taxable_value?></td>
                            <td><?=$total_tax?></td>
                            <td><?=$total_subtotal?></td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="9">
                              <?=$this->lang->line('advance_adjusted')?> 
                            </td>
                            <td><?="0.0"?></td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="9">
                              <?=$this->lang->line('rounded_off')?>
                            </td>
                            <td>
                              <?php 
                                if((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)) > 0)
                                {
                                  echo '+'.number_format((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)),2);
                                }
                                else
                                {
                                  echo number_format((round($purchase->total_taxable_value+$purchase->total_tax) - ($purchase->total_taxable_value+$purchase->total_tax)),2);
                                }
                              ?>
                            </td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bolder;">
                            <td colspan="9">
                              <?=$this->lang->line('balance_payable')?>
                            </td>
                            <td>
                              <?php echo round($purchase->total_taxable_value+$purchase->total_tax);?>
                            </td>
                          </tr>
                          <tr style="font-size: 16px;font-weight: bold; ">
                            <td colspan="5">
                              <?=$this->lang->line('amount_in_words')?>
                            </td>
                            <td colspan="5" style="text-align: right">
                              <?php echo $this->numbertowords->convert_number(round($purchase->total_taxable_value+$purchase->total_tax));?>
                            </td>
                          </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <!-- /.row -->

                <div class="row">
                  <div class="col-12">
                    <table width="100%" class="table">
                      <tr style="font-size: 16px;font-weight: bolder;">
                        <td width="50%">
                          <?=$this->lang->line('terms_condition')?>
                        </td>
                        <td>
                         <?=$this->lang->line('certified_message')?>                         
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?=$purchase->terms_and_condition?>
                        </td>
                        <td>
                          <?=$this->lang->line('for')?>, <?=strtoupper($company_setting->company_name)?>
                          <br/>
                          <br/>
                          <br/>
                          <?=$this->lang->line('signatory')?>
                        </td>
                      </tr>
                    </table>
                  </div>
                </div>

                <!-- this row will not appear when printing -->
                <div class="row no-print">
                  <div class="col-12">
                    
                    <button type="button" class="btn btn-success float-left print_invoice">
                      <i class="fas fa-print"></i> <?=$this->lang->line('print')?>
                    </button>
                    <!-- <button type="button" class="btn btn-success float-right">
                      <i class="far fa-credit-card"></i> Submit Payment
                    </button>
                    <a class="btn btn-primary float-right" style="margin-right: 5px;" href="<?=base_url('purchase/pdf/'.$purchase->id)?>" target="_blank">
                      <i class="fas fa-download"></i> Generate PDF
                    </a> -->
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<?php $this->load->view('layout/footer');?>

<script type="text/javascript">
  $(document).ready(function(e){
    $('.print_invoice').click(function(e){
      $('.invoice').printThis();
    });
  });
</script>