<?php $this->load->view('layout/header');?>

<div class="wrapper">
  <div class="content-wrapper">
    <section class="content-header">
      <div class="row mb-2">
        <div class="col-sm-12">
          <ol class="breadcrumb breadcrumb-custom float-sm-left">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('header_setting')?></a></li>
            <li class="breadcrumb-item"><a href="#"><?=$this->lang->line('header_currency')?></a></li>
            <li class="breadcrumb-item active"><?=$this->lang->line('currency_list')?></li>
          </ol>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><?=$this->lang->line('currency_list')?></h3>
              <div class="card-tools">
                <ul class="nav nav-pills ml-auto">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?=base_url('currency/add')?>"><i class="fas fa-money-check-alt mr-2"></i><?=$this->lang->line('currency_add')?></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="card-body">

              <button type="button" id="button1" class="btn btn-outline-primary append_text" data-shortcode="{test_1}">Test 1</button>
              <button type="button" id="button2" class="btn btn-outline-primary append_text" data-shortcode="{test_2}">Test 2</button>
              <button type="button" id="button3" class="btn btn-outline-primary append_text" data-shortcode="{test_3}">Test 3</button>



              <textarea id="text_area" class="form-control" rows="3" placeholder="Enter ..." style="margin-top: 15px;"></textarea>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<?php $this->load->view('layout/footer');?>

<script type="text/javascript">
  
  $(function() {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });

    <?php if($this->session->flashdata('success')) { ?>
        Toast.fire({
          type: 'success',
          title: '<?=$this->session->flashdata('success')?>'
        });
    <?php } ?>
  });
</script>

<script type="text/javascript">
  $(document).ready(function(e){
    $('.append_text').click(function(e){
      var text_area_content = $('#text_area').text();
      text_area_content += $(this).data('shortcode')
      $('#text_area').text(text_area_content);
    })
  });
</script>
